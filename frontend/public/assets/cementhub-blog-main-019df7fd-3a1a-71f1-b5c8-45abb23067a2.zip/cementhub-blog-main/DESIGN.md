# Design Brief

## Direction

Editorial Clarity — Professional content-first blog for engineers with high legibility, strong visual hierarchy, and semantic structure optimized for SEO.

## Tone

Approachable editorial. Clean serif-and-sans pairing, generous whitespace, deliberate color restraint. Inspires confidence through clarity, not decoration.

## Differentiation

Distinctive serif display headers combined with industrial slate-blue accent color create a memorable publishing identity that stands apart from generic tech blogs.

## Color Palette

| Token      | OKLCH           | Role                          |
| ---------- | --------------- | ----------------------------- |
| background | 0.98 0.005 230  | Light cream, maximum contrast |
| foreground | 0.15 0.01 230   | Deep slate text               |
| card       | 1.0 0.0 0       | Pure white surfaces           |
| primary    | 0.48 0.12 245   | Slate-blue CTAs & headers     |
| accent     | 0.55 0.08 160   | Muted sage emphasis           |
| muted      | 0.94 0.01 230   | Subtle backgrounds            |

## Typography

- Display: Lora — editorial warmth for article titles, section headers
- Body: General Sans — technical clarity for paragraphs, UI labels, metadata
- Mono: Geist Mono — code blocks, terminal references
- Scale: hero `text-5xl md:text-7xl font-bold tracking-tight`, h2 `text-3xl md:text-4xl font-bold tracking-tight`, label `text-xs uppercase tracking-widest`, body `text-base md:text-lg`

## Elevation & Depth

Minimal shadows (shadows-sm only). Surface hierarchy through background color shifts: white cards on cream background, muted sections alternate at 30% opacity. No decorative depth effects.

## Structural Zones

| Zone           | Background            | Border      | Notes                                 |
| -------------- | --------------------- | ----------- | ------------------------------------- |
| Header         | `bg-card`             | `border-b`  | Holds logo, nav, dark toggle          |
| Hero           | `bg-background`       | —           | Title, search, hero visual band       |
| Article cards  | `bg-card` / `bg-muted/30` | —          | Alternating for visual rhythm         |
| Footer         | `bg-muted/40`         | `border-t`  | Site nav, copyright, social links     |

## Spacing & Rhythm

Section gaps 3rem (12 * 0.25rem) mobile, 4rem (16 * 0.25rem) desktop. Card padding 1.5rem, article content max-width 65ch. Meta information compact (0.5rem gaps). Category chips inline with 0.75rem gaps.

## Component Patterns

- Buttons: Rounded-sm slate-blue bg with white text, hover darkens hue, no shadow
- Cards: Rounded-md white background on cream, subtle border, no shadow
- Badges: Rounded-sm with primary/10 background, primary text, semibold weight
- Search: Rounded-md input with border-border, slate-blue focus ring

## Motion

- Entrance: Fade-in 300ms on page load, cascade for article cards (50ms stagger)
- Hover: Button color shift 200ms, underline on article link text
- Decorative: None — prioritize content clarity over animation

## Constraints

- No gradients, no glows, no neon effects
- No full-page backgrounds, all surfaces are explicit layers
- Categories limited to 5-6 max per row for mobile clarity
- Article headings paired with Lora serif for consistency

## Signature Detail

Alternating card backgrounds (white / subtle muted) create visual rhythm without decoration, guiding eye flow through content while maintaining editorial neutrality. This is the anti-pattern pivot: instead of matching cement cliche (industrial rust/grey), we chose editorial refinement.

