import { Layout } from "@/components/Layout";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import { getStoredToken } from "@/hooks/useAuth";
import { InternetIdentityProvider } from "@caffeineai/core-infrastructure";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
  redirect,
} from "@tanstack/react-router";
import { ThemeProvider } from "next-themes";
import { Suspense, lazy } from "react";

const HomePage = lazy(() => import("@/pages/Home"));
const ArticlesPage = lazy(() => import("@/pages/Articles"));
const ArticleDetailPage = lazy(() => import("@/pages/ArticleDetail"));
const AdminPage = lazy(() => import("@/pages/Admin"));
const AdminEditorPage = lazy(() => import("@/pages/AdminEditor"));
const AdminLoginPage = lazy(() => import("@/pages/AdminLogin"));
const ToolsPage = lazy(() => import("@/pages/Tools"));
const KilnThermalCalculator = lazy(
  () => import("@/pages/calculators/KilnThermalCalculator"),
);
const RawMixDesigner = lazy(() => import("@/pages/calculators/RawMixDesigner"));
const EnergyOptimizer = lazy(
  () => import("@/pages/calculators/EnergyOptimizer"),
);
const MillPerformanceAnalyzer = lazy(
  () => import("@/pages/calculators/MillPerformanceAnalyzer"),
);
const EmissionsTracker = lazy(
  () => import("@/pages/calculators/EmissionsTracker"),
);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 60_000, retry: 1 },
  },
});

function PageLoader() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <Skeleton className="h-8 w-64 mb-4" />
      <Skeleton className="h-4 w-full max-w-lg mb-2" />
      <Skeleton className="h-4 w-full max-w-md" />
    </div>
  );
}

const rootRoute = createRootRoute({
  component: () => (
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <Outlet />
      </Suspense>
    </Layout>
  ),
});

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: HomePage,
});

const articlesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/articles",
  component: ArticlesPage,
  validateSearch: (search: Record<string, string>) => ({
    q: (search.q as string) || "",
    category: (search.category as string) || "",
    sort: (search.sort as string) || "date",
    page: search.page ? Number.parseInt(search.page) : 1,
  }),
});

const articleDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/articles/$slug",
  component: ArticleDetailPage,
});

const toolsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools",
  component: ToolsPage,
});

const kilnThermalRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools/kiln-thermal",
  component: KilnThermalCalculator,
});

const rawMixRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools/raw-mix",
  component: RawMixDesigner,
});

const energyOptimizerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools/energy-optimizer",
  component: EnergyOptimizer,
});

const millPerformanceRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools/mill-performance",
  component: MillPerformanceAnalyzer,
});

const emissionsTrackerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/tools/emissions-tracker",
  component: EmissionsTracker,
});

const adminLoginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin/login",
  component: AdminLoginPage,
  beforeLoad: () => {
    const token = getStoredToken();
    if (token) {
      throw redirect({ to: "/admin" });
    }
  },
});

const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin",
  component: AdminPage,
  beforeLoad: () => {
    const token = getStoredToken();
    if (!token) {
      throw redirect({ to: "/admin/login" });
    }
  },
});

const adminEditorRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin/editor",
  component: AdminEditorPage,
  beforeLoad: () => {
    const token = getStoredToken();
    if (!token) {
      throw redirect({ to: "/admin/login" });
    }
  },
  validateSearch: (search: Record<string, string>) => ({
    id: search.id ? BigInt(search.id) : undefined,
  }),
});

const routeTree = rootRoute.addChildren([
  homeRoute,
  articlesRoute,
  articleDetailRoute,
  toolsRoute,
  kilnThermalRoute,
  rawMixRoute,
  energyOptimizerRoute,
  millPerformanceRoute,
  emissionsTrackerRoute,
  adminLoginRoute,
  adminRoute,
  adminEditorRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return (
    <InternetIdentityProvider>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <RouterProvider router={router} />
          <Toaster richColors position="top-right" />
        </ThemeProvider>
      </QueryClientProvider>
    </InternetIdentityProvider>
  );
}
