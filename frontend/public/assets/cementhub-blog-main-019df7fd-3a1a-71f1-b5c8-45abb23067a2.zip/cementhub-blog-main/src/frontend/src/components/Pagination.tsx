import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PaginationProps {
  page: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  className?: string;
}

export function Pagination({
  page,
  totalPages,
  onPageChange,
  className,
}: PaginationProps) {
  if (totalPages <= 1) return null;

  const pages = buildPageNumbers(page, totalPages);

  return (
    <nav
      aria-label="Pagination"
      className={cn("flex items-center justify-center gap-1", className)}
      data-ocid="pagination"
    >
      <button
        type="button"
        onClick={() => onPageChange(page - 1)}
        disabled={page === 1}
        data-ocid="pagination.pagination_prev"
        aria-label="Previous page"
        className="flex items-center justify-center w-9 h-9 rounded-sm border border-border text-foreground disabled:opacity-40 hover:bg-muted disabled:cursor-not-allowed transition-smooth"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {pages.map((p, i) => {
        const key = p === "..." ? `ellipsis-${i}` : String(p);
        return p === "..." ? (
          <span
            key={key}
            className="flex items-center justify-center w-9 h-9 text-muted-foreground text-sm"
          >
            …
          </span>
        ) : (
          <button
            type="button"
            key={key}
            onClick={() => onPageChange(p as number)}
            data-ocid={`pagination.item.${p}`}
            aria-current={p === page ? "page" : undefined}
            className={cn(
              "flex items-center justify-center w-9 h-9 rounded-sm border text-sm font-medium transition-smooth",
              p === page
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-foreground hover:bg-muted",
            )}
          >
            {p}
          </button>
        );
      })}

      <button
        type="button"
        onClick={() => onPageChange(page + 1)}
        disabled={page === totalPages}
        data-ocid="pagination.pagination_next"
        aria-label="Next page"
        className="flex items-center justify-center w-9 h-9 rounded-sm border border-border text-foreground disabled:opacity-40 hover:bg-muted disabled:cursor-not-allowed transition-smooth"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </nav>
  );
}

function buildPageNumbers(current: number, total: number): (number | "...")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages: (number | "...")[] = [1];
  if (current > 3) pages.push("...");
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (current < total - 2) pages.push("...");
  pages.push(total);
  return pages;
}
