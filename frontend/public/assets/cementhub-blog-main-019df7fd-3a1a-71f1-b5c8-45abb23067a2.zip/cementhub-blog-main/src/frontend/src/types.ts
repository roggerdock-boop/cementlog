// Re-export backend types for frontend use
export type {
  Article,
  ArticleId,
  ArticleListResult,
  CreateArticleInput,
  UpdateArticleInput,
  ListArticlesFilter,
} from "./backend.d";

export { ArticleStatus, Category, SortBy } from "./backend.d";

export const CATEGORY_LABELS: Record<string, string> = {
  RawMill: "Raw Mill",
  CementMill: "Cement Mill",
  Kiln: "Kiln",
  AFR: "AFR",
  EnergyOptimization: "Energy Optimization",
};

export const CATEGORY_COLORS: Record<string, string> = {
  RawMill: "bg-primary/10 text-primary",
  CementMill: "bg-accent/10 text-accent-foreground",
  Kiln: "bg-destructive/10 text-destructive",
  AFR: "bg-secondary text-secondary-foreground",
  EnergyOptimization: "bg-primary/15 text-primary",
};

export function formatDate(timestamp: bigint): string {
  return new Date(Number(timestamp)).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function estimateReadTime(content: string): number {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  return Math.max(1, Math.ceil(wordCount / wordsPerMinute));
}
