import { CategoryBadge } from "@/components/CategoryBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useDeleteArticle } from "@/hooks/useAdmin";
import { useListArticles } from "@/hooks/useArticles";
import { clearStoredToken } from "@/hooks/useAuth";
import { type Article, ArticleStatus } from "@/types";
import { formatDate } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  BookOpen,
  Edit,
  Eye,
  FileText,
  PenSquare,
  Plus,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: number | string;
}) {
  return (
    <div className="bg-card border border-border rounded-md p-5 flex items-center gap-4">
      <div className="flex items-center justify-center w-10 h-10 rounded-sm bg-primary/10 text-primary flex-shrink-0">
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
          {label}
        </p>
        <p className="text-2xl font-bold font-display text-foreground">
          {value}
        </p>
      </div>
    </div>
  );
}

function LoadingTable() {
  return (
    <div data-ocid="admin.loading_state" className="space-y-3 p-4">
      {Array.from({ length: 5 }).map((_, i) => (
        // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
        <Skeleton key={i} className="h-12 w-full" />
      ))}
    </div>
  );
}

export default function AdminPage() {
  const navigate = useNavigate();
  const [deleteTarget, setDeleteTarget] = useState<Article | null>(null);
  const deleteMutation = useDeleteArticle();

  const { data: result, isLoading: articlesLoading } = useListArticles({
    page: 0,
    pageSize: 200,
  } as Parameters<typeof useListArticles>[0]);

  const articles = result?.articles ?? [];

  const totalArticles = articles.length;
  const totalPublished = articles.filter(
    (a) => a.status === ArticleStatus.published,
  ).length;
  const totalDrafts = articles.filter(
    (a) => a.status === ArticleStatus.draft,
  ).length;
  const totalViews = articles.reduce((sum, a) => sum + Number(a.viewCount), 0);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteMutation.mutateAsync(deleteTarget.id);
      toast.success(`"${deleteTarget.title}" deleted successfully.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      if (msg === "SESSION_EXPIRED") {
        clearStoredToken();
        toast.error("Your session has expired. Please log in again.");
        navigate({ to: "/admin/login" });
      } else {
        toast.error("Failed to delete article. Please try again.");
        console.error("[handleDelete] error:", err);
      }
    } finally {
      setDeleteTarget(null);
    }
  };

  return (
    <div
      data-ocid="admin.page"
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10"
    >
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground tracking-tight">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage your articles and content
          </p>
        </div>
        <Button
          data-ocid="admin.new_article.primary_button"
          onClick={() =>
            navigate({ to: "/admin/editor", search: { id: undefined } })
          }
        >
          <Plus className="w-4 h-4 mr-2" />
          New Article
        </Button>
      </div>

      {/* Stats Row */}
      <div
        data-ocid="admin.stats.section"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10"
      >
        <StatCard
          icon={FileText}
          label="Total Articles"
          value={totalArticles}
        />
        <StatCard icon={BookOpen} label="Published" value={totalPublished} />
        <StatCard icon={PenSquare} label="Drafts" value={totalDrafts} />
        <StatCard
          icon={TrendingUp}
          label="Total Views"
          value={totalViews.toLocaleString()}
        />
      </div>

      {/* Articles Table */}
      <div className="bg-card border border-border rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-border">
          <h2 className="font-semibold text-foreground font-display text-lg">
            All Articles
          </h2>
        </div>

        {articlesLoading ? (
          <LoadingTable />
        ) : articles.length === 0 ? (
          <div
            data-ocid="admin.articles.empty_state"
            className="py-20 flex flex-col items-center gap-4 text-center px-4"
          >
            <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground">
              <FileText className="w-6 h-6" />
            </div>
            <p className="text-muted-foreground">
              No articles yet. Create your first one!
            </p>
            <Button
              data-ocid="admin.articles.empty_state.primary_button"
              onClick={() =>
                navigate({ to: "/admin/editor", search: { id: undefined } })
              }
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Article
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table data-ocid="admin.articles.table">
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[240px]">Title</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Views</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {articles.map((article, idx) => (
                  <TableRow
                    key={article.id.toString()}
                    data-ocid={`admin.articles.item.${idx + 1}`}
                    className="group"
                  >
                    <TableCell className="font-medium max-w-xs">
                      <span className="line-clamp-2 text-sm text-foreground leading-snug">
                        {article.title}
                      </span>
                      <span className="text-xs text-muted-foreground mt-0.5 block truncate">
                        /{article.slug}
                      </span>
                    </TableCell>
                    <TableCell>
                      <CategoryBadge category={article.category} />
                    </TableCell>
                    <TableCell>
                      {article.status === ArticleStatus.published ? (
                        <Badge
                          data-ocid={`admin.articles.status.${idx + 1}`}
                          className="bg-accent/15 text-accent-foreground border-0 font-semibold text-xs"
                        >
                          Published
                        </Badge>
                      ) : (
                        <Badge
                          data-ocid={`admin.articles.status.${idx + 1}`}
                          className="bg-muted text-muted-foreground border-0 font-semibold text-xs"
                        >
                          Draft
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-sm text-muted-foreground">
                      <span className="flex items-center justify-end gap-1">
                        <Eye className="w-3.5 h-3.5" />
                        {Number(article.viewCount).toLocaleString()}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                      {formatDate(article.publishDate)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          data-ocid={`admin.articles.edit_button.${idx + 1}`}
                          onClick={() =>
                            navigate({
                              to: "/admin/editor",
                              search: { id: article.id },
                            })
                          }
                          aria-label="Edit article"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          data-ocid={`admin.articles.delete_button.${idx + 1}`}
                          onClick={() => setDeleteTarget(article)}
                          aria-label="Delete article"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent data-ocid="admin.delete.dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Article</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold text-foreground">
                &ldquo;{deleteTarget?.title}&rdquo;
              </span>
              ? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              data-ocid="admin.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              data-ocid="admin.delete.confirm_button"
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete Article"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
