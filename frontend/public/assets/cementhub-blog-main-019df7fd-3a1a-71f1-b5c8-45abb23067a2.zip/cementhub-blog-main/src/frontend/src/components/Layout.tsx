import { clearStoredToken, getStoredToken } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  LogOut,
  Menu,
  Moon,
  Settings,
  Sun,
  Wrench,
  X,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useRef, useState } from "react";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, setTheme } = useTheme();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();

  const token = getStoredToken();
  const isAdminArea = pathname.startsWith("/admin");

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const prevPathRef = useRef(pathname);
  if (prevPathRef.current !== pathname) {
    prevPathRef.current = pathname;
    if (mobileOpen) setMobileOpen(false);
  }

  const isDark = theme === "dark";

  const handleLogout = () => {
    clearStoredToken();
    navigate({ to: "/admin/login" });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header
        className={cn(
          "sticky top-0 z-50 bg-card border-b border-border transition-smooth",
          scrolled ? "shadow-sm" : "",
        )}
        data-ocid="header"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center gap-2.5 group"
              data-ocid="header.logo.link"
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-sm bg-primary text-primary-foreground font-bold text-sm font-display">
                C
              </div>
              <div className="leading-tight">
                <span className="text-base font-bold font-display text-foreground tracking-tight group-hover:text-primary transition-colors">
                  CementHub
                </span>
                <span className="hidden sm:block text-[10px] text-muted-foreground tracking-widest uppercase">
                  Knowledge Platform
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav
              className="hidden md:flex items-center gap-1"
              data-ocid="header.nav"
            >
              <Link
                to="/"
                data-ocid="header.nav.home.link"
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-sm transition-smooth",
                  pathname === "/"
                    ? "text-primary bg-primary/5"
                    : "text-foreground hover:text-primary hover:bg-muted",
                )}
              >
                Home
              </Link>
              <Link
                to="/articles"
                search={{ q: "", category: "", sort: "date", page: 1 }}
                data-ocid="header.nav.articles.link"
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-sm transition-smooth",
                  pathname.startsWith("/articles")
                    ? "text-primary bg-primary/5"
                    : "text-foreground hover:text-primary hover:bg-muted",
                )}
              >
                Articles
              </Link>
              <Link
                to="/tools"
                data-ocid="header.nav.tools.link"
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-sm transition-smooth",
                  pathname === "/tools"
                    ? "text-primary bg-primary/5"
                    : "text-foreground hover:text-primary hover:bg-muted",
                )}
              >
                Tools
              </Link>
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-2">
              {/* Admin area indicator + logout */}
              {isAdminArea && token && (
                <div className="hidden sm:flex items-center gap-2">
                  <span className="text-xs text-muted-foreground bg-muted px-2.5 py-1 rounded-sm font-medium">
                    Logged in as admin
                  </span>
                  <button
                    type="button"
                    onClick={handleLogout}
                    data-ocid="header.admin.logout_button"
                    aria-label="Log out"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-sm border border-border transition-smooth"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Logout
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => setTheme(isDark ? "light" : "dark")}
                data-ocid="header.theme.toggle"
                aria-label="Toggle theme"
                className="flex items-center justify-center w-9 h-9 rounded-sm border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-smooth"
              >
                {isDark ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>

              {!isAdminArea && (
                <Link
                  to="/admin"
                  data-ocid="header.admin.link"
                  aria-label="Admin"
                  className="hidden sm:flex items-center justify-center w-9 h-9 rounded-sm border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-smooth"
                >
                  <Settings className="w-4 h-4" />
                </Link>
              )}

              <button
                type="button"
                onClick={() => setMobileOpen((v) => !v)}
                data-ocid="header.mobile.toggle"
                aria-label="Toggle menu"
                className="flex md:hidden items-center justify-center w-9 h-9 rounded-sm border border-border text-muted-foreground hover:text-foreground transition-smooth"
              >
                {mobileOpen ? (
                  <X className="w-4 h-4" />
                ) : (
                  <Menu className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        {mobileOpen && (
          <div
            className="md:hidden bg-card border-t border-border py-3 px-4"
            data-ocid="header.mobile.nav"
          >
            <Link
              to="/"
              data-ocid="header.mobile.home.link"
              className={cn(
                "flex items-center gap-2 w-full px-3 py-2.5 text-sm font-medium rounded-sm transition-smooth",
                pathname === "/"
                  ? "text-primary bg-primary/5"
                  : "text-foreground hover:bg-muted",
              )}
            >
              Home
            </Link>
            <Link
              to="/articles"
              search={{ q: "", category: "", sort: "date", page: 1 }}
              data-ocid="header.mobile.articles.link"
              className={cn(
                "flex items-center gap-2 w-full px-3 py-2.5 text-sm font-medium rounded-sm transition-smooth",
                pathname.startsWith("/articles")
                  ? "text-primary bg-primary/5"
                  : "text-foreground hover:bg-muted",
              )}
            >
              <BookOpen className="w-4 h-4" />
              Articles
            </Link>
            <Link
              to="/tools"
              data-ocid="header.mobile.tools.link"
              className={cn(
                "flex items-center gap-2 w-full px-3 py-2.5 text-sm font-medium rounded-sm transition-smooth",
                pathname === "/tools"
                  ? "text-primary bg-primary/5"
                  : "text-foreground hover:bg-muted",
              )}
            >
              <Wrench className="w-4 h-4" />
              Tools
            </Link>

            {isAdminArea && token ? (
              <button
                type="button"
                onClick={handleLogout}
                data-ocid="header.mobile.logout_button"
                className="flex items-center gap-2 w-full px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted rounded-sm transition-smooth"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            ) : (
              <Link
                to="/admin"
                data-ocid="header.mobile.admin.link"
                className="flex items-center gap-2 w-full px-3 py-2.5 text-sm font-medium text-foreground hover:bg-muted rounded-sm transition-smooth"
              >
                <Settings className="w-4 h-4" />
                Admin
              </Link>
            )}
          </div>
        )}
      </header>

      <main className="flex-1 bg-background">{children}</main>
      <Footer />
    </div>
  );
}

function Footer() {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";

  return (
    <footer className="bg-card border-t border-border" data-ocid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center justify-center w-7 h-7 rounded-sm bg-primary text-primary-foreground font-bold text-xs font-display">
                C
              </div>
              <span className="text-base font-bold font-display text-foreground">
                CementHub
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              A knowledge platform for cement industry engineers and plant
              operators. Practical guides, technical insights, and operational
              best practices.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-4">
              Explore
            </h3>
            <ul className="space-y-2">
              {[
                { to: "/" as const, label: "Home", search: undefined },
                {
                  to: "/articles" as const,
                  label: "All Articles",
                  search: { q: "", category: "", sort: "date", page: 1 },
                },
                { to: "/tools" as const, label: "Tools", search: undefined },
                { to: "/admin" as const, label: "Admin", search: undefined },
              ].map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    search={link.search}
                    data-ocid={`footer.${link.label.toLowerCase().replace(" ", "_")}.link`}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-4">
              Categories
            </h3>
            <ul className="space-y-2">
              {[
                "Raw Mill",
                "Cement Mill",
                "Kiln",
                "AFR",
                "Energy Optimization",
              ].map((cat) => (
                <li key={cat}>
                  <Link
                    to="/articles"
                    search={{
                      q: "",
                      category: cat.replace(/ /g, ""),
                      sort: "date",
                      page: 1,
                    }}
                    data-ocid={`footer.category.${cat.toLowerCase().replace(/ /g, "_")}.link`}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            © {year}. Built with love using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-primary transition-colors underline underline-offset-2"
            >
              caffeine.ai
            </a>
          </p>
          <p className="text-xs text-muted-foreground">
            Cement industry expertise for engineers worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
}
