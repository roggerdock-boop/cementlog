import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useCreateArticle, useUpdateArticle } from "@/hooks/useAdmin";
import { useIsAdmin } from "@/hooks/useAdmin";
import { useArticle } from "@/hooks/useArticles";
import { clearStoredToken } from "@/hooks/useAuth";
import {
  ArticleStatus,
  CATEGORY_LABELS,
  Category,
  type CreateArticleInput,
  type UpdateArticleInput,
} from "@/types";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { ArrowLeft, Save, ShieldOff } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

const AUTOSAVE_KEY = "cement_editor_draft";
const AUTOSAVE_INTERVAL = 30_000;

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

interface FormState {
  title: string;
  slug: string;
  category: Category;
  authorName: string;
  excerpt: string;
  metaDescription: string;
  content: string;
  status: ArticleStatus;
  publishDate: string;
  featuredImageUrl: string;
}

const DEFAULT_FORM: FormState = {
  title: "",
  slug: "",
  category: Category.Kiln,
  authorName: "",
  excerpt: "",
  metaDescription: "",
  content: "",
  status: ArticleStatus.draft,
  publishDate: todayISO(),
  featuredImageUrl: "",
};

export default function AdminEditorPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/admin/editor" });
  const articleId = (search as { id?: bigint }).id;
  const isEditMode = articleId !== undefined;

  const { data: isAdmin, isLoading: adminLoading } = useIsAdmin();
  const { data: existingArticle, isLoading: articleLoading } = useArticle(
    isEditMode ? articleId : undefined,
  );

  const createMutation = useCreateArticle();
  const updateMutation = useUpdateArticle();
  const isSaving = createMutation.isPending || updateMutation.isPending;

  const [form, setForm] = useState<FormState>(DEFAULT_FORM);
  const [slugManuallyEdited, setSlugManuallyEdited] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>("");
  const autosaveRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Populate form from existing article (edit mode)
  useEffect(() => {
    if (existingArticle) {
      setForm({
        title: existingArticle.title,
        slug: existingArticle.slug,
        category: existingArticle.category,
        authorName: existingArticle.authorName,
        excerpt: existingArticle.excerpt,
        metaDescription: existingArticle.metaDescription,
        content: existingArticle.content,
        status: existingArticle.status,
        publishDate: new Date(Number(existingArticle.publishDate))
          .toISOString()
          .split("T")[0],
        featuredImageUrl: existingArticle.featuredImageUrl ?? "",
      });
      setSlugManuallyEdited(true);
      if (existingArticle.featuredImageUrl) {
        setImagePreview(existingArticle.featuredImageUrl);
      }
    }
  }, [existingArticle]);

  // Restore autosave for new articles
  useEffect(() => {
    if (!isEditMode) {
      const saved = localStorage.getItem(AUTOSAVE_KEY);
      if (saved) {
        try {
          const parsed = JSON.parse(saved) as FormState;
          setForm(parsed);
          setSlugManuallyEdited(true);
        } catch {
          // ignore malformed autosave
        }
      }
    }
  }, [isEditMode]);

  // Autosave timer for new articles
  const doAutosave = useCallback(() => {
    if (!isEditMode) {
      localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(form));
    }
  }, [isEditMode, form]);

  useEffect(() => {
    if (!isEditMode) {
      autosaveRef.current = setInterval(doAutosave, AUTOSAVE_INTERVAL);
      return () => {
        if (autosaveRef.current) clearInterval(autosaveRef.current);
      };
    }
  }, [isEditMode, doAutosave]);

  // Redirect if not admin
  useEffect(() => {
    if (!adminLoading && isAdmin === false) {
      toast.info("Admin access required.");
      navigate({ to: "/" });
    }
  }, [isAdmin, adminLoading, navigate]);

  const setField = <K extends keyof FormState>(key: K, val: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: val }));
  };

  const handleTitleChange = (val: string) => {
    setField("title", val);
    if (!slugManuallyEdited) {
      setField("slug", slugify(val));
    }
  };

  const handleImageUrlChange = (url: string) => {
    setField("featuredImageUrl", url);
    setImagePreview(url);
  };

  const buildInput = () => ({
    title: form.title.trim(),
    slug: form.slug.trim(),
    category: form.category,
    authorName: form.authorName.trim(),
    excerpt: form.excerpt.trim(),
    metaDescription: form.metaDescription.trim(),
    content: form.content,
    status: form.status,
    publishDate: BigInt(new Date(form.publishDate).getTime()),
    ...(form.featuredImageUrl
      ? { featuredImageUrl: form.featuredImageUrl }
      : {}),
  });

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast.error("Title is required.");
      return;
    }
    if (!form.slug.trim()) {
      toast.error("Slug is required.");
      return;
    }
    if (!form.content.trim()) {
      toast.error("Content cannot be empty.");
      return;
    }

    try {
      if (isEditMode && articleId !== undefined) {
        const input: UpdateArticleInput = { id: articleId, ...buildInput() };
        await updateMutation.mutateAsync(input);
        toast.success("Article updated successfully.");
      } else {
        const input: CreateArticleInput = buildInput();
        await createMutation.mutateAsync(input);
        localStorage.removeItem(AUTOSAVE_KEY);
        toast.success("Article created successfully.");
        navigate({ to: "/admin" });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      if (msg === "SESSION_EXPIRED") {
        clearStoredToken();
        toast.error("Your session has expired. Please log in again.");
        navigate({ to: "/admin/login" });
      } else {
        toast.error("Failed to save article. Please try again.");
        console.error("[handleSave] error:", err);
      }
    }
  };

  // Loading states
  if (adminLoading || (isEditMode && articleLoading)) {
    return (
      <div
        data-ocid="admin_editor.loading_state"
        className="max-w-4xl mx-auto px-4 py-16 space-y-4"
      >
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (isAdmin === false) {
    return (
      <div
        data-ocid="admin_editor.error_state"
        className="max-w-4xl mx-auto px-4 py-24 flex flex-col items-center gap-6 text-center"
      >
        <ShieldOff className="w-12 h-12 text-destructive" />
        <p className="text-muted-foreground">Admin access required.</p>
        <Button onClick={() => navigate({ to: "/" })}>Back to Home</Button>
      </div>
    );
  }

  return (
    <div
      data-ocid="admin_editor.page"
      className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            data-ocid="admin_editor.back.secondary_button"
            onClick={() => navigate({ to: "/admin" })}
            aria-label="Back to admin"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold font-display text-foreground tracking-tight">
              {isEditMode ? "Edit Article" : "New Article"}
            </h1>
            {!isEditMode && (
              <p className="text-xs text-muted-foreground mt-0.5">
                Auto-saves draft every 30 seconds
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            data-ocid="admin_editor.cancel.secondary_button"
            onClick={() => navigate({ to: "/admin" })}
          >
            Cancel
          </Button>
          <Button
            data-ocid="admin_editor.save.primary_button"
            onClick={handleSave}
            disabled={isSaving}
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving
              ? "Saving…"
              : form.status === ArticleStatus.published
                ? "Save & Publish"
                : "Save Draft"}
          </Button>
        </div>
      </div>

      <div className="space-y-8">
        {/* Title */}
        <div className="space-y-2">
          <Label htmlFor="title" className="text-sm font-medium">
            Title <span className="text-destructive">*</span>
          </Label>
          <Input
            id="title"
            data-ocid="admin_editor.title.input"
            placeholder="Enter article title…"
            value={form.title}
            onChange={(e) => handleTitleChange(e.target.value)}
            className="text-base"
          />
        </div>

        {/* Slug */}
        <div className="space-y-2">
          <Label htmlFor="slug" className="text-sm font-medium">
            URL Slug <span className="text-destructive">*</span>
          </Label>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground text-sm whitespace-nowrap">
              /articles/
            </span>
            <Input
              id="slug"
              data-ocid="admin_editor.slug.input"
              placeholder="article-url-slug"
              value={form.slug}
              onChange={(e) => {
                setSlugManuallyEdited(true);
                setField("slug", slugify(e.target.value));
              }}
              className="font-mono text-sm"
            />
          </div>
        </div>

        {/* Category + Author row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="category" className="text-sm font-medium">
              Category <span className="text-destructive">*</span>
            </Label>
            <Select
              value={form.category}
              onValueChange={(v) => setField("category", v as Category)}
            >
              <SelectTrigger
                id="category"
                data-ocid="admin_editor.category.select"
              >
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="authorName" className="text-sm font-medium">
              Author Name
            </Label>
            <Input
              id="authorName"
              data-ocid="admin_editor.author.input"
              placeholder="e.g. John Chen, PE"
              value={form.authorName}
              onChange={(e) => setField("authorName", e.target.value)}
            />
          </div>
        </div>

        {/* Status + Publish Date row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="status" className="text-sm font-medium">
              Status
            </Label>
            <Select
              value={form.status}
              onValueChange={(v) => setField("status", v as ArticleStatus)}
            >
              <SelectTrigger id="status" data-ocid="admin_editor.status.select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ArticleStatus.draft}>Draft</SelectItem>
                <SelectItem value={ArticleStatus.published}>
                  Published
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="publishDate" className="text-sm font-medium">
              Publish Date
            </Label>
            <Input
              id="publishDate"
              type="date"
              data-ocid="admin_editor.publish_date.input"
              value={form.publishDate}
              onChange={(e) => setField("publishDate", e.target.value)}
            />
          </div>
        </div>

        {/* Excerpt */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="excerpt" className="text-sm font-medium">
              Excerpt
            </Label>
            <span className="text-xs text-muted-foreground">
              {form.excerpt.length}/150
            </span>
          </div>
          <Textarea
            id="excerpt"
            data-ocid="admin_editor.excerpt.textarea"
            placeholder="Brief summary shown on article cards (~150 characters)…"
            value={form.excerpt}
            onChange={(e) => setField("excerpt", e.target.value)}
            rows={3}
            maxLength={200}
          />
        </div>

        {/* Meta Description */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="metaDescription" className="text-sm font-medium">
              Meta Description{" "}
              <span className="text-muted-foreground font-normal">(SEO)</span>
            </Label>
            <span className="text-xs text-muted-foreground">
              {form.metaDescription.length}/160
            </span>
          </div>
          <Textarea
            id="metaDescription"
            data-ocid="admin_editor.meta_description.textarea"
            placeholder="Search engine description (~160 characters)…"
            value={form.metaDescription}
            onChange={(e) => setField("metaDescription", e.target.value)}
            rows={3}
            maxLength={200}
          />
        </div>

        {/* Featured Image */}
        <div className="space-y-2">
          <Label htmlFor="featuredImageUrl" className="text-sm font-medium">
            Featured Image URL
          </Label>
          <Input
            id="featuredImageUrl"
            placeholder="https://example.com/image.jpg"
            data-ocid="admin_editor.image_url.input"
            value={form.featuredImageUrl}
            onChange={(e) => handleImageUrlChange(e.target.value)}
            className="text-sm"
          />
          <p className="text-xs text-muted-foreground">
            Paste a publicly accessible image URL (JPG, PNG, WebP).
          </p>
          {imagePreview && (
            <div className="mt-2">
              <img
                src={imagePreview}
                alt="Featured preview"
                className="w-full max-h-48 object-cover rounded-sm border border-border"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="mt-2 text-destructive hover:text-destructive hover:bg-destructive/10"
                data-ocid="admin_editor.image_remove.secondary_button"
                onClick={() => handleImageUrlChange("")}
              >
                Remove
              </Button>
            </div>
          )}
        </div>

        {/* Content Editor */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="content" className="text-sm font-medium">
              Content <span className="text-destructive">*</span>
              <span className="ml-2 text-xs text-muted-foreground font-normal">
                (HTML supported)
              </span>
            </Label>
            <span className="text-xs text-muted-foreground">
              ~{Math.ceil(form.content.split(/\s+/).length / 200)} min read
            </span>
          </div>
          <Textarea
            id="content"
            data-ocid="admin_editor.content.editor"
            placeholder="Write your article content here. HTML tags are supported (e.g. <h2>, <p>, <ul>, <strong>)…"
            value={form.content}
            onChange={(e) => setField("content", e.target.value)}
            rows={24}
            className="font-mono text-sm leading-relaxed resize-y"
          />
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <Button
            variant="outline"
            data-ocid="admin_editor.cancel_bottom.secondary_button"
            onClick={() => navigate({ to: "/admin" })}
          >
            Cancel
          </Button>
          <Button
            data-ocid="admin_editor.save_bottom.primary_button"
            onClick={handleSave}
            disabled={isSaving}
            size="lg"
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving
              ? "Saving…"
              : form.status === ArticleStatus.published
                ? "Save & Publish"
                : "Save Draft"}
          </Button>
        </div>
      </div>
    </div>
  );
}
