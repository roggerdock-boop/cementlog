import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Flame, Info } from "lucide-react";
import { useState } from "react";

// ─── Shared helpers ───────────────────────────────────────────────────────────

type BenchmarkLevel = "excellent" | "good" | "average" | "poor";

function BenchmarkBadge({ level }: { level: BenchmarkLevel }) {
  const map: Record<BenchmarkLevel, { label: string; cls: string }> = {
    excellent: {
      label: "Excellent",
      cls: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
    },
    good: {
      label: "Good",
      cls: "bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30",
    },
    average: {
      label: "Average",
      cls: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30",
    },
    poor: {
      label: "Poor",
      cls: "bg-destructive/15 text-destructive border-destructive/30",
    },
  };
  const { label, cls } = map[level];
  return <Badge className={cls}>{label}</Badge>;
}

function FormulaTag({ formula }: { formula: string }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-muted/60 px-2 py-0.5 rounded font-mono mt-1">
      <Info className="h-3 w-3 shrink-0" />
      {formula}
    </span>
  );
}

function ResultBlock({
  label,
  value,
  unit,
  formula,
  level,
}: {
  label: string;
  value: string;
  unit: string;
  formula: string;
  level?: BenchmarkLevel;
}) {
  return (
    <div className="rounded-lg bg-primary/5 border border-primary/10 px-4 py-3 space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground uppercase tracking-wide">
          {label}
        </span>
        {level && <BenchmarkBadge level={level} />}
      </div>
      <p className="text-2xl font-bold font-display text-foreground tabular-nums">
        {value}{" "}
        <span className="text-sm font-normal text-muted-foreground">
          {unit}
        </span>
      </p>
      <FormulaTag formula={formula} />
    </div>
  );
}

function EmptyResult({ hint }: { hint: string }) {
  return (
    <div className="rounded-lg bg-muted/40 border border-border px-4 py-5 text-center">
      <Flame className="h-7 w-7 text-muted-foreground/30 mx-auto mb-2" />
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

// ─── Mini-Calc 1: Total Heat Input ───────────────────────────────────────────

function TotalHeatInputCalc() {
  const [fuel, setFuel] = useState("");
  const [cv, setCv] = useState("");
  const [clinker, setClinker] = useState("");

  const fuelN = Number.parseFloat(fuel);
  const cvN = Number.parseFloat(cv);
  const clinkerN = Number.parseFloat(clinker);

  const ready =
    Number.isFinite(fuelN) &&
    fuelN > 0 &&
    Number.isFinite(cvN) &&
    cvN > 0 &&
    Number.isFinite(clinkerN) &&
    clinkerN > 0;

  let result = "";
  let level: BenchmarkLevel | undefined;

  if (ready) {
    const val = (fuelN * cvN) / (clinkerN * 1000);
    result = val.toFixed(1);
    if (val < 700) level = "excellent";
    else if (val < 800) level = "good";
    else if (val <= 1000) level = "average";
    else level = "poor";
  }

  return (
    <Card className="card-elevated" data-ocid="kiln_mini.heat_input.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
            1
          </span>
          Total Heat Input
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Calculate heat supplied per kg of clinker produced
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="thi-fuel">Fuel Consumption (kg/h)</Label>
            <Input
              id="thi-fuel"
              type="number"
              min="0"
              placeholder="e.g. 12000"
              value={fuel}
              onChange={(e) => setFuel(e.target.value)}
              data-ocid="kiln_mini.heat_input.fuel.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="thi-cv">Calorific Value (kcal/kg)</Label>
            <Input
              id="thi-cv"
              type="number"
              min="0"
              placeholder="e.g. 6000 (coal), 8500 (petcoke)"
              value={cv}
              onChange={(e) => setCv(e.target.value)}
              data-ocid="kiln_mini.heat_input.cv.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="thi-clinker">Clinker Production (t/h)</Label>
            <Input
              id="thi-clinker"
              type="number"
              min="0"
              placeholder="e.g. 150"
              value={clinker}
              onChange={(e) => setClinker(e.target.value)}
              data-ocid="kiln_mini.heat_input.clinker.input"
            />
          </div>
        </div>

        {ready ? (
          <ResultBlock
            label="Total Heat Input"
            value={result}
            unit="kcal/kg clinker"
            formula="(Fuel × CV) / (Clinker × 1000)"
            level={level}
          />
        ) : (
          <EmptyResult hint="Enter all three values to calculate" />
        )}

        <div className="text-xs text-muted-foreground space-y-0.5">
          <p className="font-medium text-foreground/70">Benchmarks:</p>
          <p>
            <span className="text-emerald-600 dark:text-emerald-400">
              {"<700"}
            </span>{" "}
            Excellent ·{" "}
            <span className="text-green-600 dark:text-green-400">700–800</span>{" "}
            Good ·{" "}
            <span className="text-yellow-600 dark:text-yellow-400">
              800–1000
            </span>{" "}
            Average · <span className="text-destructive">{">1000"}</span> Poor
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 2: Exhaust Gas Heat Loss ──────────────────────────────────────

function ExhaustGasHeatLossCalc() {
  const [gasVol, setGasVol] = useState("");
  const [cp, setCp] = useState("0.33");
  const [exitTemp, setExitTemp] = useState("");
  const [ambTemp, setAmbTemp] = useState("20");

  const gasVolN = Number.parseFloat(gasVol);
  const cpN = Number.parseFloat(cp) || 0.33;
  const exitN = Number.parseFloat(exitTemp);
  const ambN = Number.parseFloat(ambTemp) || 20;

  const ready =
    Number.isFinite(gasVolN) &&
    gasVolN > 0 &&
    Number.isFinite(exitN) &&
    exitN > ambN;

  let result = "";
  let level: BenchmarkLevel | undefined;

  if (ready) {
    const val = gasVolN * cpN * (exitN - ambN);
    result = val.toFixed(1);
    if (val < 150) level = "excellent";
    else if (val <= 250) level = "good";
    else if (val <= 350) level = "average";
    else level = "poor";
  }

  return (
    <Card className="card-elevated" data-ocid="kiln_mini.exhaust_loss.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
            2
          </span>
          Exhaust Gas Heat Loss
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Calculate heat lost through kiln exhaust gases
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="ehl-gasvol">Gas Volume (Nm³/kg clinker)</Label>
            <Input
              id="ehl-gasvol"
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 1.4"
              value={gasVol}
              onChange={(e) => setGasVol(e.target.value)}
              data-ocid="kiln_mini.exhaust_loss.gas_vol.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ehl-cp">Specific Heat of Gas (kcal/Nm³/°C)</Label>
            <Input
              id="ehl-cp"
              type="number"
              min="0"
              step="0.01"
              placeholder="default 0.33"
              value={cp}
              onChange={(e) => setCp(e.target.value)}
              data-ocid="kiln_mini.exhaust_loss.cp.input"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ehl-exit">Exit Temp (°C)</Label>
              <Input
                id="ehl-exit"
                type="number"
                placeholder="e.g. 320"
                value={exitTemp}
                onChange={(e) => setExitTemp(e.target.value)}
                data-ocid="kiln_mini.exhaust_loss.exit_temp.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ehl-amb">Ambient Temp (°C)</Label>
              <Input
                id="ehl-amb"
                type="number"
                placeholder="default 20"
                value={ambTemp}
                onChange={(e) => setAmbTemp(e.target.value)}
                data-ocid="kiln_mini.exhaust_loss.amb_temp.input"
              />
            </div>
          </div>
        </div>

        {ready ? (
          <ResultBlock
            label="Exhaust Gas Heat Loss"
            value={result}
            unit="kcal/kg clinker"
            formula="Gas Vol × Cp × (T_exit − T_ambient)"
            level={level}
          />
        ) : (
          <EmptyResult hint="Enter Gas Volume and Exit Temperature to calculate" />
        )}

        <div className="text-xs text-muted-foreground space-y-0.5">
          <p className="font-medium text-foreground/70">Benchmarks:</p>
          <p>
            <span className="text-emerald-600 dark:text-emerald-400">
              {"<150"}
            </span>{" "}
            Excellent ·{" "}
            <span className="text-green-600 dark:text-green-400">150–250</span>{" "}
            Good ·{" "}
            <span className="text-yellow-600 dark:text-yellow-400">
              250–350
            </span>{" "}
            Average · <span className="text-destructive">{">350"}</span> Poor —
            lower is better
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 3: Radiation & Convection Loss ─────────────────────────────────

function RadiationLossCalc() {
  const [totalHeat, setTotalHeat] = useState("");
  const [lossFactor, setLossFactor] = useState("7");

  const totalN = Number.parseFloat(totalHeat);
  const factorN = Number.parseFloat(lossFactor) || 7;

  const ready = Number.isFinite(totalN) && totalN > 0;

  let result = "";
  let level: BenchmarkLevel | undefined;
  let pct = 0;

  if (ready) {
    const val = totalN * (factorN / 100);
    result = val.toFixed(1);
    pct = factorN;
    if (pct < 5) level = "excellent";
    else if (pct <= 7) level = "good";
    else if (pct <= 10) level = "average";
    else level = "poor";
  }

  return (
    <Card className="card-elevated" data-ocid="kiln_mini.radiation_loss.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
            3
          </span>
          Radiation &amp; Convection Loss
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Estimate shell radiation and convection losses
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="rl-total">Total Heat Input (kcal/kg clinker)</Label>
            <Input
              id="rl-total"
              type="number"
              min="0"
              placeholder="e.g. 800"
              value={totalHeat}
              onChange={(e) => setTotalHeat(e.target.value)}
              data-ocid="kiln_mini.radiation_loss.total_heat.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rl-factor">Radiation Loss Factor (%)</Label>
            <Input
              id="rl-factor"
              type="number"
              min="0"
              max="30"
              step="0.1"
              placeholder="default 7"
              value={lossFactor}
              onChange={(e) => setLossFactor(e.target.value)}
              data-ocid="kiln_mini.radiation_loss.factor.input"
            />
            <p className="text-xs text-muted-foreground">
              Typical range: 5–10% of total heat input
            </p>
          </div>
        </div>

        {ready ? (
          <ResultBlock
            label="Radiation & Convection Loss"
            value={result}
            unit="kcal/kg clinker"
            formula="Total Heat Input × (Loss Factor / 100)"
            level={level}
          />
        ) : (
          <EmptyResult hint="Enter Total Heat Input to calculate" />
        )}

        <div className="text-xs text-muted-foreground space-y-0.5">
          <p className="font-medium text-foreground/70">
            Benchmarks (loss factor):
          </p>
          <p>
            <span className="text-emerald-600 dark:text-emerald-400">
              {"<5%"}
            </span>{" "}
            Excellent ·{" "}
            <span className="text-green-600 dark:text-green-400">5–7%</span>{" "}
            Good ·{" "}
            <span className="text-yellow-600 dark:text-yellow-400">7–10%</span>{" "}
            Average · <span className="text-destructive">{">10%"}</span> Poor
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 4: Thermal Efficiency ─────────────────────────────────────────

function ThermalEfficiencyCalc() {
  const [usefulHeat, setUsefulHeat] = useState("420");
  const [totalHeat, setTotalHeat] = useState("");

  const usefulN = Number.parseFloat(usefulHeat) || 420;
  const totalN = Number.parseFloat(totalHeat);

  const ready = Number.isFinite(totalN) && totalN > 0;

  let result = "";
  let level: BenchmarkLevel | undefined;

  if (ready) {
    const val = (usefulN / totalN) * 100;
    result = val.toFixed(1);
    if (val >= 55) level = "excellent";
    else if (val >= 45) level = "good";
    else level = "poor";
  }

  return (
    <Card className="card-elevated" data-ocid="kiln_mini.thermal_eff.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
            4
          </span>
          Thermal Efficiency
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Measure how effectively heat is used for clinker formation
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="te-useful">Useful Heat for Clinker (kcal/kg)</Label>
            <Input
              id="te-useful"
              type="number"
              min="0"
              placeholder="default 420 (theoretical standard)"
              value={usefulHeat}
              onChange={(e) => setUsefulHeat(e.target.value)}
              data-ocid="kiln_mini.thermal_eff.useful_heat.input"
            />
            <p className="text-xs text-muted-foreground">
              Standard theoretical value: 420 kcal/kg
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="te-total">Total Heat Input (kcal/kg clinker)</Label>
            <Input
              id="te-total"
              type="number"
              min="0"
              placeholder="e.g. 800"
              value={totalHeat}
              onChange={(e) => setTotalHeat(e.target.value)}
              data-ocid="kiln_mini.thermal_eff.total_heat.input"
            />
          </div>
        </div>

        {ready ? (
          <ResultBlock
            label="Thermal Efficiency"
            value={result}
            unit="%"
            formula="(Useful Heat / Total Heat Input) × 100"
            level={level}
          />
        ) : (
          <EmptyResult hint="Enter Total Heat Input to calculate efficiency" />
        )}

        <div className="text-xs text-muted-foreground space-y-0.5">
          <p className="font-medium text-foreground/70">Benchmarks:</p>
          <p>
            <span className="text-emerald-600 dark:text-emerald-400">
              {"≥55%"}
            </span>{" "}
            Excellent ·{" "}
            <span className="text-green-600 dark:text-green-400">45–55%</span>{" "}
            Good · <span className="text-destructive">{"<45%"}</span> Poor
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function KilnThermalCalculator() {
  return (
    <div className="bg-background min-h-screen">
      {/* Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            to="/tools"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-5"
            data-ocid="kiln_thermal.back_link"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Tools
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Flame className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Kiln
              </p>
              <h1 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Kiln Thermal Calculator
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground text-sm max-w-2xl mt-2">
            Select a specific calculation below. Each mini-calculator is
            self-contained — enter only the values you have and get an instant
            result with performance benchmarks.
          </p>
        </div>
      </section>

      {/* 2×2 Grid of mini-calculators */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          data-ocid="kiln_thermal.calculators_grid"
        >
          <TotalHeatInputCalc />
          <ExhaustGasHeatLossCalc />
          <RadiationLossCalc />
          <ThermalEfficiencyCalc />
        </div>
      </div>
    </div>
  );
}
