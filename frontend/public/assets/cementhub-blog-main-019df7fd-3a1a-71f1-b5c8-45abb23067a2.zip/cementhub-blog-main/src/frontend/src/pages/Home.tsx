import { ArticleCard } from "@/components/ArticleCard";
import { SearchBar } from "@/components/SearchBar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useLatestArticles, usePopularArticles } from "@/hooks/useArticles";
import { CATEGORY_LABELS } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import { Activity, ArrowRight, Factory, Flame, Leaf, Zap } from "lucide-react";
import { useEffect } from "react";

const CATEGORIES = [
  {
    key: "RawMill",
    icon: Factory,
    description: "Grinding, blending, and feed preparation for kiln processes.",
    border: "border-primary/20",
    bg: "bg-primary/5",
    color: "text-primary",
  },
  {
    key: "CementMill",
    icon: Activity,
    description: "Clinker grinding, separators, and finish mill optimization.",
    border: "border-accent/20",
    bg: "bg-accent/8",
    color: "text-accent-foreground",
  },
  {
    key: "Kiln",
    icon: Flame,
    description:
      "Rotary kiln operations, burning, and clinker quality control.",
    border: "border-destructive/20",
    bg: "bg-destructive/5",
    color: "text-destructive",
  },
  {
    key: "AFR",
    icon: Leaf,
    description:
      "Alternative fuels and raw materials for sustainable production.",
    border: "border-border",
    bg: "bg-secondary",
    color: "text-primary",
  },
  {
    key: "EnergyOptimization",
    icon: Zap,
    description: "Thermal efficiency, power management, and heat recovery.",
    border: "border-primary/15",
    bg: "bg-primary/4",
    color: "text-primary",
  },
] as const;

function ArticleGridSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {["sk1", "sk2", "sk3", "sk4", "sk5", "sk6"].map((key) => (
        <div
          key={key}
          className="rounded-sm border border-border bg-card overflow-hidden"
        >
          <Skeleton className="h-44 w-full" />
          <div className="p-5 space-y-2">
            <Skeleton className="h-3 w-20" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <div className="flex gap-3 pt-1">
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-3 w-20" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const { data: latestArticles, isLoading: latestLoading } =
    useLatestArticles(6);
  const { data: popularArticles, isLoading: popularLoading } =
    usePopularArticles(6);

  useEffect(() => {
    document.title = "CementHub — Cement Engineering Blog";
    const existing = document.querySelector('meta[name="description"]');
    const content =
      "CementHub is a knowledge-sharing platform for cement engineers and plant operators. Technical articles and guides on kiln operations, raw mill, cement mill, AFR, and energy optimization.";
    if (existing) {
      existing.setAttribute("content", content);
    } else {
      const meta = document.createElement("meta");
      meta.name = "description";
      meta.content = content;
      document.head.appendChild(meta);
    }
  }, []);

  function handleCategoryClick(category: string) {
    navigate({
      to: "/articles",
      search: { q: "", category, sort: "date", page: 1 },
    });
  }

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section
        data-ocid="home.hero.section"
        className="bg-card border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <div className="inline-flex items-center gap-2 mb-6 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-semibold text-primary uppercase tracking-widest">
              Engineering Knowledge Hub
            </span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display tracking-tight text-foreground leading-[1.05] max-w-4xl mx-auto mb-6">
            CementHub — <span className="text-primary">Knowledge</span> for
            Cement Engineers
          </h1>

          <p className="text-muted-foreground text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10">
            Technical articles, operational guides, and engineering insights for
            cement plant professionals. Learn, share, and improve.
          </p>

          <div className="flex justify-center mb-8">
            <SearchBar
              variant="hero"
              placeholder="Search articles, case studies, technical insights..."
            />
          </div>

          {/* Category quick chips */}
          <div
            data-ocid="hero.categories.list"
            className="flex flex-wrap justify-center gap-2"
          >
            {CATEGORIES.map((cat) => (
              <button
                key={cat.key}
                type="button"
                data-ocid={`hero.category.${cat.key.toLowerCase()}.toggle`}
                onClick={() => handleCategoryClick(cat.key)}
                className="px-4 py-1.5 rounded-full text-sm font-medium border border-border bg-background text-foreground hover:border-primary/50 hover:bg-primary/5 hover:text-primary transition-smooth cursor-pointer"
              >
                {CATEGORY_LABELS[cat.key]}
              </button>
            ))}
            <button
              type="button"
              data-ocid="hero.all_articles.link"
              onClick={() =>
                navigate({
                  to: "/articles",
                  search: { q: "", category: "", sort: "date", page: 1 },
                })
              }
              className="inline-flex items-center gap-1 px-4 py-1.5 rounded-full text-sm font-medium border border-border bg-background text-muted-foreground hover:text-primary hover:border-primary/50 transition-smooth cursor-pointer"
            >
              All Topics <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section
        data-ocid="home.latest.section"
        className="bg-background py-16 md:py-20"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-article-meta mb-1">Fresh Insights</p>
              <h2 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Latest Articles
              </h2>
            </div>
            <button
              type="button"
              data-ocid="home.latest.view_all.link"
              onClick={() =>
                navigate({
                  to: "/articles",
                  search: { q: "", category: "", sort: "date", page: 1 },
                })
              }
              className="hidden sm:inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
            >
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {latestLoading ? (
            <ArticleGridSkeleton />
          ) : latestArticles && latestArticles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {latestArticles.map((article, i) => (
                <ArticleCard
                  key={article.id.toString()}
                  article={article}
                  index={i}
                />
              ))}
            </div>
          ) : (
            <div
              data-ocid="home.latest.empty_state"
              className="text-center py-16 border border-dashed border-border rounded-sm"
            >
              <Factory className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-muted-foreground font-medium">
                No articles published yet. Check back soon.
              </p>
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <button
              type="button"
              data-ocid="home.latest.view_all_mobile.link"
              onClick={() =>
                navigate({
                  to: "/articles",
                  search: { q: "", category: "", sort: "date", page: 1 },
                })
              }
              className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
            >
              View all articles <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Popular Articles */}
      <section
        data-ocid="home.popular.section"
        className="bg-muted/40 py-16 md:py-20 border-t border-border"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-article-meta mb-1">Most Read</p>
              <h2 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Popular Articles
              </h2>
            </div>
            <button
              type="button"
              data-ocid="home.popular.view_all.link"
              onClick={() =>
                navigate({
                  to: "/articles",
                  search: { q: "", category: "", sort: "date", page: 1 },
                })
              }
              className="hidden sm:flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
            >
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {popularLoading ? (
            <ArticleGridSkeleton />
          ) : popularArticles && popularArticles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {popularArticles.map((article, i) => (
                <ArticleCard
                  key={article.id.toString()}
                  article={article}
                  index={i}
                />
              ))}
            </div>
          ) : (
            <div
              data-ocid="home.popular.empty_state"
              className="text-center py-16 border border-dashed border-border rounded-sm"
            >
              <Activity className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-muted-foreground font-medium">
                Popular articles will appear once content is published.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Browse by Category */}
      <section
        data-ocid="home.categories.section"
        className="bg-background py-16 md:py-20 border-t border-border"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-article-meta mb-1">Explore Topics</p>
            <h2 className="text-2xl md:text-3xl font-bold font-display text-foreground">
              Browse by Category
            </h2>
            <p className="mt-2 text-muted-foreground max-w-xl mx-auto text-sm leading-relaxed">
              Deep-dive into specific areas of cement plant operations and
              engineering.
            </p>
          </div>

          <div
            data-ocid="home.categories.list"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4"
          >
            {CATEGORIES.map((cat, i) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.key}
                  type="button"
                  data-ocid={`home.category.item.${i + 1}`}
                  onClick={() => handleCategoryClick(cat.key)}
                  className={`group flex flex-col items-start text-left p-6 rounded-sm border ${cat.border} ${cat.bg} hover:shadow-md hover:border-primary/40 transition-smooth cursor-pointer w-full`}
                >
                  <div className="w-10 h-10 rounded-sm flex items-center justify-center mb-4 bg-card border border-border">
                    <Icon className={`w-5 h-5 ${cat.color}`} />
                  </div>
                  <h3 className="font-semibold font-display text-foreground text-base leading-snug mb-2 group-hover:text-primary transition-colors">
                    {CATEGORY_LABELS[cat.key]}
                  </h3>
                  <p className="text-muted-foreground text-xs leading-relaxed flex-1">
                    {cat.description}
                  </p>
                  <div className="mt-4 flex items-center gap-1 text-xs font-medium text-primary opacity-0 group-hover:opacity-100 transition-smooth">
                    Browse articles <ArrowRight className="w-3 h-3" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Strip */}
      <section
        data-ocid="home.about.section"
        className="bg-card border-t border-border py-14"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
            <div className="max-w-xl">
              <Badge
                variant="secondary"
                className="mb-3 text-xs tracking-widest uppercase"
              >
                Open Knowledge
              </Badge>
              <h2 className="text-xl md:text-2xl font-bold font-display text-foreground mb-2">
                Built by engineers, for engineers.
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                CementHub is a free, independent knowledge base. No consultancy,
                no paywalls — just well-researched technical content for cement
                plant professionals worldwide.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              <button
                type="button"
                data-ocid="home.cta.browse.button"
                onClick={() =>
                  navigate({
                    to: "/articles",
                    search: { q: "", category: "", sort: "date", page: 1 },
                  })
                }
                className="px-6 py-3 rounded-sm bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-smooth"
              >
                Browse All Articles
              </button>
              <button
                type="button"
                data-ocid="home.cta.tools.button"
                onClick={() => navigate({ to: "/tools" })}
                className="px-6 py-3 rounded-sm border border-border bg-background text-foreground font-semibold text-sm hover:border-primary/50 hover:bg-primary/5 transition-smooth"
              >
                Engineering Tools
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
