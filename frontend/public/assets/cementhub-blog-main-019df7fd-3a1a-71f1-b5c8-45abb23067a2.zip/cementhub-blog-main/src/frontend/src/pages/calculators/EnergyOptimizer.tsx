import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, TrendingDown, TrendingUp, Zap } from "lucide-react";
import { useMemo, useState } from "react";

// ─── Shared helpers ────────────────────────────────────────────────────────────

type BenchmarkLevel = "best" | "good" | "average" | "poor";

const levelStyles: Record<BenchmarkLevel, string> = {
  best: "bg-green-600/15 text-green-700 dark:text-green-400 border-green-600/30",
  good: "bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/30",
  average:
    "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30",
  poor: "bg-destructive/15 text-destructive border-destructive/30",
};

const levelLabels: Record<BenchmarkLevel, string> = {
  best: "Best Practice",
  good: "Good",
  average: "Average",
  poor: "Poor",
};

function getSHCLevel(shc: number): BenchmarkLevel {
  if (shc < 700) return "best";
  if (shc <= 800) return "good";
  if (shc <= 900) return "average";
  return "poor";
}

function getElecLevel(elec: number): BenchmarkLevel {
  if (elec < 90) return "best";
  if (elec <= 100) return "good";
  if (elec <= 110) return "average";
  return "poor";
}

function getOEELevel(oee: number): BenchmarkLevel {
  if (oee > 85) return "best";
  if (oee >= 70) return "average";
  return "poor";
}

function FormulaTag({ formula }: { formula: string }) {
  return (
    <span className="font-mono text-[10px] text-muted-foreground bg-muted/60 rounded px-1.5 py-0.5 leading-snug">
      {formula}
    </span>
  );
}

interface ResultRowProps {
  label: string;
  value: string;
  unit: string;
  formula: string;
  badge?: { level: BenchmarkLevel };
}

function ResultRow({ label, value, unit, formula, badge }: ResultRowProps) {
  return (
    <div className="py-2.5 border-b border-border last:border-0">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">{label}</p>
          <div className="mt-1">
            <FormulaTag formula={formula} />
          </div>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          <span className="text-base font-mono font-bold text-foreground">
            {value}
            <span className="text-xs font-normal text-muted-foreground ml-1">
              {unit}
            </span>
          </span>
          {badge && (
            <Badge className={levelStyles[badge.level]}>
              {levelLabels[badge.level]}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

interface BenchmarkRowProps {
  items: { label: string; range: string; level: BenchmarkLevel }[];
}

function BenchmarkGrid({ items }: BenchmarkRowProps) {
  return (
    <div
      className="grid gap-2 mt-2"
      style={{ gridTemplateColumns: `repeat(${items.length}, 1fr)` }}
    >
      {items.map((b) => (
        <div
          key={b.label}
          className={`rounded p-2 text-center text-[10px] border ${levelStyles[b.level]}`}
        >
          <p className="font-semibold">{b.label}</p>
          <p>{b.range}</p>
        </div>
      ))}
    </div>
  );
}

// ─── Mini-Calc 1: Specific Heat Consumption ────────────────────────────────────

function SHCCalculator() {
  const [fuelEnergy, setFuelEnergy] = useState("1560000");
  const [clinker, setClinker] = useState("2");

  const results = useMemo(() => {
    const fe = Number.parseFloat(fuelEnergy);
    const cl = Number.parseFloat(clinker);
    if (!Number.isFinite(fe) || !Number.isFinite(cl) || cl === 0) return null;

    const shc = fe / cl / 1000;
    const co2 = shc * 0.0000247 * 1000;
    const dailyThermal = (shc * cl * 24 * 1000) / 1_000_000;
    const eil = (shc / 750) * 100;

    return {
      shc: shc.toFixed(1),
      shcRaw: shc,
      co2: co2.toFixed(2),
      dailyThermal: dailyThermal.toFixed(1),
      eil: eil.toFixed(1),
      eilRaw: eil,
      level: getSHCLevel(shc),
    };
  }, [fuelEnergy, clinker]);

  return (
    <Card className="card-elevated" data-ocid="shc_calc.card">
      <CardHeader className="pb-3 flex-row items-start justify-between">
        <div>
          <CardTitle className="text-base font-semibold">
            Specific Heat Consumption (SHC)
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            Calculate thermal energy used per kg of clinker produced
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="shrink-0 ml-2"
          onClick={() => {
            setFuelEnergy("1560000");
            setClinker("2");
          }}
          data-ocid="shc_calc.reset_button"
        >
          Reset
        </Button>
      </CardHeader>

      <CardContent className="space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="shc_fuel_energy">Total Fuel Energy (kcal/h)</Label>
            <Input
              id="shc_fuel_energy"
              type="number"
              min="0"
              value={fuelEnergy}
              onChange={(e) => setFuelEnergy(e.target.value)}
              data-ocid="shc_calc.fuel_energy.input"
            />
            <p className="text-[10px] text-muted-foreground">
              = Fuel (kg/h) × Calorific Value (kcal/kg)
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="shc_clinker">Clinker Production (t/h)</Label>
            <Input
              id="shc_clinker"
              type="number"
              min="0"
              value={clinker}
              onChange={(e) => setClinker(e.target.value)}
              data-ocid="shc_calc.clinker.input"
            />
          </div>
        </div>

        {!results ? (
          <div
            className="py-8 text-center text-sm text-muted-foreground"
            data-ocid="shc_calc.empty_state"
          >
            Enter fuel energy and clinker production to calculate
          </div>
        ) : (
          <div className="space-y-1">
            <ResultRow
              label="Specific Heat Consumption"
              value={results.shc}
              unit="kcal/kg clinker"
              formula="SHC = Fuel Energy (kcal/h) ÷ Clinker (t/h) ÷ 1000"
              badge={{ level: results.level }}
            />
            <ResultRow
              label="CO₂ from Fuel"
              value={results.co2}
              unit="kg CO₂/t clinker"
              formula="CO₂ = SHC × 0.0000247 × 1000  (coal approx.)"
            />
            <ResultRow
              label="Daily Thermal Energy"
              value={results.dailyThermal}
              unit="Gcal/day"
              formula="= SHC × Clinker (t/h) × 24 × 1000 ÷ 1,000,000"
            />
            <div className="py-2.5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm text-muted-foreground">
                    Energy Intensity Index
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <FormulaTag formula="EII = SHC ÷ 750 × 100  (750 = industry benchmark)" />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    &lt; 100 = better than benchmark &nbsp;|&nbsp; &gt; 100 =
                    worse
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {results.eilRaw > 100 ? (
                    <TrendingUp className="h-4 w-4 text-destructive" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-green-600 dark:text-green-400" />
                  )}
                  <span
                    className={`text-2xl font-bold font-mono ${
                      results.eilRaw > 100
                        ? "text-destructive"
                        : "text-green-600 dark:text-green-400"
                    }`}
                  >
                    {results.eil}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-3">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                SHC Benchmarks (kcal/kg clinker)
              </p>
              <BenchmarkGrid
                items={[
                  { label: "Excellent", range: "< 700", level: "best" },
                  { label: "Good", range: "700–800", level: "good" },
                  { label: "Average", range: "800–900", level: "average" },
                  { label: "Poor", range: "> 900", level: "poor" },
                ]}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 2: Electrical Energy & Cost Analysis ───────────────────────────

function ElecCostCalculator() {
  const [totalPower, setTotalPower] = useState("250");
  const [cementOutput, setCementOutput] = useState("2.2");
  const [fuelCostGcal, setFuelCostGcal] = useState("3.5");
  const [elecTariff, setElecTariff] = useState("0.085");
  const [shcInput, setShcInput] = useState("780");

  const results = useMemo(() => {
    const pw = Number.parseFloat(totalPower);
    const co = Number.parseFloat(cementOutput);
    const fc = Number.parseFloat(fuelCostGcal);
    const et = Number.parseFloat(elecTariff);
    const shc = Number.parseFloat(shcInput);

    if (!Number.isFinite(pw) || !Number.isFinite(co) || co === 0) return null;

    const specElec = pw / co;
    // SHC kcal/kg → Gcal/t = shc / 1,000,000 × 1000 = shc / 1000
    const fuelCostPerTon =
      Number.isFinite(shc) && Number.isFinite(fc)
        ? (shc / 1_000_000) * fc * 1000
        : null;
    const elecCostPerTon = Number.isFinite(et) ? specElec * et : null;
    const totalCostPerTon =
      fuelCostPerTon !== null && elecCostPerTon !== null
        ? fuelCostPerTon + elecCostPerTon
        : null;

    return {
      specElec: specElec.toFixed(1),
      specElecRaw: specElec,
      fuelCostPerTon: fuelCostPerTon?.toFixed(3) ?? "—",
      elecCostPerTon: elecCostPerTon?.toFixed(3) ?? "—",
      totalCostPerTon: totalCostPerTon?.toFixed(3) ?? "—",
      level: getElecLevel(specElec),
    };
  }, [totalPower, cementOutput, fuelCostGcal, elecTariff, shcInput]);

  return (
    <Card className="card-elevated" data-ocid="elec_cost_calc.card">
      <CardHeader className="pb-3 flex-row items-start justify-between">
        <div>
          <CardTitle className="text-base font-semibold">
            Electrical Energy &amp; Cost Analysis
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            Calculate energy costs per ton of cement
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="shrink-0 ml-2"
          onClick={() => {
            setTotalPower("250");
            setCementOutput("2.2");
            setFuelCostGcal("3.5");
            setElecTariff("0.085");
            setShcInput("780");
          }}
          data-ocid="elec_cost_calc.reset_button"
        >
          Reset
        </Button>
      </CardHeader>

      <CardContent className="space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="ec_total_power">Total Power Consumed (kWh/h)</Label>
            <Input
              id="ec_total_power"
              type="number"
              min="0"
              value={totalPower}
              onChange={(e) => setTotalPower(e.target.value)}
              data-ocid="elec_cost_calc.total_power.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ec_cement_output">Cement Output (t/h)</Label>
            <Input
              id="ec_cement_output"
              type="number"
              min="0"
              value={cementOutput}
              onChange={(e) => setCementOutput(e.target.value)}
              data-ocid="elec_cost_calc.cement_output.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ec_fuel_cost">Fuel Cost ($/Gcal)</Label>
            <Input
              id="ec_fuel_cost"
              type="number"
              min="0"
              step="0.01"
              value={fuelCostGcal}
              onChange={(e) => setFuelCostGcal(e.target.value)}
              data-ocid="elec_cost_calc.fuel_cost.input"
            />
            <p className="text-[10px] text-muted-foreground">
              Cost per Giga-calorie of fuel
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ec_elec_tariff">Electricity Tariff ($/kWh)</Label>
            <Input
              id="ec_elec_tariff"
              type="number"
              min="0"
              step="0.001"
              value={elecTariff}
              onChange={(e) => setElecTariff(e.target.value)}
              data-ocid="elec_cost_calc.elec_tariff.input"
            />
          </div>
          <div className="col-span-2 space-y-1.5">
            <Label htmlFor="ec_shc_input">
              SHC (kcal/kg) —{" "}
              <span className="font-normal text-muted-foreground">
                from SHC Calculator above
              </span>
            </Label>
            <Input
              id="ec_shc_input"
              type="number"
              min="0"
              value={shcInput}
              onChange={(e) => setShcInput(e.target.value)}
              data-ocid="elec_cost_calc.shc.input"
            />
          </div>
        </div>

        {!results ? (
          <div
            className="py-8 text-center text-sm text-muted-foreground"
            data-ocid="elec_cost_calc.empty_state"
          >
            Enter power and cement output to calculate
          </div>
        ) : (
          <div className="space-y-1">
            <ResultRow
              label="Specific Electrical Energy"
              value={results.specElec}
              unit="kWh/t cement"
              formula="Spec. Elec. = Total Power (kWh/h) ÷ Cement Output (t/h)"
              badge={{ level: results.level }}
            />
            <ResultRow
              label="Fuel Cost per Ton"
              value={results.fuelCostPerTon}
              unit="$/t"
              formula="Fuel Cost/t = (SHC ÷ 1,000,000) × Fuel Cost ($/Gcal) × 1000"
            />
            <ResultRow
              label="Electrical Cost per Ton"
              value={results.elecCostPerTon}
              unit="$/t"
              formula="Elec. Cost/t = Spec. Elec. (kWh/t) × Tariff ($/kWh)"
            />

            <div className="mt-3 rounded-lg bg-muted/30 border border-border overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">
                  🔥 Fuel Energy Cost
                </span>
                <span className="font-mono font-semibold text-foreground text-sm">
                  ${results.fuelCostPerTon} / t
                </span>
              </div>
              <div className="flex items-center justify-between px-3 py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">
                  ⚡ Electrical Energy Cost
                </span>
                <span className="font-mono font-semibold text-foreground text-sm">
                  ${results.elecCostPerTon} / t
                </span>
              </div>
              <div className="flex items-center justify-between px-3 py-2.5 bg-primary/10">
                <span className="text-sm font-semibold text-foreground">
                  Total Energy Cost
                </span>
                <span className="font-mono font-bold text-primary text-lg">
                  ${results.totalCostPerTon} / t
                </span>
              </div>
            </div>

            <div className="pt-3">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                Specific Electrical Benchmarks (kWh/t cement)
              </p>
              <BenchmarkGrid
                items={[
                  { label: "Excellent", range: "< 90", level: "best" },
                  { label: "Good", range: "90–100", level: "good" },
                  { label: "Average", range: "100–110", level: "average" },
                  { label: "Poor", range: "> 110", level: "poor" },
                ]}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 3: OEE & Performance Benchmarking ──────────────────────────────

function OEECalculator() {
  const [availability, setAvailability] = useState("90");
  const [performance, setPerformance] = useState("85");
  const [quality, setQuality] = useState("98");
  const [actualSHC, setActualSHC] = useState("780");
  const [benchSHC, setBenchSHC] = useState("750");

  const results = useMemo(() => {
    const av = Number.parseFloat(availability);
    const pf = Number.parseFloat(performance);
    const ql = Number.parseFloat(quality);
    const shc = Number.parseFloat(actualSHC);
    const bench = Number.parseFloat(benchSHC);

    if (!Number.isFinite(av) || !Number.isFinite(pf) || !Number.isFinite(ql))
      return null;

    const oee = (av * pf * ql) / 10000;
    const eil =
      Number.isFinite(shc) && Number.isFinite(bench) && bench !== 0
        ? (shc / bench) * 100
        : null;

    return {
      oee: oee.toFixed(1),
      oeeRaw: oee,
      eil: eil?.toFixed(1) ?? "—",
      eilRaw: eil,
      oeeLevel: getOEELevel(oee),
    };
  }, [availability, performance, quality, actualSHC, benchSHC]);

  return (
    <Card className="card-elevated" data-ocid="oee_calc.card">
      <CardHeader className="pb-3 flex-row items-start justify-between">
        <div>
          <CardTitle className="text-base font-semibold">
            OEE &amp; Performance Benchmarking
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            Measure overall plant effectiveness and compare to industry
            benchmarks
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="shrink-0 ml-2"
          onClick={() => {
            setAvailability("90");
            setPerformance("85");
            setQuality("98");
            setActualSHC("780");
            setBenchSHC("750");
          }}
          data-ocid="oee_calc.reset_button"
        >
          Reset
        </Button>
      </CardHeader>

      <CardContent className="space-y-5">
        <div className="grid grid-cols-3 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="oee_availability">Availability (%)</Label>
            <Input
              id="oee_availability"
              type="number"
              min="0"
              max="100"
              value={availability}
              onChange={(e) => setAvailability(e.target.value)}
              data-ocid="oee_calc.availability.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="oee_performance">Performance (%)</Label>
            <Input
              id="oee_performance"
              type="number"
              min="0"
              max="100"
              value={performance}
              onChange={(e) => setPerformance(e.target.value)}
              data-ocid="oee_calc.performance.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="oee_quality">Quality (%)</Label>
            <Input
              id="oee_quality"
              type="number"
              min="0"
              max="100"
              value={quality}
              onChange={(e) => setQuality(e.target.value)}
              data-ocid="oee_calc.quality.input"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="oee_actual_shc">
              Actual SHC (kcal/kg) —{" "}
              <span className="font-normal text-muted-foreground text-xs">
                from SHC Calculator
              </span>
            </Label>
            <Input
              id="oee_actual_shc"
              type="number"
              min="0"
              value={actualSHC}
              onChange={(e) => setActualSHC(e.target.value)}
              data-ocid="oee_calc.actual_shc.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="oee_bench_shc">Benchmark SHC (kcal/kg)</Label>
            <Input
              id="oee_bench_shc"
              type="number"
              min="0"
              value={benchSHC}
              onChange={(e) => setBenchSHC(e.target.value)}
              data-ocid="oee_calc.benchmark_shc.input"
            />
            <p className="text-[10px] text-muted-foreground">
              Industry average ≈ 750 | Best practice &lt; 700
            </p>
          </div>
        </div>

        {!results ? (
          <div
            className="py-8 text-center text-sm text-muted-foreground"
            data-ocid="oee_calc.empty_state"
          >
            Enter availability, performance, and quality values to calculate
          </div>
        ) : (
          <div className="space-y-4">
            {/* OEE result with progress bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Overall Equipment Effectiveness (OEE)
                  </p>
                  <div className="mt-1">
                    <FormulaTag formula="OEE = Availability × Performance × Quality ÷ 10,000" />
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-3xl font-bold font-mono text-foreground">
                    {results.oee}%
                  </span>
                  <Badge className={levelStyles[results.oeeLevel]}>
                    {levelLabels[results.oeeLevel]}
                  </Badge>
                </div>
              </div>
              <div className="relative h-4 rounded-full bg-muted overflow-hidden">
                <div
                  className={`absolute left-0 top-0 h-full rounded-full transition-all duration-500 ${
                    results.oeeRaw > 85
                      ? "bg-green-500"
                      : results.oeeRaw >= 70
                        ? "bg-yellow-500"
                        : "bg-destructive"
                  }`}
                  style={{ width: `${Math.min(results.oeeRaw, 100)}%` }}
                />
                {/* 85% marker */}
                <div
                  className="absolute top-0 h-full w-px bg-foreground/40"
                  style={{ left: "85%" }}
                />
              </div>
              <div className="flex justify-between text-[9px] text-muted-foreground">
                <span>0%</span>
                <span>85% (excellent threshold)</span>
                <span>100%</span>
              </div>
            </div>

            {/* Energy Intensity Index with bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Energy Intensity Index (EII)
                  </p>
                  <div className="mt-1">
                    <FormulaTag formula="EII = Actual SHC ÷ Benchmark SHC × 100" />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    &lt; 100 = better than benchmark &nbsp;|&nbsp; &gt; 100 =
                    worse
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {results.eilRaw !== null && results.eilRaw > 100 ? (
                    <TrendingUp className="h-4 w-4 text-destructive" />
                  ) : results.eilRaw !== null ? (
                    <TrendingDown className="h-4 w-4 text-green-600 dark:text-green-400" />
                  ) : null}
                  <span
                    className={`text-3xl font-bold font-mono ${
                      results.eilRaw === null
                        ? "text-muted-foreground"
                        : results.eilRaw > 100
                          ? "text-destructive"
                          : "text-green-600 dark:text-green-400"
                    }`}
                  >
                    {results.eil}
                  </span>
                </div>
              </div>
              {results.eilRaw !== null && (
                <>
                  <div className="relative h-4 rounded-full bg-muted overflow-hidden">
                    <div
                      className={`absolute left-0 top-0 h-full rounded-full transition-all duration-500 ${
                        results.eilRaw > 100 ? "bg-destructive" : "bg-green-500"
                      }`}
                      style={{
                        width: `${Math.min(results.eilRaw, 150) / 1.5}%`,
                      }}
                    />
                    {/* 100% = benchmark marker at 66.67% of bar */}
                    <div
                      className="absolute top-0 h-full w-px bg-foreground/40"
                      style={{ left: "66.67%" }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-muted-foreground">
                    <span>0</span>
                    <span>100 (benchmark)</span>
                    <span>150</span>
                  </div>
                </>
              )}
            </div>

            <div className="pt-1">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                OEE Benchmarks
              </p>
              <BenchmarkGrid
                items={[
                  { label: "Excellent", range: "> 85%", level: "best" },
                  { label: "Average", range: "70–85%", level: "average" },
                  { label: "Poor", range: "< 70%", level: "poor" },
                ]}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function EnergyOptimizer() {
  return (
    <div className="bg-background min-h-screen">
      {/* Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            to="/tools"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-5"
            data-ocid="energy_optimizer.back_link"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Tools
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Energy
              </p>
              <h1 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Energy Optimizer
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground text-sm max-w-2xl mt-2">
            Select a specific calculation below. Each calculator is independent
            — enter only the inputs you have, and get instant results with
            industry benchmarks.
          </p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <SHCCalculator />
        <ElecCostCalculator />
        <OEECalculator />
      </div>
    </div>
  );
}
