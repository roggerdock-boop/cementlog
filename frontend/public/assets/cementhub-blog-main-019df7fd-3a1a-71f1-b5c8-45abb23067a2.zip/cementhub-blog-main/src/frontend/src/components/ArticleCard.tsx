import { cn } from "@/lib/utils";
import type { Article } from "@/types";
import { estimateReadTime, formatDate } from "@/types";
import { Link } from "@tanstack/react-router";
import { Clock, User } from "lucide-react";
import { CategoryBadge } from "./CategoryBadge";

interface ArticleCardProps {
  article: Article;
  className?: string;
  variant?: "default" | "featured" | "compact";
  index?: number;
}

export function ArticleCard({
  article,
  className,
  variant = "default",
  index,
}: ArticleCardProps) {
  const readTime = estimateReadTime(article.content);
  const ocid =
    index !== undefined ? `article.item.${index + 1}` : "article.card";

  if (variant === "compact") {
    return (
      <Link
        to="/articles/$slug"
        params={{ slug: article.slug }}
        data-ocid={ocid}
        className={cn(
          "group flex gap-4 p-4 rounded-sm border border-border bg-card hover:border-primary/30 transition-smooth",
          className,
        )}
      >
        <div className="flex-1 min-w-0">
          <CategoryBadge category={article.category} className="mb-1.5" />
          <h3 className="text-sm font-semibold font-display text-foreground group-hover:text-primary transition-colors line-clamp-2 leading-snug mt-1">
            {article.title}
          </h3>
          <div className="flex items-center gap-3 mt-2 text-muted-foreground text-xs">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {readTime} min read
            </span>
            <span>{formatDate(article.publishDate)}</span>
          </div>
        </div>
      </Link>
    );
  }

  if (variant === "featured") {
    return (
      <Link
        to="/articles/$slug"
        params={{ slug: article.slug }}
        data-ocid={ocid}
        className={cn(
          "group block rounded-sm border border-border bg-card overflow-hidden hover:shadow-md hover:border-primary/30 transition-smooth",
          className,
        )}
      >
        {article.featuredImageUrl && (
          <div className="aspect-[16/7] overflow-hidden bg-muted">
            <img
              src={article.featuredImageUrl}
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </div>
        )}
        <div className="p-6">
          <CategoryBadge category={article.category} size="md" />
          <h2 className="mt-3 text-2xl font-bold font-display text-foreground group-hover:text-primary transition-colors leading-tight line-clamp-3">
            {article.title}
          </h2>
          <p className="mt-2 text-muted-foreground text-sm leading-relaxed line-clamp-3">
            {article.excerpt}
          </p>
          <div className="flex items-center gap-4 mt-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" />
              {article.authorName}
            </span>
            <span>{formatDate(article.publishDate)}</span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              {readTime} min read
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to="/articles/$slug"
      params={{ slug: article.slug }}
      data-ocid={ocid}
      className={cn(
        "group block rounded-sm border border-border bg-card overflow-hidden hover:shadow-md hover:border-primary/30 transition-smooth",
        className,
      )}
    >
      {article.featuredImageUrl && (
        <div className="aspect-video overflow-hidden bg-muted">
          <img
            src={article.featuredImageUrl}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      )}
      <div className="p-5">
        <CategoryBadge category={article.category} />
        <h3 className="mt-2 text-base font-semibold font-display text-foreground group-hover:text-primary transition-colors leading-snug line-clamp-2">
          {article.title}
        </h3>
        <p className="mt-1.5 text-muted-foreground text-sm leading-relaxed line-clamp-2">
          {article.excerpt}
        </p>
        <div className="flex items-center gap-3 mt-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <User className="w-3 h-3" />
            {article.authorName}
          </span>
          <span>{formatDate(article.publishDate)}</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {readTime} min
          </span>
        </div>
      </div>
    </Link>
  );
}
