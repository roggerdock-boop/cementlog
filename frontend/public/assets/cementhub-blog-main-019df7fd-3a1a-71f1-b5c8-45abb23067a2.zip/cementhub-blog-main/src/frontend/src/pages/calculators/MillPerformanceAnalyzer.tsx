import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, BarChart3 } from "lucide-react";
import { useMemo, useState } from "react";

// ─── Shared helpers ──────────────────────────────────────────────────────────

type BenchmarkLevel = "excellent" | "good" | "average" | "poor";

const BADGE_STYLES: Record<BenchmarkLevel, string> = {
  excellent:
    "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30",
  good: "bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30",
  average:
    "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30",
  poor: "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30",
};

function BenchBadge({
  level,
  label,
}: { level: BenchmarkLevel; label: string }) {
  return <Badge className={`${BADGE_STYLES[level]} shrink-0`}>{label}</Badge>;
}

function FormulaTag({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded bg-muted/60 border border-border px-3 py-2 mt-3 text-xs font-mono text-muted-foreground leading-relaxed whitespace-pre-wrap">
      {children}
    </div>
  );
}

function GaugeBar({
  value,
  min,
  max,
  optimalStart,
  optimalEnd,
}: {
  value: number;
  min: number;
  max: number;
  optimalStart: number;
  optimalEnd: number;
}) {
  const clamp = (v: number) => Math.min(100, Math.max(0, v));
  const pct = clamp(((value - min) / (max - min)) * 100);
  const oStart = clamp(((optimalStart - min) / (max - min)) * 100);
  const oEnd = clamp(((optimalEnd - min) / (max - min)) * 100);
  const inZone = value >= optimalStart && value <= optimalEnd;
  return (
    <div className="relative h-4 bg-muted rounded-full overflow-hidden border border-border mt-3">
      <div
        className="absolute top-0 h-full"
        style={{
          left: `${oStart}%`,
          width: `${oEnd - oStart}%`,
          background: "oklch(0.55 0.12 140 / 0.28)",
        }}
      />
      <div
        className={`absolute top-0 left-0 h-full rounded-full transition-all duration-500 ${inZone ? "bg-green-500" : "bg-yellow-500"}`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function ResultValue({
  value,
  unit,
  decimals = 1,
}: {
  value: number;
  unit: string;
  decimals?: number;
}) {
  return (
    <div className="flex items-end gap-1.5">
      <span className="text-3xl font-bold font-mono text-foreground">
        {value.toFixed(decimals)}
      </span>
      <span className="text-base text-muted-foreground mb-0.5">{unit}</span>
    </div>
  );
}

// ─── Mini-Calc 1: Separator Efficiency ──────────────────────────────────────

function SeparatorEfficiencyCalc() {
  const [feedF, setFeedF] = useState("90");
  const [rejectR, setRejectR] = useState("50");
  const [productT, setProductT] = useState("5");

  const result = useMemo(() => {
    const F = Number.parseFloat(feedF);
    const R = Number.parseFloat(rejectR);
    const T = Number.parseFloat(productT);
    if (!Number.isFinite(F) || !Number.isFinite(R) || !Number.isFinite(T))
      return null;
    const denom = F - T;
    if (denom === 0) return null;
    const se = ((F - R) / denom) * 100;
    return Number.isFinite(se) ? se : null;
  }, [feedF, rejectR, productT]);

  function getLevel(v: number): BenchmarkLevel {
    if (v > 70) return "good";
    if (v >= 50) return "average";
    return "poor";
  }

  function getBenchLabel(v: number) {
    if (v > 70) return "Good (>70%)";
    if (v >= 50) return "Average (50–70%)";
    return "Poor (<50%)";
  }

  return (
    <Card className="card-elevated" data-ocid="mill_calc1.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">
          Separator Efficiency
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Evaluate how well the separator classifies fine from coarse particles
        </p>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid grid-cols-3 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="se_F">Feed Fineness F (%)</Label>
            <Input
              id="se_F"
              type="number"
              min="0"
              max="100"
              placeholder="e.g. 90"
              value={feedF}
              onChange={(e) => setFeedF(e.target.value)}
              data-ocid="mill_calc1.feed_fineness.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="se_R">Reject Fineness R (%)</Label>
            <Input
              id="se_R"
              type="number"
              min="0"
              max="100"
              placeholder="e.g. 50"
              value={rejectR}
              onChange={(e) => setRejectR(e.target.value)}
              data-ocid="mill_calc1.reject_fineness.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="se_T">Product Fineness T (%)</Label>
            <Input
              id="se_T"
              type="number"
              min="0"
              max="100"
              placeholder="e.g. 5"
              value={productT}
              onChange={(e) => setProductT(e.target.value)}
              data-ocid="mill_calc1.product_fineness.input"
            />
          </div>
        </div>

        {result !== null ? (
          <div
            className="rounded-lg bg-muted/30 border border-border p-4 space-y-3"
            data-ocid="mill_calc1.result"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-1">
                  Separator Efficiency
                </p>
                <ResultValue value={result} unit="%" />
              </div>
              <BenchBadge
                level={getLevel(result)}
                label={getBenchLabel(result)}
              />
            </div>
            <GaugeBar
              value={result}
              min={0}
              max={100}
              optimalStart={70}
              optimalEnd={95}
            />
            <p className="text-xs text-muted-foreground">
              Good: &gt;70%&nbsp;&nbsp;|&nbsp;&nbsp;Average:
              50–70%&nbsp;&nbsp;|&nbsp;&nbsp;Poor: &lt;50%
            </p>
            <FormulaTag>
              {`SE (%) = (F − R) / (F − T) × 100\n       = (${feedF} − ${rejectR}) / (${feedF} − ${productT}) × 100\n       = ${result.toFixed(2)}%`}
            </FormulaTag>
          </div>
        ) : (
          <div
            className="rounded-lg bg-muted/30 border border-dashed border-border p-6 text-center"
            data-ocid="mill_calc1.empty_state"
          >
            <p className="text-sm text-muted-foreground">
              Enter valid fineness values to see result
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 2: Circulating Load & Specific Energy ────────────────────────

function CircLoadAndSpecificEnergyCalc() {
  const [feedRate, setFeedRate] = useState("180");
  const [productRate, setProductRate] = useState("100");
  const [millPower, setMillPower] = useState("4000");
  const [throughput, setThroughput] = useState("100");

  const results = useMemo(() => {
    const feed = Number.parseFloat(feedRate);
    const product = Number.parseFloat(productRate);
    const power = Number.parseFloat(millPower);
    const tp = Number.parseFloat(throughput);

    const cl =
      Number.isFinite(feed) && Number.isFinite(product) && product > 0
        ? ((feed - product) / product) * 100
        : null;

    const sec =
      Number.isFinite(power) && Number.isFinite(tp) && tp > 0
        ? power / tp
        : null;

    return {
      cl: cl !== null && Number.isFinite(cl) ? cl : null,
      sec: sec !== null && Number.isFinite(sec) ? sec : null,
    };
  }, [feedRate, productRate, millPower, throughput]);

  function getClLevel(v: number): BenchmarkLevel {
    if (v >= 150 && v <= 300) return "good";
    if ((v >= 100 && v < 150) || (v > 300 && v <= 400)) return "average";
    return "poor";
  }

  function getClLabel(v: number) {
    if (v >= 150 && v <= 300) return "Good (150–300%)";
    if (v > 300 && v <= 400) return "High (300–400%)";
    if (v >= 100) return "Low (100–150%)";
    return "Poor (<100%)";
  }

  function getSecLevel(v: number): BenchmarkLevel {
    if (v < 25) return "excellent";
    if (v <= 40) return "good";
    if (v <= 50) return "average";
    return "poor";
  }

  function getSecLabel(v: number) {
    if (v < 25) return "Excellent (<25)";
    if (v <= 40) return "Good (25–40)";
    if (v <= 50) return "Average (40–50)";
    return "Poor (>50)";
  }

  const hasAnyResult = results.cl !== null || results.sec !== null;

  return (
    <Card className="card-elevated" data-ocid="mill_calc2.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">
          Circulating Load &amp; Specific Energy
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Measure internal recirculation and energy consumed per ton of product
        </p>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="cl_feed">Mill Feed Rate (t/h)</Label>
            <Input
              id="cl_feed"
              type="number"
              min="0"
              placeholder="e.g. 180"
              value={feedRate}
              onChange={(e) => setFeedRate(e.target.value)}
              data-ocid="mill_calc2.feed_rate.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cl_product">Mill Product Rate (t/h)</Label>
            <Input
              id="cl_product"
              type="number"
              min="0"
              placeholder="e.g. 100"
              value={productRate}
              onChange={(e) => setProductRate(e.target.value)}
              data-ocid="mill_calc2.product_rate.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cl_power">Mill Power (kW)</Label>
            <Input
              id="cl_power"
              type="number"
              min="0"
              placeholder="e.g. 4000"
              value={millPower}
              onChange={(e) => setMillPower(e.target.value)}
              data-ocid="mill_calc2.mill_power.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cl_throughput">Mill Throughput (t/h)</Label>
            <Input
              id="cl_throughput"
              type="number"
              min="0"
              placeholder="e.g. 100"
              value={throughput}
              onChange={(e) => setThroughput(e.target.value)}
              data-ocid="mill_calc2.throughput.input"
            />
          </div>
        </div>

        {hasAnyResult ? (
          <div
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            data-ocid="mill_calc2.results"
          >
            {/* Circulating Load */}
            {results.cl !== null && (
              <div className="rounded-lg bg-muted/30 border border-border p-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-1">
                      Circulating Load
                    </p>
                    <ResultValue value={results.cl} unit="%" />
                  </div>
                  <BenchBadge
                    level={getClLevel(results.cl)}
                    label={getClLabel(results.cl)}
                  />
                </div>
                <GaugeBar
                  value={results.cl}
                  min={0}
                  max={500}
                  optimalStart={150}
                  optimalEnd={300}
                />
                <p className="text-xs text-muted-foreground">
                  Good: 150–300%&nbsp;|&nbsp;Avg: 100–400%
                </p>
                <FormulaTag>
                  {`CL (%) = (Feed − Product) / Product × 100\n       = (${feedRate} − ${productRate}) / ${productRate} × 100\n       = ${results.cl.toFixed(2)}%`}
                </FormulaTag>
              </div>
            )}

            {/* Specific Energy */}
            {results.sec !== null && (
              <div className="rounded-lg bg-muted/30 border border-border p-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-1">
                      Specific Energy
                    </p>
                    <ResultValue
                      value={results.sec}
                      unit="kWh/t"
                      decimals={2}
                    />
                  </div>
                  <BenchBadge
                    level={getSecLevel(results.sec)}
                    label={getSecLabel(results.sec)}
                  />
                </div>
                <GaugeBar
                  value={results.sec}
                  min={0}
                  max={80}
                  optimalStart={25}
                  optimalEnd={40}
                />
                <p className="text-xs text-muted-foreground">
                  &lt;25 excellent&nbsp;|&nbsp;25–40 good&nbsp;|&nbsp;&gt;50
                  poor
                </p>
                <FormulaTag>
                  {`SEC (kWh/t) = Power (kW) / Throughput (t/h)\n           = ${millPower} / ${throughput}\n           = ${results.sec.toFixed(2)} kWh/t`}
                </FormulaTag>
              </div>
            )}
          </div>
        ) : (
          <div
            className="rounded-lg bg-muted/30 border border-dashed border-border p-6 text-center"
            data-ocid="mill_calc2.empty_state"
          >
            <p className="text-sm text-muted-foreground">
              Enter valid flow rates and power values to see results
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 3: Bond Energy & Grinding Efficiency ─────────────────────────

function BondGrindingCalc() {
  const [wi, setWi] = useState("14");
  const [p80, setP80] = useState("45");
  const [f80, setF80] = useState("2000");
  const [actualSec, setActualSec] = useState("40");

  const results = useMemo(() => {
    const Wi = Number.parseFloat(wi);
    const P80 = Number.parseFloat(p80);
    const F80 = Number.parseFloat(f80);
    const sec = Number.parseFloat(actualSec);

    if (
      !Number.isFinite(Wi) ||
      !Number.isFinite(P80) ||
      !Number.isFinite(F80)
    ) {
      return null;
    }
    if (P80 <= 0 || F80 <= 0) return null;

    const bondEnergy = Wi * (10 / Math.sqrt(P80) - 10 / Math.sqrt(F80));
    const reductionRatio = F80 / P80;
    const grindEff =
      Number.isFinite(sec) && sec > 0 ? (bondEnergy / sec) * 100 : null;

    return {
      bondEnergy: Number.isFinite(bondEnergy) ? bondEnergy : null,
      reductionRatio: Number.isFinite(reductionRatio) ? reductionRatio : null,
      grindEff:
        grindEff !== null && Number.isFinite(grindEff) ? grindEff : null,
      p80Term: (10 / Math.sqrt(P80)).toFixed(4),
      f80Term: (10 / Math.sqrt(F80)).toFixed(4),
    };
  }, [wi, p80, f80, actualSec]);

  function getGeLevel(v: number): BenchmarkLevel {
    if (v > 80) return "good";
    if (v >= 60) return "average";
    return "poor";
  }

  function getGeLabel(v: number) {
    if (v > 80) return "Good (>80%)";
    if (v >= 60) return "Average (60–80%)";
    return "Poor (<60%)";
  }

  return (
    <Card className="card-elevated" data-ocid="mill_calc3.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">
          Bond Energy &amp; Grinding Efficiency
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Calculate theoretical grinding energy and compare to actual
          consumption
        </p>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="be_wi">Bond Work Index Wi (kWh/t)</Label>
            <Input
              id="be_wi"
              type="number"
              min="0"
              placeholder="e.g. 14"
              value={wi}
              onChange={(e) => setWi(e.target.value)}
              data-ocid="mill_calc3.bond_wi.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="be_p80">Product P80 (µm)</Label>
            <Input
              id="be_p80"
              type="number"
              min="0"
              placeholder="e.g. 45"
              value={p80}
              onChange={(e) => setP80(e.target.value)}
              data-ocid="mill_calc3.product_p80.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="be_f80">Feed F80 (µm)</Label>
            <Input
              id="be_f80"
              type="number"
              min="0"
              placeholder="e.g. 2000"
              value={f80}
              onChange={(e) => setF80(e.target.value)}
              data-ocid="mill_calc3.feed_f80.input"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="be_sec">Actual Specific Energy (kWh/t)</Label>
            <Input
              id="be_sec"
              type="number"
              min="0"
              placeholder="e.g. 40"
              value={actualSec}
              onChange={(e) => setActualSec(e.target.value)}
              data-ocid="mill_calc3.actual_sec.input"
            />
          </div>
        </div>

        {results !== null ? (
          <div className="space-y-3" data-ocid="mill_calc3.results">
            {/* Bond Energy */}
            {results.bondEnergy !== null && (
              <div className="rounded-lg bg-muted/30 border border-border p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold text-foreground">
                    Bond Energy (W)
                  </p>
                  <ResultValue
                    value={results.bondEnergy}
                    unit="kWh/t"
                    decimals={3}
                  />
                </div>
                <FormulaTag>
                  {`W = Wi × (10/√P80 − 10/√F80)\n  = ${wi} × (${results.p80Term} − ${results.f80Term})\n  = ${results.bondEnergy.toFixed(3)} kWh/t`}
                </FormulaTag>
              </div>
            )}

            {/* Reduction Ratio */}
            {results.reductionRatio !== null && (
              <div className="rounded-lg bg-muted/30 border border-border p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold text-foreground">
                    Reduction Ratio
                  </p>
                  <div className="flex items-end gap-1">
                    <span className="text-3xl font-bold font-mono text-foreground">
                      {results.reductionRatio.toFixed(1)}
                    </span>
                    <span className="text-base text-muted-foreground mb-0.5">
                      :1
                    </span>
                  </div>
                </div>
                <FormulaTag>
                  {`RR = F80 / P80\n   = ${f80} / ${p80}\n   = ${results.reductionRatio.toFixed(1)} : 1`}
                </FormulaTag>
              </div>
            )}

            {/* Grinding Efficiency */}
            {results.grindEff !== null && (
              <div className="rounded-lg bg-muted/30 border border-border p-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-1">
                      Grinding Efficiency
                    </p>
                    <ResultValue value={results.grindEff} unit="%" />
                  </div>
                  <BenchBadge
                    level={getGeLevel(results.grindEff)}
                    label={getGeLabel(results.grindEff)}
                  />
                </div>
                <GaugeBar
                  value={results.grindEff}
                  min={0}
                  max={150}
                  optimalStart={80}
                  optimalEnd={110}
                />
                <p className="text-xs text-muted-foreground">
                  &gt;80% excellent&nbsp;|&nbsp;60–80% good&nbsp;|&nbsp;&lt;60%
                  poor&nbsp;|&nbsp;&gt;100% better than Bond predicts
                </p>
                <FormulaTag>
                  {`GE (%) = Bond Energy / Actual SEC × 100\n       = ${(results.bondEnergy ?? 0).toFixed(3)} / ${actualSec} × 100\n       = ${results.grindEff.toFixed(2)}%`}
                </FormulaTag>
              </div>
            )}
          </div>
        ) : (
          <div
            className="rounded-lg bg-muted/30 border border-dashed border-border p-6 text-center"
            data-ocid="mill_calc3.empty_state"
          >
            <p className="text-sm text-muted-foreground">
              Enter valid particle size values to see results
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Page ────────────────────────────────────────────────────────────────────

export default function MillPerformanceAnalyzer() {
  return (
    <div className="bg-background min-h-screen">
      {/* Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            to="/tools"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-5"
            data-ocid="mill_analyzer.back_link"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Tools
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <BarChart3 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">
                Cement Mill
              </p>
              <h1 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Mill Performance Analyzer
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground text-sm max-w-2xl mt-2">
            Select a specific calculation below. Each card is self-contained —
            enter only the inputs it needs and get an instant result with
            benchmarks.
          </p>
        </div>
      </section>

      {/* Mini-calculator cards */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <SeparatorEfficiencyCalc />
        <CircLoadAndSpecificEnergyCalc />
        <BondGrindingCalc />
      </div>
    </div>
  );
}
