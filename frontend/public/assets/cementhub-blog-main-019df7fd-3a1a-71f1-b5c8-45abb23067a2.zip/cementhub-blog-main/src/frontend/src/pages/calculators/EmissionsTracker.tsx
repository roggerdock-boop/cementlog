import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "@tanstack/react-router";
import { Activity, ArrowLeft, FlameKindling, Wind } from "lucide-react";
import { useMemo, useState } from "react";

// ─── Shared helpers ────────────────────────────────────────────────────────────

function FormulaTag({ formula }: { formula: string }) {
  return (
    <p className="text-[10px] font-mono bg-muted/60 border border-border rounded px-2 py-1 text-muted-foreground mt-1 leading-snug">
      {formula}
    </p>
  );
}

function ResultRow({
  label,
  value,
  formula,
  green,
}: {
  label: string;
  value: string;
  formula: string;
  green?: boolean;
}) {
  return (
    <div className="border-b border-border last:border-0 pb-3 last:pb-0">
      <div className="flex items-start justify-between gap-2 mb-0.5">
        <span className="text-sm text-muted-foreground leading-snug">
          {label}
        </span>
        <span
          className={`text-sm font-mono font-semibold shrink-0 ${green ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
        >
          {value}
        </span>
      </div>
      <FormulaTag formula={formula} />
    </div>
  );
}

function CompliancePassFail({ pass }: { pass: boolean }) {
  return pass ? (
    <Badge className="bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30 shrink-0">
      PASS
    </Badge>
  ) : (
    <Badge className="bg-destructive/15 text-destructive border-destructive/30 shrink-0">
      FAIL
    </Badge>
  );
}

// ─── Mini-Calc 1: CO₂ Emissions Calculator ────────────────────────────────────

type Co2FuelKey = "coal" | "gas" | "petcoke" | "oil";

const CO2_FUEL_FACTORS: Record<Co2FuelKey, number> = {
  coal: 0.341,
  gas: 0.202,
  petcoke: 0.347,
  oil: 0.279,
};

const CO2_FUEL_LABELS: Record<Co2FuelKey, string> = {
  coal: "Coal — 0.341 kg CO₂/kcal",
  gas: "Natural Gas — 0.202 kg CO₂/kcal",
  petcoke: "Petcoke — 0.347 kg CO₂/kcal",
  oil: "Heavy Oil — 0.279 kg CO₂/kcal",
};

const defaultCO2 = {
  clinkerProduction: "2000",
  caco3Content: "78",
  fuelConsumption: "120",
  fuelType: "coal" as Co2FuelKey,
  afrSubstitutionRate: "0",
};

function CO2Calculator() {
  const [inp, setInp] = useState(defaultCO2);
  const set =
    (key: keyof typeof defaultCO2) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setInp((p) => ({ ...p, [key]: e.target.value }));

  const r = useMemo(() => {
    const clinker = Number.parseFloat(inp.clinkerProduction);
    const caco3 = Number.parseFloat(inp.caco3Content);
    const fuel = Number.parseFloat(inp.fuelConsumption);
    const afr = Number.parseFloat(inp.afrSubstitutionRate) || 0;
    const factor = CO2_FUEL_FACTORS[inp.fuelType as Co2FuelKey] ?? 0.341;

    if (
      !Number.isFinite(clinker) ||
      !Number.isFinite(fuel) ||
      !Number.isFinite(caco3)
    )
      return null;
    if (clinker <= 0 || fuel <= 0) return null;

    const processCO2 = caco3 * 0.44 * 10;
    const fuelCO2 = fuel * factor;
    const totalCO2 = processCO2 + fuelCO2;
    const co2SavedAFR = (afr / 100) * fuelCO2;
    const netCO2 = totalCO2 - co2SavedAFR;
    const dailyCO2 = (clinker * netCO2) / 1000;

    let netBenchmark: "excellent" | "average" | "poor";
    if (netCO2 < 750) netBenchmark = "excellent";
    else if (netCO2 <= 830) netBenchmark = "average";
    else netBenchmark = "poor";

    return {
      processCO2: processCO2.toFixed(1),
      fuelCO2: fuelCO2.toFixed(1),
      totalCO2: totalCO2.toFixed(1),
      co2SavedAFR: co2SavedAFR.toFixed(1),
      netCO2: netCO2.toFixed(1),
      netCO2Num: netCO2,
      dailyCO2: dailyCO2.toFixed(0),
      netBenchmark,
    };
  }, [inp]);

  const benchmarkBadge = r ? (
    r.netBenchmark === "excellent" ? (
      <Badge className="bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30">
        Excellent &lt;750
      </Badge>
    ) : r.netBenchmark === "average" ? (
      <Badge className="bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30">
        Average 750–830
      </Badge>
    ) : (
      <Badge className="bg-destructive/15 text-destructive border-destructive/30">
        Poor &gt;830
      </Badge>
    )
  ) : null;

  return (
    <Card className="card-elevated" data-ocid="co2_calc.card">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold">
              CO₂ Emissions Calculator
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Calculate total CO₂ from process reactions and fuel combustion
            </p>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Inputs */}
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Inputs
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setInp(defaultCO2)}
                data-ocid="co2_calc.reset_button"
              >
                Reset
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="co2-clinker">Clinker Production (t/day)</Label>
                <Input
                  id="co2-clinker"
                  type="number"
                  min="0"
                  value={inp.clinkerProduction}
                  onChange={set("clinkerProduction")}
                  data-ocid="co2_calc.clinker.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="co2-caco3">CaCO₃ Content of Raw Meal (%)</Label>
                <Input
                  id="co2-caco3"
                  type="number"
                  min="0"
                  max="100"
                  value={inp.caco3Content}
                  onChange={set("caco3Content")}
                  data-ocid="co2_calc.caco3.input"
                />
                <p className="text-[10px] text-muted-foreground">
                  Default: 78%
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="co2-fueltype">Fuel Type</Label>
                <select
                  id="co2-fueltype"
                  value={inp.fuelType}
                  onChange={set("fuelType")}
                  data-ocid="co2_calc.fuel_type.select"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {(Object.keys(CO2_FUEL_LABELS) as Co2FuelKey[]).map((k) => (
                    <option key={k} value={k}>
                      {CO2_FUEL_LABELS[k]}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="co2-fuelcons">
                  Fuel Consumption (kg/t clinker)
                </Label>
                <Input
                  id="co2-fuelcons"
                  type="number"
                  min="0"
                  value={inp.fuelConsumption}
                  onChange={set("fuelConsumption")}
                  data-ocid="co2_calc.fuel_consumption.input"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="co2-afr">
                AFR Substitution Rate (%) — leave 0 if no AFR
              </Label>
              <Input
                id="co2-afr"
                type="number"
                min="0"
                max="100"
                value={inp.afrSubstitutionRate}
                onChange={set("afrSubstitutionRate")}
                data-ocid="co2_calc.afr_rate.input"
              />
            </div>
          </div>

          {/* Results */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
              Results
            </p>
            {!r ? (
              <div
                className="py-12 flex flex-col items-center gap-2 text-center"
                data-ocid="co2_calc.empty_state"
              >
                <Activity className="h-9 w-9 text-muted-foreground/30" />
                <p className="text-sm text-muted-foreground">
                  Enter valid production data
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-end gap-2 p-3 bg-muted/40 rounded-lg border border-border">
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">
                      Net CO₂ Emission
                    </p>
                    <div className="flex items-end gap-1.5">
                      <span className="text-4xl font-bold font-mono text-foreground">
                        {r.netCO2}
                      </span>
                      <span className="text-sm text-muted-foreground mb-1">
                        kg/t clinker
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      EU ETS average ~812 kg/t
                    </p>
                  </div>
                  {benchmarkBadge}
                </div>
                <div className="space-y-3">
                  <ResultRow
                    label="Process CO₂ (decarbonation)"
                    value={`${r.processCO2} kg/t`}
                    formula="CaCO₃ Content (%) × 0.44 × 10"
                  />
                  <ResultRow
                    label="Fuel CO₂"
                    value={`${r.fuelCO2} kg/t`}
                    formula="Fuel Consumption (kg/t) × CO₂ Factor (kg CO₂/kcal)"
                  />
                  <ResultRow
                    label="Total CO₂"
                    value={`${r.totalCO2} kg/t`}
                    formula="Process CO₂ + Fuel CO₂"
                  />
                  <ResultRow
                    label="CO₂ Saved via AFR"
                    value={`−${r.co2SavedAFR} kg/t`}
                    formula="AFR Rate (%) × Fuel CO₂ / 100"
                    green={Number(r.co2SavedAFR) > 0}
                  />
                  <ResultRow
                    label="Daily CO₂ Emissions"
                    value={`${Number(r.dailyCO2).toLocaleString()} t CO₂/day`}
                    formula="Clinker Production (t/day) × Net CO₂ / 1000"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 2: Stack Emissions Compliance ──────────────────────────────────

const BAT_LIMITS = { nox: 500, so2: 50, dust: 10 };

const defaultStack = {
  flueGasVolume: "1500",
  noxMeasured: "180",
  so2Measured: "35",
  dustEmission: "8",
};

function StackComplianceCalculator() {
  const [inp, setInp] = useState(defaultStack);
  const set =
    (key: keyof typeof defaultStack) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setInp((p) => ({ ...p, [key]: e.target.value }));

  const r = useMemo(() => {
    const fgv = Number.parseFloat(inp.flueGasVolume);
    const nox = Number.parseFloat(inp.noxMeasured);
    const so2 = Number.parseFloat(inp.so2Measured);
    const dust = Number.parseFloat(inp.dustEmission);

    if (
      !Number.isFinite(fgv) ||
      !Number.isFinite(nox) ||
      !Number.isFinite(so2) ||
      !Number.isFinite(dust)
    )
      return null;
    if (fgv <= 0) return null;

    const noxKgT = (nox * fgv) / 1_000_000;
    const so2KgT = (so2 * fgv) / 1_000_000;
    const dustKgT = (dust * fgv) / 1_000_000;

    const noxPass = nox <= BAT_LIMITS.nox;
    const so2Pass = so2 <= BAT_LIMITS.so2;
    const dustPass = dust <= BAT_LIMITS.dust;
    const allPass = noxPass && so2Pass && dustPass;

    return {
      nox,
      so2,
      dust,
      noxKgT: noxKgT.toFixed(3),
      so2KgT: so2KgT.toFixed(3),
      dustKgT: dustKgT.toFixed(3),
      noxPass,
      so2Pass,
      dustPass,
      allPass,
    };
  }, [inp]);

  const pollutants = [
    {
      key: "nox" as const,
      label: "NOx",
      measured: r?.nox ?? 0,
      limit: BAT_LIMITS.nox,
      kgT: r?.noxKgT ?? "—",
      pass: r?.noxPass ?? false,
      inputKey: "noxMeasured" as const,
      ocid: "stack.nox.input",
    },
    {
      key: "so2" as const,
      label: "SO₂",
      measured: r?.so2 ?? 0,
      limit: BAT_LIMITS.so2,
      kgT: r?.so2KgT ?? "—",
      pass: r?.so2Pass ?? false,
      inputKey: "so2Measured" as const,
      ocid: "stack.so2.input",
    },
    {
      key: "dust" as const,
      label: "Dust",
      measured: r?.dust ?? 0,
      limit: BAT_LIMITS.dust,
      kgT: r?.dustKgT ?? "—",
      pass: r?.dustPass ?? false,
      inputKey: "dustEmission" as const,
      ocid: "stack.dust.input",
    },
  ];

  return (
    <Card className="card-elevated" data-ocid="stack.card">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-8 h-8 rounded-md bg-accent/20 flex items-center justify-center">
            <Wind className="h-4 w-4 text-accent-foreground" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold">
              Stack Emissions Compliance
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Check NOx, SO₂, and dust emissions against EU BAT regulatory
              limits
            </p>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Inputs */}
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Inputs
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setInp(defaultStack)}
                data-ocid="stack.reset_button"
              >
                Reset
              </Button>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stack-fgv">Flue Gas Volume (Nm³/t clinker)</Label>
              <Input
                id="stack-fgv"
                type="number"
                min="0"
                value={inp.flueGasVolume}
                onChange={set("flueGasVolume")}
                data-ocid="stack.flue_gas.input"
              />
              <p className="text-[10px] text-muted-foreground">
                Default: 1,500 Nm³/t clinker
              </p>
            </div>
            <div className="border-t border-border pt-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
                Stack Measurements (mg/Nm³)
              </p>
              <div className="space-y-3">
                {pollutants.map((p) => (
                  <div key={p.key} className="space-y-1.5">
                    <Label htmlFor={`stack-${p.key}`}>
                      {p.label} Measured (mg/Nm³)
                    </Label>
                    <Input
                      id={`stack-${p.key}`}
                      type="number"
                      min="0"
                      value={inp[p.inputKey]}
                      onChange={set(p.inputKey)}
                      data-ocid={p.ocid}
                    />
                    <p className="text-[10px] text-muted-foreground">
                      EU BAT limit: &lt;{p.limit} mg/Nm³
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Results */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
              Compliance Results
            </p>
            {!r ? (
              <div
                className="py-12 flex flex-col items-center gap-2 text-center"
                data-ocid="stack.empty_state"
              >
                <Wind className="h-9 w-9 text-muted-foreground/30" />
                <p className="text-sm text-muted-foreground">
                  Enter stack measurement data
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {pollutants.map((p) => {
                  const pct = (p.measured / p.limit) * 100;
                  const barColor =
                    pct <= 70
                      ? "bg-green-500"
                      : pct <= 100
                        ? "bg-yellow-500"
                        : "bg-destructive";
                  return (
                    <div key={p.key} className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">
                          {p.label}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono text-foreground">
                            {p.measured} mg/Nm³
                          </span>
                          <CompliancePassFail pass={p.pass} />
                        </div>
                      </div>
                      <div className="h-2.5 bg-muted rounded-full overflow-hidden border border-border">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                          style={{ width: `${Math.min(100, pct)}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-muted-foreground">
                        <span>{p.kgT} kg/t clinker</span>
                        <span>BAT: {p.limit} mg/Nm³</span>
                      </div>
                      <FormulaTag
                        formula={`${p.label} (kg/t clinker) = Measured (mg/Nm³) × Flue Gas Volume (Nm³/t) / 1,000,000`}
                      />
                    </div>
                  );
                })}
                <div
                  className={`mt-4 p-3 rounded-lg border text-sm font-semibold text-center ${r.allPass ? "bg-green-500/10 border-green-500/30 text-green-700 dark:text-green-400" : "bg-destructive/10 border-destructive/30 text-destructive"}`}
                  data-ocid="stack.compliance_summary"
                >
                  {r.allPass
                    ? "✓ All pollutants within EU BAT limits"
                    : "✗ One or more pollutants exceed EU BAT limits"}
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Mini-Calc 3: AFR Substitution Rate Calculator ────────────────────────────

type AfrFuelKey = "coal" | "petcoke" | "oil";

const AFR_CO2_FACTORS: Record<AfrFuelKey, number> = {
  coal: 0.341,
  petcoke: 0.347,
  oil: 0.279,
};

const AFR_FUEL_LABELS: Record<AfrFuelKey, string> = {
  coal: "Coal — 0.341 t CO₂/t fuel",
  petcoke: "Petcoke — 0.347 t CO₂/t fuel",
  oil: "Heavy Oil — 0.279 t CO₂/t fuel",
};

const defaultAFR = {
  afrFeedRate: "5",
  afrNCV: "3500",
  totalHeatRequired: "50000000",
  currentFossilFuel: "8.5",
  fossilFuelType: "coal" as AfrFuelKey,
  fossilFuelCV: "6000",
};

function AFRSubstitutionCalculator() {
  const [inp, setInp] = useState(defaultAFR);
  const set =
    (key: keyof typeof defaultAFR) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setInp((p) => ({ ...p, [key]: e.target.value }));

  const r = useMemo(() => {
    const afrFeedRate = Number.parseFloat(inp.afrFeedRate);
    const afrNCV = Number.parseFloat(inp.afrNCV);
    const totalHeatReq = Number.parseFloat(inp.totalHeatRequired);
    const currentFossil = Number.parseFloat(inp.currentFossilFuel);
    const fossilCV = Number.parseFloat(inp.fossilFuelCV);
    const co2Factor =
      AFR_CO2_FACTORS[inp.fossilFuelType as AfrFuelKey] ?? 0.341;

    if (
      !Number.isFinite(afrFeedRate) ||
      !Number.isFinite(afrNCV) ||
      !Number.isFinite(totalHeatReq) ||
      !Number.isFinite(currentFossil) ||
      !Number.isFinite(fossilCV)
    )
      return null;
    if (afrFeedRate <= 0 || afrNCV <= 0 || totalHeatReq <= 0 || fossilCV <= 0)
      return null;

    const afrHeatInput = afrFeedRate * afrNCV * 1000;
    const tsr = (afrHeatInput / totalHeatReq) * 100;
    const remainingFossil = (totalHeatReq - afrHeatInput) / fossilCV / 1000;
    const fossilSaved = currentFossil - remainingFossil;
    const co2ReductionHour = fossilSaved * co2Factor;
    const co2ReductionYear = co2ReductionHour * 8760;
    const afrMassRate =
      (afrFeedRate / (afrFeedRate + Math.max(0, remainingFossil))) * 100;

    let tsrZone: "low" | "moderate" | "advanced";
    if (tsr < 10) tsrZone = "low";
    else if (tsr <= 25) tsrZone = "moderate";
    else tsrZone = "advanced";

    return {
      afrHeatInput: afrHeatInput.toFixed(0),
      tsr: tsr.toFixed(2),
      tsrNum: tsr,
      tsrZone,
      remainingFossil: remainingFossil.toFixed(3),
      fossilSaved: fossilSaved.toFixed(3),
      fossilSavedNum: fossilSaved,
      co2ReductionHour: co2ReductionHour.toFixed(3),
      co2ReductionHourNum: co2ReductionHour,
      co2ReductionYear: co2ReductionYear.toFixed(0),
      co2ReductionYearNum: co2ReductionYear,
      afrMassRate: afrMassRate.toFixed(2),
      co2Factor,
    };
  }, [inp]);

  const tsrBarColor = !r
    ? "bg-muted"
    : r.tsrZone === "advanced"
      ? "bg-green-500"
      : r.tsrZone === "moderate"
        ? "bg-yellow-500"
        : "bg-destructive";
  const tsrBadge = r ? (
    r.tsrZone === "advanced" ? (
      <Badge className="bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30">
        Advanced &gt;25%
      </Badge>
    ) : r.tsrZone === "moderate" ? (
      <Badge className="bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30">
        Moderate 10–25%
      </Badge>
    ) : (
      <Badge className="bg-destructive/15 text-destructive border-destructive/30">
        Low &lt;10%
      </Badge>
    )
  ) : null;

  return (
    <Card className="card-elevated" data-ocid="afr_calc.card">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-8 h-8 rounded-md bg-green-500/15 flex items-center justify-center">
            <FlameKindling className="h-4 w-4 text-green-700 dark:text-green-400" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold">
              AFR Substitution Rate Calculator
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Calculate thermal substitution, fossil fuel savings, and CO₂
              reduction from alternative fuels
            </p>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Inputs */}
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Inputs
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setInp(defaultAFR)}
                data-ocid="afr_calc.reset_button"
              >
                Reset
              </Button>
            </div>
            <div className="border-b border-border pb-4 space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Alternative Fuel (AFR)
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="afr-feedrate">AFR Feed Rate (t/h)</Label>
                  <Input
                    id="afr-feedrate"
                    type="number"
                    min="0"
                    step="0.1"
                    value={inp.afrFeedRate}
                    onChange={set("afrFeedRate")}
                    data-ocid="afr_calc.feed_rate.input"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="afr-ncv">
                    AFR Net Calorific Value (kcal/kg)
                  </Label>
                  <Input
                    id="afr-ncv"
                    type="number"
                    min="0"
                    value={inp.afrNCV}
                    onChange={set("afrNCV")}
                    data-ocid="afr_calc.ncv.input"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Typical: 2,000–5,000 kcal/kg
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="afr-totalheat">
                Total Heat Required by Kiln (kcal/h)
              </Label>
              <Input
                id="afr-totalheat"
                type="number"
                min="0"
                value={inp.totalHeatRequired}
                onChange={set("totalHeatRequired")}
                data-ocid="afr_calc.total_heat.input"
              />
              <p className="text-[10px] text-muted-foreground">
                2,000 t/day kiln ≈ 50,000,000 kcal/h
              </p>
            </div>
            <div className="border-t border-border pt-4 space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Fossil Fuel (Primary)
              </p>
              <div className="space-y-1.5">
                <Label htmlFor="afr-fueltype">Fossil Fuel Type</Label>
                <select
                  id="afr-fueltype"
                  value={inp.fossilFuelType}
                  onChange={set("fossilFuelType")}
                  data-ocid="afr_calc.fossil_type.select"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {(Object.keys(AFR_FUEL_LABELS) as AfrFuelKey[]).map((k) => (
                    <option key={k} value={k}>
                      {AFR_FUEL_LABELS[k]}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="afr-fossilcv">Fossil Fuel CV (kcal/kg)</Label>
                  <Input
                    id="afr-fossilcv"
                    type="number"
                    min="0"
                    value={inp.fossilFuelCV}
                    onChange={set("fossilFuelCV")}
                    data-ocid="afr_calc.fossil_cv.input"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Coal ≈ 6,000 | Petcoke ≈ 8,000
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="afr-currentfossil">
                    Current Fossil Feed (t/h)
                  </Label>
                  <Input
                    id="afr-currentfossil"
                    type="number"
                    min="0"
                    step="0.1"
                    value={inp.currentFossilFuel}
                    onChange={set("currentFossilFuel")}
                    data-ocid="afr_calc.current_fossil.input"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Actual usage before AFR
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
              Results
            </p>
            {!r ? (
              <div
                className="py-12 flex flex-col items-center gap-2 text-center"
                data-ocid="afr_calc.empty_state"
              >
                <FlameKindling className="h-9 w-9 text-muted-foreground/30" />
                <p className="text-sm text-muted-foreground">
                  Fill all inputs to compute AFR analysis
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* TSR hero bar */}
                <div
                  className="p-3 bg-muted/40 rounded-lg border border-border"
                  data-ocid="afr_calc.tsr_hero"
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs text-muted-foreground">
                      Thermal Substitution Rate (TSR)
                    </p>
                    {tsrBadge}
                  </div>
                  <div className="flex items-end gap-1.5 mb-2">
                    <span className="text-4xl font-bold font-mono text-primary">
                      {r.tsr}
                    </span>
                    <span className="text-sm text-muted-foreground mb-1">
                      %
                    </span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden border border-border mb-1">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${tsrBarColor}`}
                      style={{ width: `${Math.min(100, r.tsrNum)}%` }}
                      data-ocid="afr_calc.tsr_bar"
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-muted-foreground">
                    <span>Low &lt;10%</span>
                    <span>Moderate 10–25%</span>
                    <span>Advanced &gt;25%</span>
                  </div>
                  <FormulaTag formula="TSR (%) = (AFR Heat Input / Total Heat Input) × 100" />
                </div>

                {/* All result rows */}
                <div className="space-y-3">
                  <ResultRow
                    label="AFR Heat Input"
                    value={`${Number(r.afrHeatInput).toLocaleString()} kcal/h`}
                    formula="AFR Feed Rate (t/h) × AFR NCV (kcal/kg) × 1,000"
                  />
                  <ResultRow
                    label="Remaining Fossil Fuel Required"
                    value={`${r.remainingFossil} t/h`}
                    formula="(Total Heat − AFR Heat Input) / Fossil Fuel CV (kcal/kg) / 1,000"
                  />
                  <ResultRow
                    label="Fossil Fuel Saved"
                    value={`${r.fossilSaved} t/h`}
                    formula="Current Fossil Fuel − Remaining Fossil Fuel"
                    green={r.fossilSavedNum > 0}
                  />
                  <ResultRow
                    label="CO₂ Reduction (hourly)"
                    value={`${r.co2ReductionHour} t CO₂/h`}
                    formula={`Fossil Fuel Saved × CO₂ Factor (${r.co2Factor} t CO₂/t fuel)`}
                    green={r.co2ReductionHourNum > 0}
                  />
                  <ResultRow
                    label="Annual CO₂ Reduction"
                    value={`${Number(r.co2ReductionYear).toLocaleString()} t CO₂/year`}
                    formula="CO₂ Reduction (t/h) × 8,760 hours/year"
                    green={r.co2ReductionYearNum > 0}
                  />
                  <ResultRow
                    label="AFR Mass Substitution Rate"
                    value={`${r.afrMassRate} %`}
                    formula="AFR Feed Rate / (AFR Feed Rate + Remaining Fossil Fuel) × 100"
                  />
                </div>

                {/* Benchmark reference */}
                <div className="p-3 bg-muted/30 rounded-lg border border-border space-y-1.5">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Industry Benchmarks
                  </p>
                  {[
                    {
                      label: "Industry Average TSR",
                      range: "10–25%",
                      cls: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400",
                    },
                    {
                      label: "Advanced Plant TSR",
                      range: ">25%",
                      cls: "bg-green-500/15 text-green-700 dark:text-green-400",
                    },
                    {
                      label: "Practical limit (no major changes)",
                      range: "30–40%",
                      cls: "bg-muted text-muted-foreground",
                    },
                    {
                      label: "Full substitution (possible)",
                      range: "up to 60%",
                      cls: "bg-primary/10 text-primary",
                    },
                  ].map((b) => (
                    <div
                      key={b.label}
                      className="flex items-center justify-between text-xs"
                    >
                      <span className="text-muted-foreground">{b.label}</span>
                      <span
                        className={`font-mono font-semibold px-2 py-0.5 rounded-full border ${b.cls}`}
                      >
                        {b.range}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Page shell ────────────────────────────────────────────────────────────────

export default function EmissionsTracker() {
  return (
    <div className="bg-background min-h-screen">
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            to="/tools"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-5"
            data-ocid="emissions.back_link"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Tools
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                AFR &amp; Emissions
              </p>
              <h1 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Emissions Tracker
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground text-sm max-w-2xl mt-2">
            Select a specific calculation below
          </p>
        </div>
      </section>

      <div
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10"
        data-ocid="emissions_tracker.page"
      >
        <CO2Calculator />
        <StackComplianceCalculator />
        <AFRSubstitutionCalculator />
      </div>
    </div>
  );
}
