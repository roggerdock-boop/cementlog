import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Link } from "@tanstack/react-router";
import {
  Activity,
  BarChart3,
  Flame,
  FlaskConical,
  Mail,
  Zap,
} from "lucide-react";
import { useEffect } from "react";

interface ToolCard {
  icon: React.ReactNode;
  name: string;
  description: string;
  category: string;
  href: string;
}

const TOOLS: ToolCard[] = [
  {
    icon: <Flame className="h-7 w-7 text-primary" />,
    name: "Kiln Thermal Calculator",
    description:
      "Perform detailed heat balance calculations and evaluate thermal efficiency across your rotary kiln system. Identify heat losses and benchmark against industry standards.",
    category: "Kiln",
    href: "/tools/kiln-thermal",
  },
  {
    icon: <FlaskConical className="h-7 w-7 text-primary" />,
    name: "Raw Mix Designer",
    description:
      "Calculate raw material blending proportions, LSF, silica ratio, and alumina ratio to achieve target clinker chemistry. Includes Bogue clinker phase calculations.",
    category: "Raw Mill",
    href: "/tools/raw-mix",
  },
  {
    icon: <Zap className="h-7 w-7 text-primary" />,
    name: "Energy Optimizer",
    description:
      "Benchmark specific heat consumption and electrical energy usage against best-in-class cement plants. Pinpoint energy waste areas with KPI comparison charts.",
    category: "Energy",
    href: "/tools/energy-optimizer",
  },
  {
    icon: <BarChart3 className="h-7 w-7 text-primary" />,
    name: "Mill Performance Analyzer",
    description:
      "Evaluate separator efficiency, circulating load, and grinding metrics for ball mills. Diagnose bottlenecks with visual gauge indicators and benchmark ratings.",
    category: "Cement Mill",
    href: "/tools/mill-performance",
  },
  {
    icon: <Activity className="h-7 w-7 text-primary" />,
    name: "Emissions Tracker",
    description:
      "Track and report CO₂, NOx, and SO₂ emissions from your cement production line. Color-coded compliance reporting against EU BAT reference limits.",
    category: "AFR",
    href: "/tools/emissions-tracker",
  },
];

export default function Tools() {
  useEffect(() => {
    document.title = "Tools — CementHub";
    const metaDesc = document.querySelector('meta[name="description"]');
    const content =
      "Free engineering calculators and tools for cement plant optimization — kiln thermal balance, raw mix design, energy benchmarking, mill analysis, and emissions tracking.";
    if (metaDesc) {
      metaDesc.setAttribute("content", content);
    } else {
      const meta = document.createElement("meta");
      meta.name = "description";
      meta.content = content;
      document.head.appendChild(meta);
    }
  }, []);

  return (
    <div className="bg-background min-h-screen">
      {/* Page Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 md:py-20">
          <div className="max-w-2xl">
            <p className="text-article-meta mb-3">Engineering Resources</p>
            <h1 className="text-article-title mb-4">Engineering Tools</h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Practical calculators and tools for cement plant optimization
            </p>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          data-ocid="tools.list"
        >
          {TOOLS.map((tool, index) => (
            <Card
              key={tool.name}
              className="card-elevated flex flex-col hover:shadow-md transition-smooth"
              data-ocid={`tools.item.${index + 1}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/15 flex items-center justify-center flex-shrink-0">
                    {tool.icon}
                  </div>
                  <Badge
                    className="bg-accent/10 text-accent-foreground border border-accent/20 hover:bg-accent/10 font-semibold text-xs"
                    data-ocid={`tools.active_badge.${index + 1}`}
                  >
                    Active
                  </Badge>
                </div>
                <h3 className="font-display text-lg font-bold text-foreground leading-snug">
                  {tool.name}
                </h3>
                <span className="badge-category w-fit">{tool.category}</span>
              </CardHeader>

              <CardContent className="flex flex-col flex-1 pt-0">
                <p className="text-muted-foreground text-sm leading-relaxed flex-1 mb-5">
                  {tool.description}
                </p>

                <Link
                  to={tool.href}
                  data-ocid={`tools.launch_button.${index + 1}`}
                >
                  <Button className="w-full" variant="default">
                    Open Calculator
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Suggest a Tool */}
      <section
        className="bg-muted/40 border-t border-border"
        data-ocid="tools.suggest_section"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
          <div className="max-w-xl mx-auto text-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Mail className="h-6 w-6 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-bold text-foreground mb-3">
              Suggest a Tool
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed mb-6">
              Have a specific calculator or engineering tool in mind? We build
              based on what the community needs most. Share your idea and help
              shape what we develop next.
            </p>
            <a
              href="mailto:tools@cementhub.com?subject=Tool%20Suggestion"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-primary text-primary-foreground font-semibold text-sm transition-smooth hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              data-ocid="tools.suggest_link"
            >
              <Mail className="h-4 w-4" />
              tools@cementhub.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
