import { cn } from "@/lib/utils";
import { useNavigate } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface SearchBarProps {
  placeholder?: string;
  className?: string;
  defaultValue?: string;
  onSearch?: (query: string) => void;
  variant?: "hero" | "default";
  focusOnMount?: boolean;
}

export function SearchBar({
  placeholder = "Search articles, guides, technical insights...",
  className,
  defaultValue = "",
  onSearch,
  variant = "default",
  focusOnMount,
}: SearchBarProps) {
  const [value, setValue] = useState(defaultValue);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setValue(defaultValue);
  }, [defaultValue]);

  useEffect(() => {
    if (focusOnMount) {
      inputRef.current?.focus();
    }
  }, [focusOnMount]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const q = value.trim();
    if (!q) return;
    if (onSearch) {
      onSearch(q);
    } else {
      navigate({
        to: "/articles",
        search: { q, category: "", sort: "date", page: 1 },
      });
    }
  }

  function handleClear() {
    setValue("");
    inputRef.current?.focus();
    if (onSearch) onSearch("");
  }

  return (
    <form
      onSubmit={handleSubmit}
      className={cn(
        "relative flex items-center group",
        variant === "hero" ? "max-w-2xl w-full" : "w-full",
        className,
      )}
    >
      <Search
        className={cn(
          "absolute left-4 pointer-events-none text-muted-foreground transition-smooth",
          variant === "hero" ? "w-5 h-5" : "w-4 h-4",
        )}
      />
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder}
        data-ocid="search.input"
        className={cn(
          "w-full bg-card border border-border rounded-sm text-foreground placeholder:text-muted-foreground",
          "focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-smooth",
          variant === "hero"
            ? "pl-12 pr-16 py-4 text-base shadow-sm"
            : "pl-10 pr-10 py-2.5 text-sm",
        )}
      />
      {value && (
        <button
          type="button"
          onClick={handleClear}
          data-ocid="search.clear_button"
          className="absolute right-12 text-muted-foreground hover:text-foreground transition-smooth"
        >
          <X className="w-4 h-4" />
        </button>
      )}
      <button
        type="submit"
        data-ocid="search.submit_button"
        aria-label="Search articles"
        className={cn(
          "absolute right-0 flex items-center justify-center font-medium text-sm transition-smooth",
          variant === "hero"
            ? "right-1 top-1 bottom-1 px-5 bg-primary text-primary-foreground rounded-sm hover:bg-primary/90"
            : "right-2 text-muted-foreground hover:text-primary px-2 py-1.5",
        )}
      >
        {variant === "hero" ? "Search" : <Search className="w-4 h-4" />}
      </button>
    </form>
  );
}
