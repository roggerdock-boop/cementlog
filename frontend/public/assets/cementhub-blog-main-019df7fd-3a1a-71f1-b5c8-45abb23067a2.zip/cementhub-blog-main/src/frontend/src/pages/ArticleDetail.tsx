import { ArticleCard } from "@/components/ArticleCard";
import { CategoryBadge } from "@/components/CategoryBadge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useArticleBySlug,
  useIncrementViewCount,
  useLatestArticles,
} from "@/hooks/useArticles";
import { CATEGORY_LABELS, estimateReadTime, formatDate } from "@/types";
import { Link, useParams } from "@tanstack/react-router";
import {
  Calendar,
  ChevronDown,
  ChevronRight,
  Clock,
  Copy,
  Eye,
  RefreshCw,
  User,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

// ── Table of Contents helpers ─────────────────────────────────────────────────

interface TocItem {
  id: string;
  text: string;
  level: number;
}

function extractToc(html: string): TocItem[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const headings = doc.querySelectorAll("h2, h3");
  const items: TocItem[] = [];
  for (const h of Array.from(headings)) {
    const text = h.textContent?.trim() ?? "";
    const level = h.tagName === "H2" ? 2 : 3;
    const id = text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
    items.push({ id, text, level });
  }
  return items;
}

function addAnchorIds(html: string): string {
  const seen: Record<string, number> = {};
  return html.replace(
    /<(h[23])([^>]*)>([\s\S]*?)<\/h[23]>/gi,
    (_, tag, attrs, inner) => {
      const text = inner.replace(/<[^>]+>/g, "").trim();
      const baseId = text
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");
      const count = seen[baseId] ?? 0;
      seen[baseId] = count + 1;
      const id = count === 0 ? baseId : `${baseId}-${count}`;
      return `<${tag}${attrs} id="${id}">${inner}</${tag}>`;
    },
  );
}

// ── TOC Component ─────────────────────────────────────────────────────────────

interface TocListProps {
  items: TocItem[];
  activeId: string;
}

function TocList({ items, activeId }: TocListProps) {
  if (items.length === 0) return null;
  return (
    <nav aria-label="Table of contents">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">
        Table of Contents
      </p>
      <ol className="space-y-1">
        {items.map((item) => (
          <li key={`${item.id}-${item.level}`}>
            <a
              href={`#${item.id}`}
              data-ocid="article.toc.link"
              onClick={(e) => {
                e.preventDefault();
                const el = document.getElementById(item.id);
                if (el)
                  el.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
              className={[
                "block text-sm leading-snug transition-colors duration-200 py-0.5",
                item.level === 3 ? "pl-4" : "",
                activeId === item.id
                  ? "text-primary font-semibold"
                  : "text-muted-foreground hover:text-foreground",
              ].join(" ")}
            >
              {item.text}
            </a>
          </li>
        ))}
      </ol>
    </nav>
  );
}

// ── Article Skeleton ───────────────────────────────────────────────────────────

function ArticleSkeleton() {
  return (
    <div
      data-ocid="article.loading_state"
      className="max-w-7xl mx-auto px-4 sm:px-6 py-10 lg:py-16"
    >
      <Skeleton className="h-4 w-64 mb-8" />
      <div className="max-w-3xl">
        <Skeleton className="h-5 w-24 mb-4" />
        <Skeleton className="h-10 w-full mb-3" />
        <Skeleton className="h-10 w-4/5 mb-6" />
        <div className="flex gap-4 mb-8">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
        </div>
        <Skeleton className="h-72 w-full rounded-sm mb-10" />
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-4 w-full mb-3" />
        ))}
      </div>
    </div>
  );
}

// ── 404 View ──────────────────────────────────────────────────────────────────

function ArticleNotFound() {
  return (
    <div
      data-ocid="article.error_state"
      className="max-w-2xl mx-auto px-4 py-24 text-center"
    >
      <p className="text-7xl font-bold font-display text-muted-foreground/20 mb-4 select-none">
        404
      </p>
      <h1 className="text-2xl font-bold font-display text-foreground mb-3">
        Article Not Found
      </h1>
      <p className="text-muted-foreground mb-8">
        The article you're looking for doesn't exist or may have been moved.
      </p>
      <Link
        to="/articles"
        search={{ q: "", category: "", sort: "date", page: 1 }}
      >
        <Button variant="default" data-ocid="article.back_button">
          Browse All Articles
        </Button>
      </Link>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function ArticleDetail() {
  const { slug } = useParams({ from: "/articles/$slug" });
  const { data: article, isLoading } = useArticleBySlug(slug);
  const incrementView = useIncrementViewCount();
  const { data: latestArticles } = useLatestArticles(9);
  const [activeHeading, setActiveHeading] = useState("");
  const [tocOpen, setTocOpen] = useState(false);
  const viewIncremented = useRef(false);

  // Increment view count once
  useEffect(() => {
    if (article && !viewIncremented.current) {
      viewIncremented.current = true;
      incrementView.mutate(article.id);
    }
  }, [article, incrementView]);

  // SEO meta tags
  useEffect(() => {
    if (!article) return;
    document.title = `${article.title} | The Kiln — Cement Engineering Hub`;

    const setMeta = (selector: string, attr: string, value: string) => {
      let el = document.querySelector<HTMLMetaElement>(selector);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr.split("=")[0], attr.split("=")[1] ?? "");
        document.head.appendChild(el);
      }
      el.content = value;
    };

    setMeta(
      'meta[name="description"]',
      "name=description",
      article.metaDescription,
    );
    setMeta('meta[property="og:type"]', "property=og:type", "article");
    setMeta('meta[property="og:title"]', "property=og:title", article.title);
    setMeta(
      'meta[property="og:description"]',
      "property=og:description",
      article.metaDescription,
    );
    setMeta('meta[property="og:url"]', "property=og:url", window.location.href);

    return () => {
      document.title = "The Kiln — Cement Engineering Hub";
    };
  }, [article]);

  // Active heading tracking via IntersectionObserver
  useEffect(() => {
    if (!article) return;
    const headings = document.querySelectorAll<HTMLElement>(
      "article h2[id], article h3[id]",
    );
    if (!headings.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveHeading(entry.target.id);
            break;
          }
        }
      },
      { rootMargin: "-10% 0px -70% 0px" },
    );
    for (const h of Array.from(headings)) observer.observe(h);
    return () => observer.disconnect();
  }, [article]);

  if (isLoading) return <ArticleSkeleton />;
  if (!article) return <ArticleNotFound />;

  const readTime = estimateReadTime(article.content);
  const processedContent = addAnchorIds(article.content);
  const tocItems = extractToc(article.content);
  const categoryLabel = CATEGORY_LABELS[article.category] ?? article.category;

  const relatedArticles = (latestArticles ?? [])
    .filter((a) => a.category === article.category && a.id !== article.id)
    .slice(0, 3);

  function copyLink() {
    navigator.clipboard.writeText(window.location.href).then(() => {
      toast.success("Link copied to clipboard!", { duration: 4000 });
    });
  }

  const publishedAt = new Date(Number(article.publishDate)).toISOString();
  const updatedAt = new Date(Number(article.lastUpdated)).toISOString();
  const showUpdated =
    article.lastUpdated !== article.publishDate &&
    Math.abs(Number(article.lastUpdated) - Number(article.publishDate)) >
      86_400_000;

  return (
    <div className="bg-background min-h-screen">
      {/* Breadcrumb */}
      <nav
        aria-label="Breadcrumb"
        className="border-b border-border bg-card"
        data-ocid="article.breadcrumb"
      >
        <ol className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-1.5 text-sm text-muted-foreground flex-wrap">
          <li>
            <Link
              to="/"
              className="hover:text-primary transition-colors"
              data-ocid="breadcrumb.home_link"
            >
              Home
            </Link>
          </li>
          <li aria-hidden="true">
            <ChevronRight className="w-3.5 h-3.5" />
          </li>
          <li>
            <Link
              to="/articles"
              className="hover:text-primary transition-colors"
              data-ocid="breadcrumb.articles_link"
              search={{ q: "", category: "", sort: "date", page: 1 }}
            >
              Articles
            </Link>
          </li>
          <li aria-hidden="true">
            <ChevronRight className="w-3.5 h-3.5" />
          </li>
          <li>
            <Link
              to="/articles"
              search={{
                category: article.category,
                q: "",
                sort: "date",
                page: 1,
              }}
              className="hover:text-primary transition-colors"
              data-ocid="breadcrumb.category_link"
            >
              {categoryLabel}
            </Link>
          </li>
          <li aria-hidden="true">
            <ChevronRight className="w-3.5 h-3.5" />
          </li>
          <li
            className="text-foreground font-medium truncate max-w-[200px] sm:max-w-xs"
            aria-current="page"
          >
            {article.title}
          </li>
        </ol>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 lg:py-12">
        <div className="lg:grid lg:grid-cols-[1fr_280px] lg:gap-12 xl:gap-16">
          {/* ── Article Column ───────────────────────────────────────── */}
          <div className="min-w-0">
            <article
              itemScope
              itemType="https://schema.org/Article"
              data-ocid="article.body_container"
            >
              {/* Header */}
              <header className="mb-8">
                <CategoryBadge
                  category={article.category}
                  size="md"
                  className="mb-4"
                />

                <h1
                  itemProp="headline"
                  className="text-3xl sm:text-4xl lg:text-5xl font-bold font-display text-foreground leading-tight tracking-tight mb-5"
                >
                  {article.title}
                </h1>

                {/* Meta row */}
                <div
                  className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground border-y border-border py-4"
                  data-ocid="article.meta"
                >
                  <span
                    className="flex items-center gap-1.5"
                    itemProp="author"
                    itemScope
                    itemType="https://schema.org/Person"
                  >
                    <User className="w-4 h-4 shrink-0" />
                    <span
                      className="font-medium text-foreground"
                      itemProp="name"
                    >
                      {article.authorName}
                    </span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 shrink-0" />
                    <time dateTime={publishedAt} itemProp="datePublished">
                      {formatDate(article.publishDate)}
                    </time>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4 shrink-0" />
                    {readTime} min read
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Eye className="w-4 h-4 shrink-0" />
                    {Number(article.viewCount).toLocaleString()} views
                  </span>
                  {showUpdated && (
                    <span className="flex items-center gap-1.5 text-xs">
                      <RefreshCw className="w-3.5 h-3.5 shrink-0" />
                      <time dateTime={updatedAt} itemProp="dateModified">
                        Updated {formatDate(article.lastUpdated)}
                      </time>
                    </span>
                  )}
                </div>
              </header>

              {/* Featured Image */}
              {article.featuredImageUrl && (
                <figure className="mb-8 -mx-4 sm:mx-0 sm:rounded-sm overflow-hidden bg-muted">
                  <img
                    src={article.featuredImageUrl}
                    alt={article.title}
                    loading="lazy"
                    className="w-full max-h-[480px] object-cover"
                    itemProp="image"
                    data-ocid="article.featured_image"
                  />
                </figure>
              )}

              {/* Mobile TOC */}
              {tocItems.length > 0 && (
                <div
                  className="lg:hidden mb-8 border border-border rounded-sm bg-card overflow-hidden"
                  data-ocid="article.mobile_toc"
                >
                  <button
                    type="button"
                    onClick={() => setTocOpen(!tocOpen)}
                    className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-foreground"
                    aria-expanded={tocOpen}
                    aria-controls="mobile-toc-content"
                    data-ocid="article.toc_toggle"
                  >
                    <span>Table of Contents</span>
                    <ChevronDown
                      className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${
                        tocOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {tocOpen && (
                    <div
                      id="mobile-toc-content"
                      className="px-4 pb-4 border-t border-border pt-3"
                    >
                      <TocList items={tocItems} activeId={activeHeading} />
                    </div>
                  )}
                </div>
              )}

              {/* Article Body */}
              <section
                data-ocid="article.body"
                className="prose prose-slate dark:prose-invert max-w-none
                  prose-headings:font-display prose-headings:font-bold prose-headings:text-foreground
                  prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4 prose-h2:scroll-mt-24
                  prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3 prose-h3:scroll-mt-24
                  prose-p:text-foreground prose-p:leading-relaxed prose-p:mb-5
                  prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                  prose-strong:text-foreground prose-strong:font-semibold
                  prose-code:text-primary prose-code:bg-muted prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-sm prose-code:font-mono prose-code:before:content-none prose-code:after:content-none
                  prose-pre:bg-muted prose-pre:border prose-pre:border-border prose-pre:rounded-sm
                  prose-blockquote:border-l-primary prose-blockquote:text-muted-foreground prose-blockquote:italic prose-blockquote:not-italic
                  prose-ul:text-foreground prose-ol:text-foreground prose-li:my-1
                  prose-img:rounded-sm prose-img:border prose-img:border-border
                  prose-table:text-sm prose-th:text-foreground prose-th:bg-muted/60 prose-td:text-foreground
                  prose-hr:border-border"
                // biome-ignore lint/security/noDangerouslySetInnerHtml: Admin-controlled content only
                dangerouslySetInnerHTML={{ __html: processedContent }}
                itemProp="articleBody"
              />

              {/* Share Section */}
              <section
                className="mt-12 pt-8 border-t border-border"
                data-ocid="article.share_section"
              >
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">
                  Share this article
                </h2>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copyLink}
                  className="gap-2"
                  data-ocid="article.copy_link_button"
                >
                  <Copy className="w-4 h-4" />
                  Copy Link
                </Button>
              </section>
            </article>

            {/* Related Articles */}
            {relatedArticles.length > 0 && (
              <section
                className="mt-16 pt-10 border-t border-border"
                data-ocid="article.related_section"
                aria-label="Related articles"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold font-display text-foreground">
                    More from {categoryLabel}
                  </h2>
                  <Link
                    to="/articles"
                    search={{
                      category: article.category,
                      q: "",
                      sort: "date",
                      page: 1,
                    }}
                    className="text-sm text-primary hover:underline font-medium"
                    data-ocid="article.related_view_all_link"
                  >
                    View all →
                  </Link>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {relatedArticles.map((related, i) => (
                    <ArticleCard
                      key={related.id.toString()}
                      article={related}
                      index={i}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* ── Desktop TOC Sidebar ──────────────────────────────────── */}
          {tocItems.length > 0 && (
            <aside
              className="hidden lg:block"
              aria-label="Table of contents"
              data-ocid="article.toc_sidebar"
            >
              <div className="sticky top-6 bg-card border border-border rounded-sm p-5">
                <TocList items={tocItems} activeId={activeHeading} />

                {/* Share in sidebar */}
                <div className="mt-6 pt-5 border-t border-border">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">
                    Share
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyLink}
                    className="w-full gap-2 justify-start"
                    data-ocid="article.sidebar_copy_link_button"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy Link
                  </Button>
                </div>
              </div>
            </aside>
          )}
        </div>
      </div>
    </div>
  );
}
