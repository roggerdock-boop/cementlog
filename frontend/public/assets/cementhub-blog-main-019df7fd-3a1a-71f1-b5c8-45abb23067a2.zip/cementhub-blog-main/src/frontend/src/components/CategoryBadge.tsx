import { cn } from "@/lib/utils";
import type { Category } from "@/types";
import { CATEGORY_COLORS, CATEGORY_LABELS } from "@/types";

interface CategoryBadgeProps {
  category: Category;
  className?: string;
  size?: "sm" | "md";
}

export function CategoryBadge({
  category,
  className,
  size = "sm",
}: CategoryBadgeProps) {
  const label = CATEGORY_LABELS[category] ?? category;
  const colorClass =
    CATEGORY_COLORS[category] ?? "bg-muted text-muted-foreground";

  return (
    <span
      className={cn(
        "inline-flex items-center font-semibold rounded-sm tracking-wide uppercase",
        size === "sm" ? "text-[10px] px-2 py-0.5" : "text-xs px-3 py-1",
        colorClass,
        className,
      )}
      data-ocid="category.badge"
    >
      {label}
    </span>
  );
}

interface CategoryChipProps {
  category: Category;
  active?: boolean;
  onClick?: () => void;
}

export function CategoryChip({ category, active, onClick }: CategoryChipProps) {
  const label = CATEGORY_LABELS[category] ?? category;
  return (
    <button
      type="button"
      onClick={onClick}
      data-ocid="category.toggle"
      className={cn(
        "px-4 py-2 rounded-sm text-sm font-medium border transition-smooth cursor-pointer",
        active
          ? "bg-primary text-primary-foreground border-primary"
          : "bg-card text-foreground border-border hover:border-primary/50 hover:bg-primary/5",
      )}
    >
      {label}
    </button>
  );
}
