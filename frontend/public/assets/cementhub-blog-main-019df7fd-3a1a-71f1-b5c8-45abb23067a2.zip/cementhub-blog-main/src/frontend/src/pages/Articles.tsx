import { ArticleCard } from "@/components/ArticleCard";
import { CategoryChip } from "@/components/CategoryBadge";
import { Pagination } from "@/components/Pagination";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useListArticles,
  usePublishedArticles,
  useSearchArticles,
} from "@/hooks/useArticles";
import { CATEGORY_LABELS, Category, SortBy } from "@/types";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { ChevronDown, Filter, Search, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

const PAGE_SIZE = 10;
const ALL_CATEGORIES = Object.values(Category);

const SORT_OPTIONS: { label: string; value: string }[] = [
  { label: "Newest", value: "date" },
  { label: "Most Popular", value: "viewCount" },
  { label: "A–Z", value: "alpha" },
];

function toSortBy(sort: string): SortBy {
  if (sort === "viewCount") return SortBy.viewCount;
  return SortBy.date;
}

function sortAlpha(articles: { title: string }[]) {
  return [...articles].sort((a, b) => a.title.localeCompare(b.title));
}

// ─── Skeleton grid ──────────────────────────────────────────────────────────
function ArticleGridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: PAGE_SIZE }).map((_, i) => (
        <div
          // biome-ignore lint/suspicious/noArrayIndexKey: skeleton has no identity
          key={i}
          className="rounded-sm border border-border bg-card overflow-hidden"
        >
          <Skeleton className="aspect-video w-full" />
          <div className="p-5 space-y-2.5">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2 mt-3" />
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Active filter tag ───────────────────────────────────────────────────────
function FilterTag({
  label,
  onRemove,
  ocid,
}: { label: string; onRemove: () => void; ocid: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm bg-primary/10 text-primary text-sm font-medium"
      data-ocid={ocid}
    >
      {label}
      <button
        type="button"
        onClick={onRemove}
        aria-label={`Remove ${label} filter`}
        className="hover:text-primary/70 transition-colors"
      >
        <X className="w-3 h-3" />
      </button>
    </span>
  );
}

// ─── Sort dropdown ───────────────────────────────────────────────────────────
function SortDropdown({
  value,
  onChange,
}: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const currentLabel =
    SORT_OPTIONS.find((o) => o.value === value)?.label ?? "Newest";

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative" data-ocid="sort.select">
      <button
        type="button"
        onClick={() => setOpen((p) => !p)}
        className="flex items-center gap-2 px-3 py-2 rounded-sm border border-border bg-card text-sm text-foreground hover:border-primary/50 transition-smooth"
        aria-label="Sort articles"
        aria-expanded={open}
      >
        <span className="text-muted-foreground text-xs uppercase tracking-wide hidden sm:inline">
          Sort:
        </span>
        <span className="font-medium">{currentLabel}</span>
        <ChevronDown className="w-4 h-4 text-muted-foreground" />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 z-20 min-w-[160px] rounded-sm border border-border bg-card shadow-lg py-1">
          {SORT_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              type="button"
              data-ocid={`sort.item.${opt.value}`}
              onClick={() => {
                onChange(opt.value);
                setOpen(false);
              }}
              className={`w-full text-left px-4 py-2 text-sm transition-colors hover:bg-muted ${
                opt.value === value
                  ? "text-primary font-semibold"
                  : "text-foreground"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main page ───────────────────────────────────────────────────────────────
export default function Articles() {
  const search = useSearch({ from: "/articles" });
  const navigate = useNavigate();

  const q = search.q ?? "";
  const category = (search.category as Category | "") ?? "";
  const sort = (search.sort as string) ?? "date";
  const page = search.page ?? 1;

  // Debounced search input
  const [inputValue, setInputValue] = useState(q);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setInputValue(q);
  }, [q]);

  const handleSearchChange = useCallback(
    (value: string) => {
      setInputValue(value);
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        navigate({
          to: "/articles",
          search: { q: value, category, sort, page: 1 },
        });
      }, 300);
    },
    [navigate, category, sort],
  );

  function setCategory(cat: Category | "") {
    navigate({ to: "/articles", search: { q, category: cat, sort, page: 1 } });
  }

  function setSort(s: string) {
    navigate({ to: "/articles", search: { q, category, sort: s, page: 1 } });
  }

  function setPage(p: number) {
    navigate({ to: "/articles", search: { q, category, sort, page: p } });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // Data fetching
  const isSearching = q.trim().length > 1;
  const searchResults = useSearchArticles(q);
  const listFilter = {
    category: category ? (category as Category) : undefined,
    sortBy: toSortBy(sort),
  } as Parameters<typeof usePublishedArticles>[0];

  const listResults = usePublishedArticles({
    ...listFilter,
    page: page - 1,
    pageSize: PAGE_SIZE,
  } as Parameters<typeof usePublishedArticles>[0]);

  const isLoading = isSearching
    ? searchResults.isLoading
    : listResults.isLoading;

  // Build display articles
  let articles = isSearching
    ? (searchResults.data ?? [])
    : (listResults.data?.articles ?? []);

  // Alpha sort handled client-side since backend only supports date/viewCount
  if (sort === "alpha") {
    articles = sortAlpha(articles) as typeof articles;
  }

  // Filter search results by category client-side
  if (isSearching && category) {
    articles = articles.filter((a) => a.category === category);
  }

  const totalItems = isSearching
    ? articles.length
    : Number(listResults.data?.total ?? 0);

  const totalPages = isSearching
    ? Math.ceil(articles.length / PAGE_SIZE)
    : Math.ceil(totalItems / PAGE_SIZE);

  // For search results, paginate client-side
  const displayArticles = isSearching
    ? articles.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)
    : articles;

  const hasActiveFilters = !!q || !!category || sort !== "date";

  // SEO meta title
  const metaTitle = hasActiveFilters
    ? `Articles — CementHub${category ? ` · ${CATEGORY_LABELS[category]}` : ""}${q ? ` · "${q}"` : ""}`
    : "Articles — CementHub";

  useEffect(() => {
    document.title = metaTitle;
  }, [metaTitle]);

  return (
    <div className="min-h-screen bg-background">
      {/* Page header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl md:text-4xl font-bold font-display text-foreground tracking-tight">
            All Articles
          </h1>
          <p className="mt-2 text-muted-foreground text-base max-w-xl">
            Technical guides, operational insights, and engineering best
            practices for cement industry professionals.
          </p>

          {/* Search bar */}
          <div className="mt-6 relative flex items-center max-w-2xl">
            <Search className="absolute left-4 w-4 h-4 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              value={inputValue}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search articles, guides, technical insights..."
              data-ocid="articles.search_input"
              className="w-full pl-10 pr-10 py-2.5 text-sm bg-card border border-border rounded-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-smooth"
            />
            {inputValue && (
              <button
                type="button"
                onClick={() => handleSearchChange("")}
                data-ocid="articles.search_clear"
                className="absolute right-3 text-muted-foreground hover:text-foreground transition-smooth"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* ── Sidebar (desktop) ── */}
          <aside className="hidden lg:block w-56 flex-shrink-0">
            <div className="sticky top-6">
              <div className="flex items-center gap-2 mb-4">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-semibold text-foreground uppercase tracking-wide">
                  Categories
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  data-ocid="category.filter.all"
                  onClick={() => setCategory("")}
                  className={`text-left px-3 py-2 rounded-sm text-sm font-medium transition-smooth ${
                    !category
                      ? "bg-primary text-primary-foreground"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  All Categories
                </button>
                {ALL_CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    data-ocid={`category.filter.${cat.toLowerCase()}`}
                    onClick={() => setCategory(cat)}
                    className={`text-left px-3 py-2 rounded-sm text-sm font-medium transition-smooth ${
                      category === cat
                        ? "bg-primary text-primary-foreground"
                        : "text-foreground hover:bg-muted"
                    }`}
                  >
                    {CATEGORY_LABELS[cat]}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* ── Main content ── */}
          <div className="flex-1 min-w-0">
            {/* Mobile category chips */}
            <div className="lg:hidden mb-5 overflow-x-auto pb-1">
              <div className="flex gap-2 min-w-max">
                <button
                  type="button"
                  data-ocid="category.filter.all"
                  onClick={() => setCategory("")}
                  className={`px-4 py-1.5 rounded-sm text-sm font-medium border transition-smooth ${
                    !category
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-foreground border-border hover:border-primary/50"
                  }`}
                >
                  All
                </button>
                {ALL_CATEGORIES.map((cat) => (
                  <CategoryChip
                    key={cat}
                    category={cat}
                    active={category === cat}
                    onClick={() => setCategory(cat)}
                  />
                ))}
              </div>
            </div>

            {/* Controls bar */}
            <div className="flex items-center justify-between gap-4 mb-5">
              <p
                className="text-sm text-muted-foreground"
                data-ocid="articles.result_count"
              >
                {isLoading
                  ? "Loading…"
                  : `${totalItems} article${totalItems !== 1 ? "s" : ""}${q ? ` for "${q}"` : ""}`}
              </p>
              <SortDropdown value={sort} onChange={setSort} />
            </div>

            {/* Active filter tags */}
            {hasActiveFilters && (
              <div
                className="flex flex-wrap items-center gap-2 mb-5"
                data-ocid="articles.active_filters"
              >
                <span className="text-xs text-muted-foreground font-medium">
                  Filters:
                </span>
                {q && (
                  <FilterTag
                    label={`Search: "${q}"`}
                    ocid="articles.filter_tag.search"
                    onRemove={() =>
                      navigate({
                        to: "/articles",
                        search: { q: "", category, sort, page: 1 },
                      })
                    }
                  />
                )}
                {category && (
                  <FilterTag
                    label={CATEGORY_LABELS[category]}
                    ocid="articles.filter_tag.category"
                    onRemove={() => setCategory("")}
                  />
                )}
                {sort !== "date" && (
                  <FilterTag
                    label={`Sort: ${SORT_OPTIONS.find((o) => o.value === sort)?.label}`}
                    ocid="articles.filter_tag.sort"
                    onRemove={() => setSort("date")}
                  />
                )}
                <button
                  type="button"
                  data-ocid="articles.clear_all_filters"
                  onClick={() =>
                    navigate({
                      to: "/articles",
                      search: { q: "", category: "", sort: "date", page: 1 },
                    })
                  }
                  className="text-xs text-muted-foreground hover:text-foreground underline transition-colors"
                >
                  Clear all
                </button>
              </div>
            )}

            {/* Loading state */}
            {isLoading && (
              <div data-ocid="articles.loading_state">
                <ArticleGridSkeleton />
              </div>
            )}

            {/* Empty state */}
            {!isLoading && displayArticles.length === 0 && (
              <div
                className="flex flex-col items-center justify-center py-20 text-center"
                data-ocid="articles.empty_state"
              >
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold font-display text-foreground mb-2">
                  No articles found
                </h3>
                <p className="text-muted-foreground text-sm max-w-sm mb-6">
                  {q
                    ? `No results for "${q}". Try different keywords or remove the search filter.`
                    : category
                      ? `No articles in ${CATEGORY_LABELS[category]} yet. Check back soon.`
                      : "No articles available. Check back soon."}
                </p>
                <button
                  type="button"
                  data-ocid="articles.empty_cta"
                  onClick={() =>
                    navigate({
                      to: "/articles",
                      search: { q: "", category: "", sort: "date", page: 1 },
                    })
                  }
                  className="px-4 py-2 rounded-sm bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-smooth"
                >
                  Browse all articles
                </button>
              </div>
            )}

            {/* Articles grid */}
            {!isLoading && displayArticles.length > 0 && (
              <>
                <div
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
                  data-ocid="articles.list"
                >
                  {displayArticles.map((article, i) => (
                    <ArticleCard
                      key={article.id.toString()}
                      article={article}
                      index={(page - 1) * PAGE_SIZE + i}
                    />
                  ))}
                </div>

                {totalPages > 1 && (
                  <div className="mt-10">
                    <Pagination
                      page={page}
                      totalPages={totalPages}
                      onPageChange={setPage}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
