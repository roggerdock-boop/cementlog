import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Factory, FlaskConical, RotateCcw } from "lucide-react";
import { useMemo, useState } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Material {
  name: string;
  cao: string;
  sio2: string;
  al2o3: string;
  fe2o3: string;
  proportion: string;
}

interface GeomInputs {
  diameter: string;
  length: string;
  burningZoneLength: string;
}

interface LoadingInputs {
  clinkerOutput: string;
  feedRate: string;
  diameter: string;
  length: string;
}

interface ThermalInputs {
  heatInput: string;
  bzVolume: string;
  length: string;
  diameter: string;
  inclination: string;
  rotationSpeed: string;
}

// ─── Defaults ─────────────────────────────────────────────────────────────────

const defaultGeom: GeomInputs = {
  diameter: "4.5",
  length: "75",
  burningZoneLength: "15",
};

const defaultLoading: LoadingInputs = {
  clinkerOutput: "3500",
  feedRate: "280",
  diameter: "4.5",
  length: "75",
};

const defaultThermal: ThermalInputs = {
  heatInput: "280000000",
  bzVolume: "",
  length: "75",
  diameter: "4.5",
  inclination: "3.5",
  rotationSpeed: "3.5",
};

const defaultMaterials: Material[] = [
  {
    name: "Limestone",
    cao: "52.0",
    sio2: "3.5",
    al2o3: "1.2",
    fe2o3: "0.5",
    proportion: "80",
  },
  {
    name: "Clay",
    cao: "3.0",
    sio2: "55.0",
    al2o3: "18.0",
    fe2o3: "6.0",
    proportion: "14",
  },
  {
    name: "Iron Ore",
    cao: "1.0",
    sio2: "12.0",
    al2o3: "5.0",
    fe2o3: "65.0",
    proportion: "3",
  },
  {
    name: "Sand",
    cao: "0.5",
    sio2: "88.0",
    al2o3: "3.0",
    fe2o3: "1.0",
    proportion: "3",
  },
];

// ─── Shared helpers ───────────────────────────────────────────────────────────

type RatingLevel = "optimal" | "near" | "out";

function getRating(value: number, low: number, high: number): RatingLevel {
  if (value >= low && value <= high) return "optimal";
  if (value >= low * 0.9 && value <= high * 1.1) return "near";
  return "out";
}

function RatingBadge({
  value,
  low,
  high,
}: { value: number; low: number; high: number }) {
  const level = getRating(value, low, high);
  if (level === "optimal")
    return (
      <Badge className="bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30">
        Optimal
      </Badge>
    );
  if (level === "near")
    return (
      <Badge className="bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30">
        Near Range
      </Badge>
    );
  return (
    <Badge className="bg-destructive/15 text-destructive border-destructive/30">
      Out of Range
    </Badge>
  );
}

function FormulaTag({ formula }: { formula: string }) {
  return (
    <span className="font-mono text-[10px] text-muted-foreground/80 bg-muted/60 rounded px-1.5 py-0.5 inline-block mt-0.5">
      {formula}
    </span>
  );
}

function ResultRow({
  label,
  value,
  unit,
  formula,
  low,
  high,
  rangeLabel,
  ocid,
}: {
  label: string;
  value: string;
  unit: string;
  formula: string;
  low?: number;
  high?: number;
  rangeLabel?: string;
  ocid?: string;
}) {
  const numVal = Number.parseFloat(value);
  return (
    <div className="py-3 border-b border-border last:border-0" data-ocid={ocid}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground">{label}</p>
          <FormulaTag formula={formula} />
          {rangeLabel && (
            <p className="text-[11px] text-muted-foreground mt-0.5">
              Benchmark: {rangeLabel}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-lg font-bold font-mono text-foreground whitespace-nowrap">
            {value}
            <span className="text-xs font-normal text-muted-foreground ml-1">
              {unit}
            </span>
          </span>
          {low !== undefined && high !== undefined && !Number.isNaN(numVal) && (
            <RatingBadge value={numVal} low={low} high={high} />
          )}
        </div>
      </div>
    </div>
  );
}

function InputField({
  label,
  unit,
  value,
  onChange,
  placeholder,
  ocid,
}: {
  label: string;
  unit: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder: string;
  ocid: string;
}) {
  return (
    <div className="space-y-1" data-ocid={`${ocid}.field`}>
      <Label className="text-xs text-muted-foreground">
        {label} <span className="text-muted-foreground/60">({unit})</span>
      </Label>
      <Input
        type="number"
        step="any"
        min="0"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="h-9 text-sm"
        data-ocid={`${ocid}.input`}
      />
    </div>
  );
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-4 py-2">
      <div className="flex-1 h-px bg-border" />
      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest px-2">
        {label}
      </span>
      <div className="flex-1 h-px bg-border" />
    </div>
  );
}

// ─── Card A: Kiln Geometry ────────────────────────────────────────────────────

function CardA({
  geom,
  setGeom,
}: {
  geom: GeomInputs;
  setGeom: React.Dispatch<React.SetStateAction<GeomInputs>>;
}) {
  const set =
    (k: keyof GeomInputs) => (e: React.ChangeEvent<HTMLInputElement>) =>
      setGeom((p) => ({ ...p, [k]: e.target.value }));

  const results = useMemo(() => {
    const D = Number.parseFloat(geom.diameter);
    const L = Number.parseFloat(geom.length);
    const bz = Number.parseFloat(geom.burningZoneLength);
    if (!Number.isFinite(D) || D <= 0) return null;
    if (!Number.isFinite(L) || L <= 0) return null;
    if (!Number.isFinite(bz) || bz <= 0) return null;
    const kilnVol = (Math.PI / 4) * D * D * L;
    const bzVol = (Math.PI / 4) * D * D * bz;
    return { kilnVol: kilnVol.toFixed(1), bzVol: bzVol.toFixed(1) };
  }, [geom]);

  return (
    <Card className="card-elevated" data-ocid="kiln_geometry.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-orange-500/15 text-orange-600 dark:text-orange-400 rounded px-1.5 py-0.5">
            A
          </span>
          Kiln Geometry
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Volumes from kiln dimensions
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <InputField
            label="Diameter D"
            unit="m"
            value={geom.diameter}
            onChange={set("diameter")}
            placeholder="4.5"
            ocid="kiln_geometry.diameter"
          />
          <InputField
            label="Length L"
            unit="m"
            value={geom.length}
            onChange={set("length")}
            placeholder="75"
            ocid="kiln_geometry.length"
          />
          <InputField
            label="BZ Length"
            unit="m"
            value={geom.burningZoneLength}
            onChange={set("burningZoneLength")}
            placeholder="15"
            ocid="kiln_geometry.bz_length"
          />
        </div>
        {results ? (
          <div className="space-y-0.5 pt-2 border-t border-border">
            <ResultRow
              label="Kiln Volume"
              value={results.kilnVol}
              unit="m³"
              formula="V = π/4 × D² × L"
              ocid="kiln_geometry.kiln_volume"
            />
            <ResultRow
              label="Burning Zone Volume"
              value={results.bzVol}
              unit="m³"
              formula="V_bz = π/4 × D² × L_bz"
              ocid="kiln_geometry.bz_volume"
            />
          </div>
        ) : (
          <div
            className="text-center py-6 text-muted-foreground text-xs"
            data-ocid="kiln_geometry.empty_state"
          >
            Enter valid dimensions to compute volumes
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Card B: Kiln Loading ─────────────────────────────────────────────────────

function CardB({
  loading,
  setLoading,
}: {
  loading: LoadingInputs;
  setLoading: React.Dispatch<React.SetStateAction<LoadingInputs>>;
}) {
  const set =
    (k: keyof LoadingInputs) => (e: React.ChangeEvent<HTMLInputElement>) =>
      setLoading((p) => ({ ...p, [k]: e.target.value }));

  const results = useMemo(() => {
    const clinker = Number.parseFloat(loading.clinkerOutput);
    const feed = Number.parseFloat(loading.feedRate);
    const D = Number.parseFloat(loading.diameter);
    const L = Number.parseFloat(loading.length);
    if (!Number.isFinite(clinker) || clinker <= 0) return null;
    if (!Number.isFinite(feed) || feed <= 0) return null;
    if (!Number.isFinite(D) || D <= 0) return null;
    if (!Number.isFinite(L) || L <= 0) return null;
    const kilnVol = (Math.PI / 4) * D * D * L;
    const svl = clinker / kilnVol;
    const vl = (feed / (kilnVol * 1.4)) * 100;
    return { svl: svl.toFixed(3), svlRaw: svl, vl: vl.toFixed(2), vlRaw: vl };
  }, [loading]);

  return (
    <Card className="card-elevated" data-ocid="kiln_loading.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-orange-500/15 text-orange-600 dark:text-orange-400 rounded px-1.5 py-0.5">
            B
          </span>
          Kiln Loading
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Specific volume & volumetric loading
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <InputField
            label="Clinker Output"
            unit="t/day"
            value={loading.clinkerOutput}
            onChange={set("clinkerOutput")}
            placeholder="3500"
            ocid="kiln_loading.clinker_output"
          />
          <InputField
            label="Feed Rate"
            unit="t/h"
            value={loading.feedRate}
            onChange={set("feedRate")}
            placeholder="280"
            ocid="kiln_loading.feed_rate"
          />
          <InputField
            label="Diameter D"
            unit="m"
            value={loading.diameter}
            onChange={set("diameter")}
            placeholder="4.5"
            ocid="kiln_loading.diameter"
          />
          <InputField
            label="Length L"
            unit="m"
            value={loading.length}
            onChange={set("length")}
            placeholder="75"
            ocid="kiln_loading.length"
          />
        </div>
        {results ? (
          <div className="space-y-0.5 pt-2 border-t border-border">
            <ResultRow
              label="Specific Volume Loading"
              value={results.svl}
              unit="t/m³/day"
              formula="SVL = Clinker / (π/4 × D² × L)"
              low={1.2}
              high={1.8}
              rangeLabel="1.2–1.8 (good), >2.0 overloaded"
              ocid="kiln_loading.svl"
            />
            <ResultRow
              label="Volumetric Loading"
              value={results.vl}
              unit="%"
              formula="VL = Feed Rate / (π/4 × D² × L × 1.4) × 100"
              low={10}
              high={15}
              rangeLabel="10–15% normal range"
              ocid="kiln_loading.vl"
            />
          </div>
        ) : (
          <div
            className="text-center py-6 text-muted-foreground text-xs"
            data-ocid="kiln_loading.empty_state"
          >
            Enter all inputs to compute loading
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Card C: Thermal Loading & Residence Time ─────────────────────────────────

function CardC({
  thermal,
  setThermal,
}: {
  thermal: ThermalInputs;
  setThermal: React.Dispatch<React.SetStateAction<ThermalInputs>>;
}) {
  const set =
    (k: keyof ThermalInputs) => (e: React.ChangeEvent<HTMLInputElement>) =>
      setThermal((p) => ({ ...p, [k]: e.target.value }));

  const results = useMemo(() => {
    const heat = Number.parseFloat(thermal.heatInput);
    const D = Number.parseFloat(thermal.diameter);
    const L = Number.parseFloat(thermal.length);
    const inc = Number.parseFloat(thermal.inclination);
    const n = Number.parseFloat(thermal.rotationSpeed);
    if (!Number.isFinite(heat) || heat <= 0) return null;
    if (!Number.isFinite(D) || D <= 0) return null;
    if (!Number.isFinite(L) || L <= 0) return null;
    if (!Number.isFinite(inc) || inc <= 0) return null;
    if (!Number.isFinite(n) || n <= 0) return null;

    // BZ volume: use manual input if provided, else compute from diameter
    const manualBz = Number.parseFloat(thermal.bzVolume);
    const bzVol =
      Number.isFinite(manualBz) && manualBz > 0
        ? manualBz
        : (Math.PI / 4) * D * D * 15; // fallback: assume 15 m burning zone

    const stl = heat / bzVol / 1e6;
    const rt = (1.77 * Math.sqrt(inc) * L) / (D * n);
    return { stl: stl.toFixed(3), stlRaw: stl, rt: rt.toFixed(1), rtRaw: rt };
  }, [thermal]);

  return (
    <Card className="card-elevated" data-ocid="kiln_thermal.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-orange-500/15 text-orange-600 dark:text-orange-400 rounded px-1.5 py-0.5">
            C
          </span>
          Thermal Loading &amp; Residence Time
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Specific thermal load and material residence time
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <InputField
            label="Heat Input"
            unit="kcal/h"
            value={thermal.heatInput}
            onChange={set("heatInput")}
            placeholder="280000000"
            ocid="kiln_thermal.heat_input"
          />
          <InputField
            label="BZ Volume (optional)"
            unit="m³"
            value={thermal.bzVolume}
            onChange={set("bzVolume")}
            placeholder="auto from Card A"
            ocid="kiln_thermal.bz_volume"
          />
          <InputField
            label="Length L"
            unit="m"
            value={thermal.length}
            onChange={set("length")}
            placeholder="75"
            ocid="kiln_thermal.length"
          />
          <InputField
            label="Diameter D"
            unit="m"
            value={thermal.diameter}
            onChange={set("diameter")}
            placeholder="4.5"
            ocid="kiln_thermal.diameter"
          />
          <InputField
            label="Inclination"
            unit="%"
            value={thermal.inclination}
            onChange={set("inclination")}
            placeholder="3.5"
            ocid="kiln_thermal.inclination"
          />
          <InputField
            label="Rotation Speed n"
            unit="RPM"
            value={thermal.rotationSpeed}
            onChange={set("rotationSpeed")}
            placeholder="3.5"
            ocid="kiln_thermal.rotation_speed"
          />
        </div>
        {results ? (
          <div className="space-y-0.5 pt-2 border-t border-border">
            <ResultRow
              label="Specific Thermal Loading"
              value={results.stl}
              unit="×10⁶ kcal/m³/h"
              formula="STL = Heat Input / BZ Volume"
              low={3.5}
              high={4.5}
              rangeLabel="3.5–4.5 ×10⁶ kcal/m³/h"
              ocid="kiln_thermal.stl"
            />
            <ResultRow
              label="Residence Time"
              value={results.rt}
              unit="min"
              formula="t = 1.77 × √(Inc%) × L / (D × n)"
              low={20}
              high={30}
              rangeLabel="20–30 min"
              ocid="kiln_thermal.residence_time"
            />
          </div>
        ) : (
          <div
            className="text-center py-6 text-muted-foreground text-xs"
            data-ocid="kiln_thermal.empty_state"
          >
            Enter valid inputs to compute thermal loading
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Card D: Material Composition Input ──────────────────────────────────────

function CardD({
  materials,
  setMaterials,
  totalProportion,
  propOk,
}: {
  materials: Material[];
  setMaterials: React.Dispatch<React.SetStateAction<Material[]>>;
  totalProportion: string;
  propOk: boolean;
}) {
  const setField =
    (idx: number, key: keyof Material) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setMaterials((prev) =>
        prev.map((m, i) => (i === idx ? { ...m, [key]: e.target.value } : m)),
      );

  return (
    <Card className="card-elevated" data-ocid="raw_mix.inputs_card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-primary/15 text-primary rounded px-1.5 py-0.5">
            D
          </span>
          Material Composition Input
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Enter oxide chemistry for each raw material
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Column headers */}
        <div className="grid grid-cols-6 gap-1.5">
          <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
            Material
          </div>
          {(["CaO", "SiO₂", "Al₂O₃", "Fe₂O₃", "Blend %"] as const).map((h) => (
            <div
              key={h}
              className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide text-center"
            >
              {h}
            </div>
          ))}
        </div>

        {materials.map((mat, idx) => (
          <div
            key={mat.name}
            className="grid grid-cols-6 gap-1.5 items-center"
            data-ocid={`raw_mix.material.${idx + 1}`}
          >
            <Input
              value={mat.name}
              onChange={setField(idx, "name")}
              className="h-8 text-xs px-2"
              data-ocid={`raw_mix.material.${idx + 1}.name`}
            />
            {(["cao", "sio2", "al2o3", "fe2o3", "proportion"] as const).map(
              (key) => (
                <Input
                  key={key}
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={mat[key]}
                  onChange={setField(idx, key)}
                  className="h-8 text-xs px-2"
                  data-ocid={`raw_mix.${mat.name.toLowerCase().replace(/\s+/g, "_")}.${key}.input`}
                />
              ),
            )}
          </div>
        ))}

        {/* Totals row */}
        <div className="grid grid-cols-6 gap-1.5 items-center border-t border-border pt-2">
          <span className="text-xs font-semibold text-muted-foreground">
            Total
          </span>
          <div />
          <div />
          <div />
          <div />
          <div
            className={`text-center text-sm font-bold font-mono rounded px-1 ${
              propOk ? "text-green-600 dark:text-green-400" : "text-destructive"
            }`}
            data-ocid="raw_mix.proportion_total"
          >
            {totalProportion}%
          </div>
        </div>

        {!propOk && (
          <p
            className="text-xs text-destructive"
            data-ocid="raw_mix.proportion.field_error"
          >
            Total blend must sum to 100%
          </p>
        )}

        <div className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground border border-border">
          <p className="font-semibold text-foreground mb-1">Target Ranges</p>
          <p>
            • LSF: <strong>95–100</strong> | SR: <strong>2.0–3.0</strong> | AR:{" "}
            <strong>1.5–2.5</strong>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Card E: Blended Composition & Moduli ─────────────────────────────────────

interface MixCalc {
  cao: string;
  sio2: string;
  al2o3: string;
  fe2o3: string;
  lsf: string;
  lsfNum: number;
  sr: string;
  srNum: number;
  ar: string;
  arNum: number;
  c3s: string;
  c2s: string;
  c3a: string;
  c4af: string;
  propOk: boolean;
  totalProportion: string;
}

function CardE({ mix }: { mix: MixCalc | null }) {
  if (!mix)
    return (
      <Card className="card-elevated">
        <CardContent
          className="py-16 text-center"
          data-ocid="raw_mix.blended.empty_state"
        >
          <FlaskConical className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">
            Fill material compositions to see blended oxides
          </p>
        </CardContent>
      </Card>
    );

  return (
    <Card className="card-elevated" data-ocid="raw_mix.blended_card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-primary/15 text-primary rounded px-1.5 py-0.5">
            E
          </span>
          Blended Composition &amp; Moduli
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Weighted oxide averages and cement moduli
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Blended oxides grid */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: "CaO", value: mix.cao },
            { label: "SiO₂", value: mix.sio2 },
            { label: "Al₂O₃", value: mix.al2o3 },
            { label: "Fe₂O₃", value: mix.fe2o3 },
          ].map((o) => (
            <div
              key={o.label}
              className="bg-muted/40 rounded-md p-2.5 text-center border border-border"
            >
              <p className="text-[10px] text-muted-foreground mb-0.5">
                {o.label}
              </p>
              <p className="text-base font-bold font-mono text-foreground">
                {o.value}
                <span className="text-[10px] font-normal text-muted-foreground">
                  %
                </span>
              </p>
            </div>
          ))}
        </div>

        {/* Moduli */}
        <div className="space-y-0.5 pt-1 border-t border-border">
          <ResultRow
            label="Lime Saturation Factor (LSF)"
            value={mix.lsf}
            unit=""
            formula="CaO / (2.8×SiO₂ + 1.2×Al₂O₃ + 0.65×Fe₂O₃) × 100"
            low={95}
            high={100}
            rangeLabel="95–100 optimal; <90 soft burn; >100 excess lime"
            ocid="raw_mix.lsf"
          />
          <ResultRow
            label="Silica Ratio (SR)"
            value={mix.sr}
            unit=""
            formula="SR = SiO₂ / (Al₂O₃ + Fe₂O₃)"
            low={2.0}
            high={3.0}
            rangeLabel="2.0–3.0 optimal"
            ocid="raw_mix.sr"
          />
          <ResultRow
            label="Alumina Ratio (AR)"
            value={mix.ar}
            unit=""
            formula="AR = Al₂O₃ / Fe₂O₃"
            low={1.5}
            high={2.5}
            rangeLabel="1.5–2.5 optimal"
            ocid="raw_mix.ar"
          />
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Card F: Bogue Phase Composition ─────────────────────────────────────────

const PHASE_COLORS: Record<string, string> = {
  "C₃S (Alite)": "bg-blue-500",
  "C₂S (Belite)": "bg-emerald-500",
  "C₃A (Aluminate)": "bg-orange-500",
  "C₄AF (Ferrite)": "bg-rose-500",
};

function PhaseBar({
  label,
  value,
  low,
  high,
}: { label: string; value: string; low: number; high: number }) {
  const num = Number.parseFloat(value);
  const pct = Number.isFinite(num) ? Math.min(Math.max(num, 0), 100) : 0;
  const color = PHASE_COLORS[label] ?? "bg-primary";
  const rating = getRating(pct, low, high);
  const ratingColor =
    rating === "optimal"
      ? "text-green-600 dark:text-green-400"
      : rating === "near"
        ? "text-yellow-600 dark:text-yellow-400"
        : "text-destructive";

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-foreground">{label}</span>
        <span className={`text-sm font-bold font-mono ${ratingColor}`}>
          {value}%
        </span>
      </div>
      <div className="h-2 bg-muted/60 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <p className="text-[10px] text-muted-foreground">
        Benchmark: {low}–{high}%
      </p>
    </div>
  );
}

function CardF({ mix }: { mix: MixCalc | null }) {
  if (!mix)
    return (
      <Card className="card-elevated">
        <CardContent
          className="py-16 text-center"
          data-ocid="raw_mix.bogue.empty_state"
        >
          <FlaskConical className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">
            Computed from Card D once blended
          </p>
        </CardContent>
      </Card>
    );

  const phases = [
    {
      label: "C₃S (Alite)",
      value: mix.c3s,
      note: "Early strength",
      formula: "4.07·CaO − 7.6·SiO₂ − 6.72·Al₂O₃ − 1.43·Fe₂O₃",
      low: 60,
      high: 70,
    },
    {
      label: "C₂S (Belite)",
      value: mix.c2s,
      note: "Late strength",
      formula: "2.87·SiO₂ − 0.754·C₃S",
      low: 10,
      high: 20,
    },
    {
      label: "C₃A (Aluminate)",
      value: mix.c3a,
      note: "Heat / sulfate resistance",
      formula: "2.65·Al₂O₃ − 1.69·Fe₂O₃",
      low: 8,
      high: 12,
    },
    {
      label: "C₄AF (Ferrite)",
      value: mix.c4af,
      note: "Color / resistance",
      formula: "3.04·Fe₂O₃",
      low: 8,
      high: 12,
    },
  ];

  return (
    <Card className="card-elevated" data-ocid="raw_mix.bogue_card">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <span className="text-xs font-bold bg-primary/15 text-primary rounded px-1.5 py-0.5">
            F
          </span>
          Bogue Phase Composition
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Clinker mineralogy from blended oxides (SO₃ assumed 0)
        </p>
      </CardHeader>
      <CardContent className="space-y-5">
        {phases.map((p) => (
          <div key={p.label} className="space-y-1">
            <PhaseBar
              label={p.label}
              value={p.value}
              low={p.low}
              high={p.high}
            />
            <p className="text-[10px] text-muted-foreground">{p.note}</p>
            <FormulaTag formula={p.formula} />
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function RawMixDesigner() {
  const [geom, setGeom] = useState<GeomInputs>(defaultGeom);
  const [loading, setLoading] = useState<LoadingInputs>(defaultLoading);
  const [thermal, setThermal] = useState<ThermalInputs>(defaultThermal);
  const [materials, setMaterials] = useState<Material[]>(defaultMaterials);

  const resetKiln = () => {
    setGeom(defaultGeom);
    setLoading(defaultLoading);
    setThermal(defaultThermal);
  };

  const resetMix = () => setMaterials(defaultMaterials);

  const mixResults: MixCalc | null = useMemo(() => {
    const totalProp = materials.reduce(
      (s, m) => s + (Number.parseFloat(m.proportion) || 0),
      0,
    );
    if (totalProp <= 0) return null;

    let cao = 0;
    let sio2 = 0;
    let al2o3 = 0;
    let fe2o3 = 0;

    for (const m of materials) {
      const p = (Number.parseFloat(m.proportion) || 0) / 100;
      cao += p * (Number.parseFloat(m.cao) || 0);
      sio2 += p * (Number.parseFloat(m.sio2) || 0);
      al2o3 += p * (Number.parseFloat(m.al2o3) || 0);
      fe2o3 += p * (Number.parseFloat(m.fe2o3) || 0);
    }

    const denom = 2.8 * sio2 + 1.2 * al2o3 + 0.65 * fe2o3;
    const lsf = denom > 0 ? (cao / denom) * 100 : 0;
    const sr = al2o3 + fe2o3 > 0 ? sio2 / (al2o3 + fe2o3) : 0;
    const ar = fe2o3 > 0 ? al2o3 / fe2o3 : 0;
    const c3s = 4.07 * cao - 7.6 * sio2 - 6.72 * al2o3 - 1.43 * fe2o3;
    const c2s = 2.87 * sio2 - 0.754 * c3s;
    const c3a = 2.65 * al2o3 - 1.69 * fe2o3;
    const c4af = 3.04 * fe2o3;

    return {
      totalProportion: totalProp.toFixed(1),
      cao: cao.toFixed(2),
      sio2: sio2.toFixed(2),
      al2o3: al2o3.toFixed(2),
      fe2o3: fe2o3.toFixed(2),
      lsf: lsf.toFixed(1),
      lsfNum: lsf,
      sr: sr.toFixed(2),
      srNum: sr,
      ar: ar.toFixed(2),
      arNum: ar,
      c3s: Math.max(0, c3s).toFixed(1),
      c2s: Math.max(0, c2s).toFixed(1),
      c3a: Math.max(0, c3a).toFixed(1),
      c4af: Math.max(0, c4af).toFixed(1),
      propOk: Math.abs(totalProp - 100) < 0.1,
    };
  }, [materials]);

  return (
    <div className="bg-background min-h-screen">
      {/* Page Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            to="/tools"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-5"
            data-ocid="raw_mix.back_link"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Tools
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FlaskConical className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Kiln &amp; Raw Mill
              </p>
              <h1 className="text-2xl md:text-3xl font-bold font-display text-foreground">
                Kiln Throughput &amp; Raw Mix Designer
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground text-sm max-w-2xl mt-2">
            Two independent calculators: analyze kiln geometry, loading, and
            thermal performance — then design your raw mix with oxide chemistry,
            moduli (LSF, SR, AR), and Bogue clinker phases.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
        {/* ═══ SECTION 1 — KILN THROUGHPUT ════════════════════════════════════ */}
        <section data-ocid="kiln_throughput.section">
          <div className="flex items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <Factory className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <h2 className="text-xl font-bold font-display text-foreground">
                  Kiln Throughput Calculator
                </h2>
                <p className="text-xs text-muted-foreground">
                  Calculate kiln capacity, loading and residence time from
                  dimensions
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={resetKiln}
              data-ocid="kiln_throughput.reset_button"
            >
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" /> Reset
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <CardA geom={geom} setGeom={setGeom} />
            <CardB loading={loading} setLoading={setLoading} />
            <CardC thermal={thermal} setThermal={setThermal} />
          </div>
        </section>

        <SectionDivider label="Section 2 — Raw Mix Moduli" />

        {/* ═══ SECTION 2 — RAW MIX MODULI ═════════════════════════════════════ */}
        <section data-ocid="raw_mix.section">
          <div className="flex items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                <FlaskConical className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-bold font-display text-foreground">
                  Raw Mix Moduli Calculator
                </h2>
                <p className="text-xs text-muted-foreground">
                  Calculate LSF, silica ratio, alumina ratio, and Bogue phases
                  from oxide composition
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={resetMix}
              data-ocid="raw_mix.reset_button"
            >
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" /> Reset
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <CardD
              materials={materials}
              setMaterials={setMaterials}
              totalProportion={mixResults?.totalProportion ?? "0.0"}
              propOk={mixResults?.propOk ?? false}
            />
            <CardE mix={mixResults} />
            <CardF mix={mixResults} />
          </div>
        </section>
      </div>
    </div>
  );
}
