import { createActor } from "@/backend";
import { ExternalBlob } from "@/backend";
import { getStoredToken } from "@/hooks/useAuth";
import type {
  Article,
  ArticleListResult,
  CreateArticleInput,
  ListArticlesFilter,
  UpdateArticleInput,
} from "@/types";
import { ArticleStatus, Category, SortBy } from "@/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

// ---------------------------------------------------------------------------
// Actor factory — no II provider required
// ---------------------------------------------------------------------------

function getCanisterId(): string | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const env = (import.meta as any).env;
    const fromVite = env?.VITE_BACKEND_CANISTER_ID ?? env?.CANISTER_ID_BACKEND;
    if (
      fromVite &&
      typeof fromVite === "string" &&
      fromVite !== "undefined" &&
      fromVite.length > 0
    ) {
      return fromVite;
    }
  } catch {
    /* ignore */
  }
  try {
    // @ts-expect-error — global injected by the platform
    const cfg = window.__caffeine_env ?? {};
    const cid = cfg.backend_canister_id ?? "";
    if (cid.length > 0 && cid !== "undefined") return cid;
  } catch {
    /* ignore */
  }
  return null;
}

// No-op file handlers — this app does not use object storage
const noopUpload = async (_file: ExternalBlob): Promise<Uint8Array> =>
  new Uint8Array();
const noopDownload = async (_bytes: Uint8Array): Promise<ExternalBlob> =>
  ExternalBlob.fromURL("");

// Create actor once at module level — synchronous, no React hook needed
const canisterId = getCanisterId();
const actor = canisterId
  ? (() => {
      try {
        return createActor(canisterId, noopUpload, noopDownload);
      } catch {
        return null;
      }
    })()
  : null;

// ---------------------------------------------------------------------------
// Sample data — shown when the backend actor is unavailable (dev / preview)
// ---------------------------------------------------------------------------
const now = BigInt(Date.now());
const DAY = BigInt(86_400_000);

const SAMPLE_ARTICLES: Article[] = [
  {
    id: BigInt(1),
    slug: "optimizing-raw-mill-grinding-efficiency",
    title: "Optimizing Raw Mill Grinding Efficiency: A Practical Guide",
    excerpt:
      "Discover proven strategies to improve throughput, reduce specific energy consumption, and extend wear-part life in your raw mill circuit.",
    content:
      "## Introduction\nRaw mill grinding is one of the highest energy-consuming operations in a cement plant. Achieving optimal efficiency requires a systematic approach to process control, maintenance scheduling, and equipment configuration.\n\n## Key Parameters\nFocus on feed moisture, mill inlet/outlet differential pressure, separator speed, and specific power consumption. Even a 1 kWh/t improvement across a 3000 t/d plant saves significant costs annually.\n\n## Practical Steps\n1. Establish baseline KPIs via a performance audit\n2. Calibrate online moisture analysers\n3. Tune classifier speed to target PSD\n4. Implement expert-system-based PID loops\n\n## Conclusion\nSystematic optimisation of raw grinding can yield 5–10% energy savings and a measurable increase in mill throughput.",
    category: Category.RawMill,
    authorName: "Dr. Ahmed Hassan",
    publishDate: now - DAY * BigInt(3),
    lastUpdated: now - DAY * BigInt(3),
    viewCount: BigInt(1240),
    status: ArticleStatus.published,
    metaDescription:
      "Proven strategies to improve throughput, reduce energy, and extend wear-part life in raw mill circuits.",
    featuredImageUrl: undefined,
  },
  {
    id: BigInt(2),
    slug: "cement-mill-separator-efficiency-improvements",
    title: "Cement Mill Separator Efficiency: Modern Approaches",
    excerpt:
      "Third-generation separators dramatically reduce circulating load and improve cement particle size distribution — here's how to get the most from yours.",
    content:
      "## Background\nThe cement mill separator is the critical quality control point in the finish-grinding circuit. An inefficient separator forces high circulating loads, wasting energy and degrading cement quality.\n\n## Third-Generation Advantages\nModern dynamic separators achieve sharp cuts at desired finenesses, reducing the circulating load from 300% to below 150% in many installations.\n\n## Optimisation Checklist\n- Inspect rotor blades and guide vanes quarterly\n- Verify air-flow balance across the separator\n- Cross-check separator efficiency curve against design\n- Log reject and product residues at 45 µm and 90 µm\n\n## Case Study\nA 200 t/h mill increased output by 14% after separator refurbishment with no change to specific power consumption.",
    category: Category.CementMill,
    authorName: "Eng. Maria Santos",
    publishDate: now - DAY * BigInt(7),
    lastUpdated: now - DAY * BigInt(7),
    viewCount: BigInt(987),
    status: ArticleStatus.published,
    metaDescription:
      "Modern separator techniques to reduce circulating load and improve cement PSD in finish-grinding circuits.",
    featuredImageUrl: undefined,
  },
  {
    id: BigInt(3),
    slug: "kiln-burning-zone-temperature-control",
    title: "Mastering Kiln Burning Zone Temperature Control",
    excerpt:
      "Stable burning zone temperatures are the foundation of consistent clinker quality. Learn how to identify instability causes and implement effective corrective actions.",
    content:
      "## Why Burning Zone Stability Matters\nThe burning zone of a rotary kiln operates at 1400-1500 degC. Thermal fluctuations directly impact free-lime content, clinker C3S formation, and coating behaviour.\n\n## Common Instability Causes\n- Raw mix chemistry variations (LSF, SR, AR)\n- Feed rate surges from raw mill interruptions\n- Fuel quality swings\n- Primary air / secondary air imbalance\n\n## Control Strategies\n1. Implement real-time raw mix correction via online XRF\n2. Use a heat-camera pyrometer with automatic emissivity correction\n3. Establish a burning zone index composite KPI\n4. Deploy model-predictive control (MPC) to anticipate kiln disturbances\n\n## Results\nPlants deploying MPC for kiln burning zone control consistently report 5 degC stability versus 25 degC with manual control.",
    category: Category.Kiln,
    authorName: "Dr. Peter Müller",
    publishDate: now - DAY * BigInt(12),
    lastUpdated: now - DAY * BigInt(12),
    viewCount: BigInt(2105),
    status: ArticleStatus.published,
    metaDescription:
      "Identify burning zone instability causes and implement effective corrective actions for consistent clinker quality.",
    featuredImageUrl: undefined,
  },
  {
    id: BigInt(4),
    slug: "alternative-fuels-co-processing-cement-kiln",
    title: "Alternative Fuels Co-Processing in Cement Kilns",
    excerpt:
      "Co-processing waste-derived fuels can cut fuel costs by 30–50% while reducing landfill burden. This guide covers qualification, handling, and feeding best practices.",
    content:
      "## The Business Case\nAlternative fuels (AF) typically cost 30-70% less than coal or petcoke on a calorific-value basis. Plants in Europe routinely achieve thermal substitution rates (TSR) above 70%.\n\n## Fuel Categories\n- Solid recovered fuel (SRF / RDF)\n- Tyres (whole or shredded)\n- Biomass (agricultural residues, wood waste)\n- Liquid hazardous waste\n- Sewage sludge\n\n## Pre-qualification Requirements\n- Calorific value and moisture limits\n- Chlorine content less than 0.5% (to limit bypass demand)\n- Heavy metal limits per national regulations\n\n## Operational Considerations\nFeeding AF at the main burner vs. the calciner affects burning zone temperature and NOx. Detailed mass and energy balance modelling is essential before increasing TSR beyond 20%.",
    category: Category.AFR,
    authorName: "Eng. Priya Nair",
    publishDate: now - DAY * BigInt(18),
    lastUpdated: now - DAY * BigInt(18),
    viewCount: BigInt(1567),
    status: ArticleStatus.published,
    metaDescription:
      "Co-processing waste-derived fuels to cut costs and reduce environmental impact in cement kilns.",
    featuredImageUrl: undefined,
  },
  {
    id: BigInt(5),
    slug: "energy-optimization-waste-heat-recovery",
    title: "Waste Heat Recovery Systems for Cement Plants",
    excerpt:
      "Converting kiln exhaust and clinker cooler waste heat to electricity can self-generate 25–35% of a plant's power needs with payback periods under 6 years.",
    content:
      "## Overview\nA typical dry-process cement plant emits 35-40% of its thermal input as waste heat via the preheater exit gas and clinker cooler vent. Organic Rankine Cycle (ORC) and steam Rankine systems can recover this energy as electrical power.\n\n## System Configurations\n- Combined WHR: Preheater + cooler in a single steam circuit (most common)\n- ORC only: Lower temperature threshold, suitable for smaller kilns\n- Co-generation: Power + process heat for drying raw materials\n\n## Typical Yields\n- 2000 t/d kiln: 3-4 MW (28% of plant demand)\n- 4000 t/d kiln: 7-9 MW (32% of plant demand)\n- 6000 t/d kiln: 11-14 MW (35% of plant demand)\n\n## Financial Model\nAt $0.08/kWh avoided cost and 8400 operating hours per year, a 5 MW WHR plant saves ~$3.4M annually, giving a simple payback of 4-6 years on a $15-20M investment.",
    category: Category.EnergyOptimization,
    authorName: "Dr. Li Wei",
    publishDate: now - DAY * BigInt(25),
    lastUpdated: now - DAY * BigInt(25),
    viewCount: BigInt(3021),
    status: ArticleStatus.published,
    metaDescription:
      "How waste heat recovery systems convert kiln exhaust to electricity, self-generating 25–35% of plant power.",
    featuredImageUrl: undefined,
  },
  {
    id: BigInt(6),
    slug: "raw-mill-vertical-roller-mill-maintenance",
    title: "Vertical Roller Mill Maintenance: Reducing Unplanned Downtime",
    excerpt:
      "VRMs deliver excellent grinding efficiency but require disciplined maintenance programmes. Here's a structured approach to predictive and preventive care.",
    content:
      "## Introduction\nVertical roller mills (VRMs) have become the dominant raw grinding technology in new plants thanks to 30-40% lower specific power versus ball mills. However, unplanned downtime is costly and often avoidable.\n\n## Critical Wear Components\n- Grinding rollers and table liners\n- Hydraulic cylinders and seals\n- Separator rotor blades\n- Gas-seal rings and air-lock feeding devices\n\n## Predictive Maintenance Tools\n1. Vibration monitoring on gearbox and rollers\n2. Oil analysis (viscosity, metallic particles, water content)\n3. Thermal imaging of roller bearings\n4. Historical trending of grinding pressure vs. throughput\n\n## Recommended Inspection Intervals\n- Roller tyres: Monthly inspection, replace at 20 mm wear\n- Table liner: Monthly inspection, replace at 30 mm wear\n- Separator blades: Quarterly inspection, replace on visible erosion\n- Hydraulic seals: Annual inspection, replace on any leakage",
    category: Category.RawMill,
    authorName: "Eng. Carlos Rivera",
    publishDate: now - DAY * BigInt(30),
    lastUpdated: now - DAY * BigInt(30),
    viewCount: BigInt(876),
    status: ArticleStatus.published,
    metaDescription:
      "Structured predictive and preventive maintenance for vertical roller mills to reduce unplanned downtime.",
    featuredImageUrl: undefined,
  },
];

function sampleListResult(
  articles: Article[],
  page: number,
  pageSize: number,
): ArticleListResult {
  const start = page * pageSize;
  return {
    articles: articles.slice(start, start + pageSize),
    total: BigInt(articles.length),
    page: BigInt(page),
    pageSize: BigInt(pageSize),
  };
}

// ---------------------------------------------------------------------------
// Hooks
// ---------------------------------------------------------------------------

export function useLatestArticles(n = 6) {
  return useQuery<Article[]>({
    queryKey: ["articles", "latest", n],
    queryFn: async () => {
      if (!actor) return SAMPLE_ARTICLES.slice(0, n);
      return actor.getLatestArticles(BigInt(n));
    },
  });
}

export function usePopularArticles(n = 6) {
  return useQuery<Article[]>({
    queryKey: ["articles", "popular", n],
    queryFn: async () => {
      if (!actor) {
        return [...SAMPLE_ARTICLES]
          .sort((a, b) => Number(b.viewCount - a.viewCount))
          .slice(0, n);
      }
      return actor.getPopularArticles(BigInt(n));
    },
  });
}

export function useListArticles(
  filter: Partial<ListArticlesFilter> & { page?: number; pageSize?: number },
) {
  const page = filter.page ?? 0;
  const pageSize = filter.pageSize ?? 12;
  const fullFilter: ListArticlesFilter = {
    sortBy: filter.sortBy ?? SortBy.date,
    page: BigInt(page),
    pageSize: BigInt(pageSize),
    ...(filter.category !== undefined ? { category: filter.category } : {}),
    ...(filter.status !== undefined ? { status: filter.status } : {}),
  };
  return useQuery({
    queryKey: ["articles", "list", fullFilter],
    queryFn: async () => {
      if (!actor) {
        let items = SAMPLE_ARTICLES.filter(
          (a) =>
            (!fullFilter.status || a.status === fullFilter.status) &&
            (!fullFilter.category || a.category === fullFilter.category),
        );
        if (fullFilter.sortBy === SortBy.viewCount) {
          items = items.sort((a, b) => Number(b.viewCount - a.viewCount));
        }
        return sampleListResult(items, page, pageSize);
      }
      return actor.listArticles(fullFilter);
    },
  });
}

export function useSearchArticles(query: string) {
  return useQuery<Article[]>({
    queryKey: ["articles", "search", query],
    queryFn: async () => {
      if (!query.trim()) return [];
      if (!actor) {
        const q = query.toLowerCase();
        return SAMPLE_ARTICLES.filter(
          (a) =>
            a.title.toLowerCase().includes(q) ||
            a.excerpt.toLowerCase().includes(q) ||
            a.content.toLowerCase().includes(q),
        );
      }
      return actor.searchArticles(query.trim());
    },
    enabled: query.trim().length > 1,
  });
}

export function useArticleBySlug(slug: string) {
  return useQuery<Article | null>({
    queryKey: ["articles", "slug", slug],
    queryFn: async () => {
      if (!slug) return null;
      if (!actor) {
        return SAMPLE_ARTICLES.find((a) => a.slug === slug) ?? null;
      }
      return actor.getArticleBySlug(slug);
    },
    enabled: !!slug,
  });
}

export function useArticle(id: bigint | undefined) {
  return useQuery<Article | null>({
    queryKey: ["articles", "id", id?.toString()],
    queryFn: async () => {
      if (id === undefined) return null;
      if (!actor) {
        return SAMPLE_ARTICLES.find((a) => a.id === id) ?? null;
      }
      return actor.getArticle(id);
    },
    enabled: id !== undefined,
  });
}

export function useIncrementViewCount() {
  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) return;
      await actor.incrementViewCount(id);
    },
  });
}

export function useCreateArticle() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: CreateArticleInput) => {
      if (!actor) throw new Error("Backend not available");
      const token = getStoredToken();
      console.log(
        "[useCreateArticle] token prefix:",
        token?.slice(0, 8) ?? "null",
      );
      if (!token) throw new Error("SESSION_EXPIRED");
      const valid = await actor.adminVerifyToken(token);
      if (!valid) throw new Error("SESSION_EXPIRED");
      return actor.createArticle(token, input);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["articles"] });
    },
  });
}

export function useUpdateArticle() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: UpdateArticleInput) => {
      if (!actor) throw new Error("Backend not available");
      const token = getStoredToken();
      console.log(
        "[useUpdateArticle] token prefix:",
        token?.slice(0, 8) ?? "null",
        "id:",
        input.id.toString(),
      );
      if (!token) throw new Error("SESSION_EXPIRED");
      const valid = await actor.adminVerifyToken(token);
      if (!valid) throw new Error("SESSION_EXPIRED");
      return actor.updateArticle(token, input);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["articles"] });
    },
  });
}

export function useDeleteArticle() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error("Backend not available");
      const token = getStoredToken();
      console.log(
        "[useDeleteArticle] token prefix:",
        token?.slice(0, 8) ?? "null",
        "id:",
        id.toString(),
      );
      if (!token) throw new Error("SESSION_EXPIRED");
      const valid = await actor.adminVerifyToken(token);
      if (!valid) throw new Error("SESSION_EXPIRED");
      return actor.deleteArticle(token, id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["articles"] });
    },
  });
}

export function usePublishedArticles(
  filter?: Partial<ListArticlesFilter> & { page?: number; pageSize?: number },
) {
  return useListArticles({ ...filter, status: ArticleStatus.published });
}
