import { createActor } from "@/backend";
import { ExternalBlob } from "@/backend";
import { getStoredToken } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
export {
  useCreateArticle,
  useUpdateArticle,
  useDeleteArticle,
} from "./useArticles";

// No-op file handlers — admin area does not use object storage
const noopUpload = async (_file: ExternalBlob): Promise<Uint8Array> =>
  new Uint8Array();
const noopDownload = async (_bytes: Uint8Array): Promise<ExternalBlob> =>
  ExternalBlob.fromURL("");

function getCanisterId(): string | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const env = (import.meta as any).env;
    const id = env?.VITE_BACKEND_CANISTER_ID ?? env?.CANISTER_ID_BACKEND;
    if (id && typeof id === "string" && id !== "undefined" && id.length > 0) {
      return id;
    }
  } catch {
    /* ignore */
  }
  try {
    // @ts-expect-error — global injected by the platform
    const cfg = window.__caffeine_env ?? {};
    const cid = cfg.backend_canister_id ?? "";
    if (cid.length > 0 && cid !== "undefined") return cid;
  } catch {
    /* ignore */
  }
  return null;
}

// Create actor once at module level — no React hook, no II provider required
const canisterId = getCanisterId();
const actor = canisterId
  ? (() => {
      try {
        return createActor(canisterId, noopUpload, noopDownload);
      } catch {
        return null;
      }
    })()
  : null;

export function useIsAdmin() {
  const token = getStoredToken();

  return useQuery<boolean>({
    queryKey: ["admin", "isAdmin", token],
    queryFn: async () => {
      if (!token) return false;
      if (!actor) return false;
      return actor.isAdmin(token);
    },
    enabled: !!token && !!actor,
    staleTime: 5 * 60 * 1000,
  });
}

export function useAdminLogin() {
  return actor;
}
