import { ExternalBlob, createActor } from "@/backend";
import { hashPassword, setStoredToken } from "@/hooks/useAuth";
import { useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Lock, LogIn, User } from "lucide-react";
import { type FormEvent, useState } from "react";

// Create actor at module level — no II provider required
function getCanisterId(): string | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const env = (import.meta as any).env;
    const fromVite = env?.VITE_BACKEND_CANISTER_ID ?? env?.CANISTER_ID_BACKEND;
    if (
      fromVite &&
      typeof fromVite === "string" &&
      fromVite !== "undefined" &&
      fromVite.length > 0
    ) {
      return fromVite;
    }
  } catch {
    /* ignore */
  }
  try {
    // @ts-expect-error — global injected by the platform
    const cfg = window.__caffeine_env ?? {};
    const cid = cfg.backend_canister_id ?? "";
    if (cid.length > 0 && cid !== "undefined") return cid;
  } catch {
    /* ignore */
  }
  return null;
}

const noopUpload = async (_file: ExternalBlob): Promise<Uint8Array> =>
  new Uint8Array();
const noopDownload = async (_bytes: Uint8Array): Promise<ExternalBlob> =>
  ExternalBlob.fromURL("");

const canisterId = getCanisterId();
const actor = canisterId
  ? (() => {
      try {
        return createActor(canisterId, noopUpload, noopDownload);
      } catch {
        return null;
      }
    })()
  : null;

export default function AdminLoginPage() {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;

    setError(null);
    setIsLoading(true);

    try {
      const hashed = await hashPassword(password);

      if (!actor) {
        // No backend — use hardcoded demo credentials for local preview
        if (username === "admin" && password === "admin123") {
          setStoredToken("demo_session_token_1234567890abcdef");
          navigate({ to: "/admin" });
          return;
        }
        setError("Invalid username or password");
        return;
      }

      const result = await actor.adminLogin(username, hashed);
      if (result.__kind__ === "ok") {
        setStoredToken(result.ok);
        navigate({ to: "/admin" });
      } else {
        setError("Invalid username or password");
      }
    } catch {
      setError("Invalid username or password");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      data-ocid="admin_login.page"
      className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-background px-4 py-16"
    >
      <div className="w-full max-w-sm">
        {/* Card */}
        <div className="bg-card border border-border rounded-lg shadow-sm p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center w-12 h-12 rounded-sm bg-primary text-primary-foreground font-bold text-lg font-display mx-auto mb-4">
              C
            </div>
            <h1 className="text-2xl font-bold font-display text-foreground tracking-tight">
              Admin Login
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              CementHub Knowledge Platform
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            {/* Username */}
            <div className="space-y-1.5">
              <label
                htmlFor="username"
                className="text-sm font-medium text-foreground"
              >
                Username
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-muted-foreground">
                  <User className="w-4 h-4" />
                </span>
                <input
                  id="username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter username"
                  data-ocid="admin_login.username.input"
                  className="w-full pl-9 pr-4 py-2.5 rounded-md border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <label
                htmlFor="password"
                className="text-sm font-medium text-foreground"
              >
                Password
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-muted-foreground">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  data-ocid="admin_login.password.input"
                  className="w-full pl-9 pr-10 py-2.5 rounded-md border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  data-ocid="admin_login.password.toggle"
                  className="absolute inset-y-0 right-3 flex items-center text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <p
                data-ocid="admin_login.error_state"
                className="text-sm text-destructive bg-destructive/8 border border-destructive/20 rounded-md px-3 py-2"
              >
                {error}
              </p>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading || !username.trim() || !password}
              data-ocid="admin_login.submit_button"
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/40 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Signing in…
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  Sign In
                </>
              )}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Protected admin area · CementHub
        </p>
      </div>
    </div>
  );
}
